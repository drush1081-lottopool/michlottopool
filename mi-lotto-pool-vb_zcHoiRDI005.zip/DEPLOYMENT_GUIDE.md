# Michigan Lotto Pool - Complete Deployment Guide

## Pre-Launch Checklist

### Legal & Compliance (CRITICAL - Complete FIRST)
- [ ] Consult with Michigan gaming attorney
- [ ] Apply for Michigan Gaming Control Board license
- [ ] Register business entity (LLC recommended)
- [ ] Obtain EIN from IRS
- [ ] Set up business bank account
- [ ] Get liability insurance ($1M+ recommended)
- [ ] Get cyber liability insurance
- [ ] Review and finalize Terms of Service
- [ ] Review and finalize Privacy Policy
- [ ] Set up escrow account for pool funds
- [ ] Establish accounting system
- [ ] Hire CPA familiar with gaming operations

### Technical Setup

#### 1. Domain & Hosting

**Register Domain:**
\`\`\`bash
# Recommended domains (check availability):
- milottopool.com
- michiganlottopool.com
- milottery.app
\`\`\`

**Deploy to Vercel:**
1. Click "Publish" button in v0 (top right)
2. Or manually:
\`\`\`bash
npm install -g vercel
vercel login
vercel --prod
\`\`\`

3. Connect custom domain in Vercel dashboard
4. SSL certificates are automatic with Vercel

#### 2. Database Setup (Choose One)

**Option A: Supabase (Recommended for beginners)**
1. Go to supabase.com and create project
2. Copy connection details from Settings > Database
3. Run SQL scripts in Supabase SQL Editor:
   - Execute `scripts/01-create-database-schema.sql`
   - Execute `scripts/02-seed-initial-data.sql`
4. Enable Row Level Security policies
5. Add Supabase integration in v0 (Connect tab)

**Option B: Neon (Recommended for scale)**
1. Go to neon.tech and create project
2. Copy DATABASE_URL from connection details
3. Use a database client to run SQL scripts
4. Add Neon integration in v0 (Connect tab)

#### 3. Email Service Setup

**Option A: Resend (Easiest, $20/month)**
\`\`\`bash
1. Sign up at resend.com
2. Verify your domain (add DNS records)
3. Get API key from dashboard
4. Add to environment variables
\`\`\`

**Option B: SendGrid (Reliable, free tier available)**
\`\`\`bash
1. Sign up at sendgrid.com
2. Complete sender verification
3. Create API key
4. Add to environment variables
\`\`\`

**Option C: AWS SES (Cheapest for scale)**
\`\`\`bash
1. AWS Console > SES
2. Verify domain and email
3. Request production access
4. Create IAM user with SES permissions
5. Add credentials to environment variables
\`\`\`

#### 4. Payment Processing (Stripe)

\`\`\`bash
# Setup Steps:
1. Create Stripe account at stripe.com
2. Complete business verification
3. Get API keys from Dashboard > Developers
4. Add webhook endpoint: https://milottopool.com/api/webhooks/stripe
5. Add webhook secret to environment variables
6. Test in test mode before going live
\`\`\`

**Important Stripe Settings:**
- Enable payment methods: Card, ACH
- Set up payout schedule (daily recommended)
- Configure tax settings for 1099 reporting
- Enable dispute protection

#### 5. Environment Variables

Copy `.env.example` to `.env.local` and fill all values:

\`\`\`bash
# In Vercel Dashboard:
1. Go to Project Settings > Environment Variables
2. Add all variables from .env.example
3. Set for Production, Preview, and Development
4. Redeploy after adding variables
\`\`\`

**Critical Variables to Set:**
- DATABASE_URL
- STRIPE_SECRET_KEY
- RESEND_API_KEY (or email provider)
- JWT_SECRET (generate with: openssl rand -base64 32)
- CRON_SECRET (for daily email job)

#### 6. Cron Jobs for Daily Emails

**Setup Vercel Cron:**

Create `vercel.json`:
\`\`\`json
{
  "crons": [
    {
      "path": "/api/cron/send-daily-numbers",
      "schedule": "0 8 * * *"
    }
  ]
}
\`\`\`

Create API route `app/api/cron/send-daily-numbers/route.ts`:
\`\`\`typescript
export async function GET(request: Request) {
  // Verify cron secret
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return new Response('Unauthorized', { status: 401 });
  }

  // Send emails to all active users
  // Implementation here

  return Response.json({ success: true });
}
\`\`\`

#### 7. Identity Verification (KYC)

**Manual Process (Start here):**
- Admin reviews submissions manually in admin dashboard
- Check ID documents, proof of residency
- Approve/reject from `/admin/users` page

**Automated (Add later):**
- Integrate Veriff or Stripe Identity
- Automatic ID verification
- Cost: ~$1-2 per verification

#### 8. File Storage for Documents

**Option A: Vercel Blob (Easiest)**
\`\`\`bash
npm install @vercel/blob
# Get token from Vercel dashboard
\`\`\`

**Option B: AWS S3**
\`\`\`bash
1. Create S3 bucket
2. Set lifecycle policies for document retention
3. Enable encryption at rest
4. Set up IAM access
\`\`\`

#### 9. Monitoring & Error Tracking

**Sentry Setup:**
\`\`\`bash
npm install @sentry/nextjs
npx @sentry/wizard@latest -i nextjs
\`\`\`

**Vercel Analytics:**
- Automatically enabled with Vercel deployment
- View in Vercel dashboard

### Security Hardening

#### 1. Rate Limiting (Recommended)
\`\`\`bash
# Install Upstash Redis for rate limiting
npm install @upstash/redis @upstash/ratelimit
\`\`\`

#### 2. Security Headers
Add to `next.config.js`:
\`\`\`javascript
module.exports = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
        ],
      },
    ];
  },
};
\`\`\`

#### 3. Password Security
- Already using bcrypt for hashing
- Enforce minimum 8 characters
- Consider adding 2FA later

#### 4. HTTPS Only
- Automatic with Vercel
- Enforce HTTPS redirects in middleware

### Launch Strategy

#### Phase 1: Closed Beta (Week 1-4)
- [ ] Invite 20-50 friends/family
- [ ] Test all features with real money (small amounts)
- [ ] Fix critical bugs
- [ ] Gather feedback

#### Phase 2: Limited Launch (Month 2)
- [ ] Open to one Michigan city
- [ ] Maximum 500 members
- [ ] Monitor all transactions manually
- [ ] Establish support processes

#### Phase 3: Full Launch (Month 3+)
- [ ] Expand to all Michigan
- [ ] Increase marketing
- [ ] Hire support staff
- [ ] Scale infrastructure

### Daily Operations Checklist

**Every Morning:**
- [ ] Review overnight transactions
- [ ] Check for failed payments
- [ ] Monitor error logs
- [ ] Verify daily email sent successfully

**Every Week:**
- [ ] Review pending KYC verifications
- [ ] Process payouts to winners
- [ ] Check compliance metrics
- [ ] Review customer support tickets

**Every Month:**
- [ ] Generate tax reports
- [ ] File regulatory reports
- [ ] Audit user activity
- [ ] Review financial statements

### Support Setup

**Create Support Channels:**
1. support@milottopool.com email
2. Phone line: Consider Google Voice initially
3. Live chat: Add Intercom or similar
4. FAQ page: Already created

**Support Hours:**
- Start: Mon-Fri 9am-5pm EST
- Goal: 24/7 eventually

### Marketing & Growth

**Initial Marketing:**
1. Local Michigan Facebook groups
2. Reddit r/Michigan (follow rules)
3. Local community centers
4. Michigan lottery retailers (partnerships)
5. Word of mouth referral program

**SEO:**
- Submit sitemap to Google
- Claim Google My Business
- Get listed in Michigan business directories

### Cost Estimates (Monthly)

**Minimum to Start:**
- Vercel Pro: $20/month
- Database (Supabase/Neon): $25/month
- Email (Resend): $20/month
- Domain: $15/year
- Stripe fees: 2.9% + 30¢ per transaction
- **Total: ~$70/month + transaction fees**

**With Growth:**
- Legal/Compliance: $500-1000/month
- Insurance: $200-500/month
- Customer Support: $2000+/month (staff)
- Marketing: $500-2000/month
- **Total: ~$3,200-4,500/month**

### Emergency Contacts

**Keep these numbers handy:**
- Michigan Gaming Control Board: (517) 241-0040
- Your attorney: [Add here]
- Your CPA: [Add here]
- Stripe Support: support.stripe.com
- Vercel Support: vercel.com/help

### Post-Launch Monitoring

**Watch These Metrics:**
1. New member signups
2. Failed payment rate
3. KYC approval rate
4. Email delivery rate
5. Support ticket response time
6. User retention rate
7. Average transaction size

### When Things Go Wrong

**Payment Failed:**
1. Contact user immediately
2. Offer alternative payment method
3. Log in admin system
4. Follow up in 24 hours

**Winner Dispute:**
1. Review audit logs
2. Check lottery combination records
3. Contact legal counsel if needed
4. Document everything

**Security Breach:**
1. Immediately disable affected systems
2. Contact security expert
3. Notify affected users
4. File required breach notifications
5. Review and patch vulnerability

### Success Metrics (First 6 Months)

**Minimum Viable:**
- 500+ active members
- $25,000+ in monthly pool contributions
- <5% payment failure rate
- <24 hour support response time
- 100% compliance with regulations

**Ideal:**
- 2,000+ active members
- $100,000+ in monthly pool contributions
- <2% payment failure rate
- <4 hour support response time
- Zero compliance violations

### Next Steps After Launch

**Month 3-6:**
- [ ] Add mobile app (React Native)
- [ ] Automated KYC with Veriff
- [ ] Advanced analytics dashboard
- [ ] Referral program
- [ ] Multiple pool options

**Month 6-12:**
- [ ] Expand to other states
- [ ] White-label solution for lottery retailers
- [ ] Corporate/office pools
- [ ] Syndicate features
- [ ] International expansion research

## Need Help?

This is a complex business with legal, financial, and technical requirements. Consider:

1. **Hire a technical co-founder** who can manage the platform
2. **Partner with existing lottery retailer** for legal/financial
3. **Start consulting business** helping organize pools instead

## Final Checklist Before Going Live

- [ ] All legal approvals obtained
- [ ] Insurance policies active
- [ ] Database fully set up and backed up
- [ ] All environment variables configured
- [ ] Payment processing tested end-to-end
- [ ] Email system tested
- [ ] KYC process tested
- [ ] Support system ready
- [ ] Emergency procedures documented
- [ ] Team trained on all systems
- [ ] Beta testing complete
- [ ] Legal documents reviewed by attorney
- [ ] Accounting system ready
- [ ] Tax reporting system configured
- [ ] Compliance monitoring active
- [ ] Backup admin accounts created
- [ ] Monitoring and alerts configured

**Only launch when ALL items are checked!**
