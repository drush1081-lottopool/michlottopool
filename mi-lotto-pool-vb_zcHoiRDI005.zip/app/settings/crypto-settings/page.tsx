"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Bitcoin, TrendingUp, Wallet, Shield, Copy, CheckCircle, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function CryptoSettingsPage() {
  const [autoConvert, setAutoConvert] = useState(false)
  const [minThreshold, setMinThreshold] = useState("100")
  const [walletAddress, setWalletAddress] = useState("")
  const [savedWallet, setSavedWallet] = useState("bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh")
  const [copied, setCopied] = useState(false)

  // Real-time Bitcoin price
  const btcPrice = 96842.5
  const btcChange = 2.4

  const conversionHistory = [
    { date: "Jan 5, 2025", usd: 1500, btc: 0.0155, rate: 96774, txId: "a1b2c3d4..." },
    { date: "Dec 28, 2024", usd: 2200, btc: 0.0228, rate: 96491, txId: "e5f6g7h8..." },
    { date: "Dec 15, 2024", usd: 800, btc: 0.0083, rate: 96386, txId: "i9j0k1l2..." },
  ]

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Bitcoin Conversion</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        <Tabs defaultValue="settings" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="learn">Learn</TabsTrigger>
          </TabsList>

          <TabsContent value="settings" className="space-y-4 mt-6">
            {/* Current BTC Price */}
            <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Bitcoin className="h-8 w-8 text-orange-500" />
                    <span className="text-2xl font-bold text-gray-900">Bitcoin</span>
                  </div>
                  <Badge className={btcChange >= 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {btcChange >= 0 ? "+" : ""}
                    {btcChange}%
                  </Badge>
                </div>
                <div className="space-y-2">
                  <p className="text-4xl font-bold text-gray-900">${btcPrice.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">Price updates every 5 minutes</p>
                </div>
              </CardContent>
            </Card>

            {/* Auto-Convert Settings */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Auto-Convert Winnings</CardTitle>
                <CardDescription>Automatically convert lottery winnings to Bitcoin</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <Label htmlFor="auto-convert" className="font-medium">
                      Enable Auto-Conversion
                    </Label>
                    <p className="text-sm text-gray-600">Convert winnings to BTC automatically</p>
                  </div>
                  <Switch id="auto-convert" checked={autoConvert} onCheckedChange={setAutoConvert} />
                </div>

                {autoConvert && (
                  <div className="space-y-4 p-4 bg-orange-50 rounded-lg border border-orange-200">
                    <div className="space-y-2">
                      <Label htmlFor="threshold">Minimum Amount to Convert</Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                        <Input
                          id="threshold"
                          type="number"
                          value={minThreshold}
                          onChange={(e) => setMinThreshold(e.target.value)}
                          className="pl-7"
                        />
                      </div>
                      <p className="text-xs text-gray-500">Only convert winnings above this amount</p>
                    </div>

                    <div className="p-3 bg-white rounded border border-orange-200">
                      <div className="flex items-start space-x-2">
                        <AlertCircle className="h-4 w-4 text-orange-600 mt-0.5" />
                        <div className="text-xs text-orange-800">
                          <p className="font-medium">Profit Maximization Strategy</p>
                          <p>
                            Converting to Bitcoin may increase value over time. Past performance doesn't guarantee
                            future results.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Bitcoin Wallet */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <Wallet className="h-5 w-5 text-orange-500" />
                  <span>Bitcoin Wallet</span>
                </CardTitle>
                <CardDescription>Where your converted Bitcoin will be sent</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {savedWallet ? (
                  <div className="space-y-3">
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="h-5 w-5 text-green-600" />
                          <span className="font-medium text-green-900">Wallet Connected</span>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => copyToClipboard(savedWallet)}>
                          {copied ? <CheckCircle className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm font-mono text-gray-700 break-all">{savedWallet}</p>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full bg-transparent"
                      onClick={() => {
                        setSavedWallet("")
                        setWalletAddress("")
                      }}
                    >
                      Change Wallet
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="wallet">Bitcoin Wallet Address</Label>
                      <Input
                        id="wallet"
                        placeholder="bc1q..."
                        value={walletAddress}
                        onChange={(e) => setWalletAddress(e.target.value)}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-gray-500">Enter your Bitcoin (BTC) wallet address</p>
                    </div>

                    <div className="p-3 bg-blue-50 rounded border border-blue-200">
                      <div className="flex items-start space-x-2">
                        <Shield className="h-4 w-4 text-blue-600 mt-0.5" />
                        <div className="text-xs text-blue-800">
                          <p className="font-medium">Security Notice</p>
                          <p>We never store your private keys. Only provide your public wallet address.</p>
                        </div>
                      </div>
                    </div>

                    <Button
                      className="w-full bg-orange-600 hover:bg-orange-700"
                      disabled={!walletAddress}
                      onClick={() => setSavedWallet(walletAddress)}
                    >
                      Save Wallet Address
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Conversion Preview */}
            {autoConvert && savedWallet && (
              <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Conversion Preview</CardTitle>
                  <CardDescription>Estimated conversion at current rates</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-white rounded-lg">
                      <p className="text-sm text-gray-600 mb-1">If you win</p>
                      <p className="text-2xl font-bold text-gray-900">$1,000</p>
                    </div>
                    <div className="text-center p-4 bg-white rounded-lg">
                      <p className="text-sm text-gray-600 mb-1">You'll receive</p>
                      <p className="text-2xl font-bold text-orange-600">{(1000 / btcPrice).toFixed(6)} BTC</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded text-sm">
                    <p className="text-gray-600 mb-2">Potential profit scenarios (12 months):</p>
                    <div className="space-y-1">
                      <div className="flex justify-between">
                        <span>+10% BTC growth:</span>
                        <span className="font-medium text-green-600">$1,100</span>
                      </div>
                      <div className="flex justify-between">
                        <span>+25% BTC growth:</span>
                        <span className="font-medium text-green-600">$1,250</span>
                      </div>
                      <div className="flex justify-between">
                        <span>+50% BTC growth:</span>
                        <span className="font-medium text-green-600">$1,500</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-gray-500 text-center">
                    These are estimates. Cryptocurrency values can go up or down.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Conversion History</h2>
              <Badge variant="secondary">{conversionHistory.length} conversions</Badge>
            </div>

            {conversionHistory.map((conversion, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <Bitcoin className="h-5 w-5 text-orange-500" />
                      <div>
                        <p className="font-medium">${conversion.usd.toLocaleString()}</p>
                        <p className="text-sm text-gray-600">{conversion.date}</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Bitcoin Received:</span>
                      <span className="font-medium text-orange-600">{conversion.btc} BTC</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Conversion Rate:</span>
                      <span className="font-medium">${conversion.rate.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Current Value:</span>
                      <span className="font-medium text-green-600">${(conversion.btc * btcPrice).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Profit/Loss:</span>
                      <span
                        className={`font-medium ${
                          conversion.btc * btcPrice > conversion.usd ? "text-green-600" : "text-red-600"
                        }`}
                      >
                        {conversion.btc * btcPrice > conversion.usd ? "+" : ""}$
                        {(conversion.btc * btcPrice - conversion.usd).toFixed(2)} (
                        {(((conversion.btc * btcPrice - conversion.usd) / conversion.usd) * 100).toFixed(1)}%)
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 p-2 bg-gray-50 rounded">
                    <p className="text-xs text-gray-600">Transaction ID:</p>
                    <p className="text-xs font-mono text-gray-800">{conversion.txId}</p>
                  </div>
                </CardContent>
              </Card>
            ))}

            {conversionHistory.length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <Bitcoin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No Conversions Yet</h3>
                  <p className="text-gray-600">Your Bitcoin conversion history will appear here.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="learn" className="space-y-4 mt-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Why Convert to Bitcoin?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start space-x-3">
                  <TrendingUp className="h-5 w-5 text-green-600 mt-1" />
                  <div>
                    <p className="font-medium">Potential Growth</p>
                    <p className="text-sm text-gray-600">
                      Bitcoin has historically appreciated over time, potentially increasing your winnings value.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Shield className="h-5 w-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-medium">Hedge Against Inflation</p>
                    <p className="text-sm text-gray-600">
                      Bitcoin's limited supply makes it resistant to traditional currency inflation.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Wallet className="h-5 w-5 text-orange-600 mt-1" />
                  <div>
                    <p className="font-medium">Full Control</p>
                    <p className="text-sm text-gray-600">
                      You own your Bitcoin directly in your wallet with no intermediaries.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <AlertCircle className="h-5 w-5 text-yellow-600" />
                  <span>Important Risks</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-gray-700">
                <p>
                  <strong>Volatility:</strong> Bitcoin prices can fluctuate significantly, potentially decreasing the
                  value of your winnings.
                </p>
                <p>
                  <strong>Irreversible:</strong> Bitcoin transactions cannot be reversed once completed.
                </p>
                <p>
                  <strong>Security:</strong> You are responsible for securing your Bitcoin wallet and private keys.
                </p>
                <p>
                  <strong>Tax Implications:</strong> Cryptocurrency conversions may have tax consequences. Consult a tax
                  professional.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">How It Works</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center flex-shrink-0 font-bold text-xs">
                    1
                  </div>
                  <div>
                    <p className="font-medium">You Win</p>
                    <p className="text-gray-600">Your pool wins and your share is calculated</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center flex-shrink-0 font-bold text-xs">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Auto-Conversion Check</p>
                    <p className="text-gray-600">System checks if amount meets your minimum threshold</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center flex-shrink-0 font-bold text-xs">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Instant Conversion</p>
                    <p className="text-gray-600">Your USD winnings are converted to Bitcoin at current market rate</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center flex-shrink-0 font-bold text-xs">
                    4
                  </div>
                  <div>
                    <p className="font-medium">Bitcoin Sent</p>
                    <p className="text-gray-600">Bitcoin is transferred to your wallet address within 24 hours</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="font-medium text-blue-900 mb-2">Need Help?</p>
                  <p className="text-sm text-blue-700 mb-3">
                    Learn more about Bitcoin wallets and how to set up your first wallet
                  </p>
                  <Button size="sm" variant="outline" className="bg-white">
                    Bitcoin Wallet Guide
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
