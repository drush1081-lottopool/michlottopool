"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Facebook, Twitter, Instagram, Linkedin, Youtube, CheckCircle, Unlink } from "lucide-react"
import Link from "next/link"

export default function SocialAccountsPage() {
  const [accounts, setAccounts] = useState({
    facebook: "",
    twitter: "",
    instagram: "",
    linkedin: "",
    youtube: "",
  })

  const [connected, setConnected] = useState({
    facebook: false,
    twitter: false,
    instagram: false,
    linkedin: false,
    youtube: false,
  })

  const [saved, setSaved] = useState(false)

  const socialPlatforms = [
    {
      name: "facebook",
      label: "Facebook",
      icon: Facebook,
      color: "text-blue-600",
      placeholder: "facebook.com/username",
    },
    {
      name: "twitter",
      label: "Twitter / X",
      icon: Twitter,
      color: "text-sky-500",
      placeholder: "twitter.com/username",
    },
    {
      name: "instagram",
      label: "Instagram",
      icon: Instagram,
      color: "text-pink-600",
      placeholder: "instagram.com/username",
    },
    {
      name: "linkedin",
      label: "LinkedIn",
      icon: Linkedin,
      color: "text-blue-700",
      placeholder: "linkedin.com/in/username",
    },
    { name: "youtube", label: "YouTube", icon: Youtube, color: "text-red-600", placeholder: "youtube.com/@username" },
  ]

  const handleConnect = (platform: string) => {
    if (accounts[platform as keyof typeof accounts]) {
      setConnected({ ...connected, [platform]: true })
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    }
  }

  const handleDisconnect = (platform: string) => {
    setConnected({ ...connected, [platform]: false })
    setAccounts({ ...accounts, [platform]: "" })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Social Accounts</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {saved && (
          <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center space-x-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <p className="text-sm text-green-700">Account connected successfully!</p>
          </div>
        )}

        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Connect Your Social Media</CardTitle>
            <CardDescription>Link your social accounts to share wins and connect with pool members</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {socialPlatforms.map((platform) => {
              const Icon = platform.icon
              const isConnected = connected[platform.name as keyof typeof connected]

              return (
                <div key={platform.name} className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Icon className={`h-6 w-6 ${platform.color}`} />
                      <div>
                        <p className="font-medium">{platform.label}</p>
                        {isConnected && <Badge className="mt-1 bg-green-100 text-green-800">Connected</Badge>}
                      </div>
                    </div>
                    {isConnected && (
                      <Button variant="ghost" size="sm" onClick={() => handleDisconnect(platform.name)}>
                        <Unlink className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  {isConnected ? (
                    <div className="p-3 bg-green-50 rounded border border-green-200">
                      <p className="text-sm text-gray-700 break-all">
                        {accounts[platform.name as keyof typeof accounts]}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor={platform.name}>Profile URL or Username</Label>
                      <Input
                        id={platform.name}
                        placeholder={platform.placeholder}
                        value={accounts[platform.name as keyof typeof accounts]}
                        onChange={(e) => setAccounts({ ...accounts, [platform.name]: e.target.value })}
                      />
                      <Button
                        className="w-full"
                        onClick={() => handleConnect(platform.name)}
                        disabled={!accounts[platform.name as keyof typeof accounts]}
                      >
                        Connect {platform.label}
                      </Button>
                    </div>
                  )}
                </div>
              )
            })}
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <h4 className="font-medium text-blue-900 mb-2">Why Connect Social Media?</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Share your winning moments with friends</li>
              <li>• Connect with other pool members</li>
              <li>• Invite friends to join your pool</li>
              <li>• Build trust within the community</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
