"use client"

import { ArrowLeft, FileText, Scale, Shield, AlertTriangle } from "lucide-react"
import { CustomButton } from "@/components/ui/custom-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/">
            <CustomButton variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </CustomButton>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Terms of Service</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-blue-600" />
              <span>Terms of Service</span>
            </CardTitle>
            <p className="text-sm text-gray-600">Last updated: January 1, 2025</p>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <section>
              <h3 className="font-semibold text-gray-900 mb-2">1. Eligibility</h3>
              <ul className="space-y-1 text-gray-600 ml-4">
                <li>• Must be 18 years or older</li>
                <li>• Must be a verified Michigan resident</li>
                <li>• Must provide valid identification</li>
                <li>• Cannot be excluded from gaming activities</li>
              </ul>
            </section>

            <section>
              <h3 className="font-semibold text-gray-900 mb-2">2. Pool Participation</h3>
              <ul className="space-y-1 text-gray-600 ml-4">
                <li>• Minimum investment: $5 per draw</li>
                <li>• Maximum investment: $500 per draw</li>
                <li>• Payments must be made before draw deadline</li>
                <li>• No refunds after draw participation</li>
              </ul>
            </section>

            <section>
              <h3 className="font-semibold text-gray-900 mb-2">3. Winnings Distribution</h3>
              <ul className="space-y-1 text-gray-600 ml-4">
                <li>• 85% of winnings distributed to winners</li>
                <li>• 10% for operational costs</li>
                <li>• 5% reserved for platform maintenance</li>
                <li>• Payouts processed within 48 hours</li>
              </ul>
            </section>

            <section>
              <h3 className="font-semibold text-gray-900 mb-2">4. Responsible Gaming</h3>
              <div className="bg-amber-50 p-3 rounded border border-amber-200">
                <div className="flex items-start space-x-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5" />
                  <div className="text-amber-700">
                    <p className="font-medium">Play Responsibly</p>
                    <p className="text-xs">Set limits, play within your means, seek help if needed.</p>
                  </div>
                </div>
              </div>
            </section>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Scale className="h-5 w-5 text-purple-600" />
              <span>Legal Compliance</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-gray-600">
            <p>
              Michigan Lotto Pool LLC operates under license #LG-2024-001 issued by the Michigan Gaming Control Board.
              All operations comply with Michigan state gaming regulations and federal anti-money laundering
              requirements.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-600" />
              <span>Data Protection</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-gray-600">
            <p>
              Your personal information is protected under Michigan privacy laws and our comprehensive privacy policy.
              We use bank-grade encryption and never sell your data to third parties.
            </p>
          </CardContent>
        </Card>

        <div className="text-center">
          <Link href="/">
            <CustomButton>Return to Home</CustomButton>
          </Link>
        </div>
      </div>
    </div>
  )
}
