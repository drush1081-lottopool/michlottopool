"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Mail, CheckCircle, AlertCircle, RefreshCw } from "lucide-react"
import Link from "next/link"

export default function EmailVerificationPage() {
  const [verificationCode, setVerificationCode] = useState("")
  const [isVerified, setIsVerified] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [resendCooldown, setResendCooldown] = useState(0)
  const [error, setError] = useState("")

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [resendCooldown])

  const handleVerify = async () => {
    if (verificationCode.length !== 6) {
      setError("Please enter a 6-digit verification code")
      return
    }

    setIsLoading(true)
    setError("")

    // Simulate verification process
    setTimeout(() => {
      if (verificationCode === "123456") {
        setIsVerified(true)
      } else {
        setError("Invalid verification code. Please try again.")
      }
      setIsLoading(false)
    }, 1500)
  }

  const handleResend = () => {
    setResendCooldown(60)
    setError("")
    // Simulate resend
  }

  if (isVerified) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-md mx-auto px-4 py-4 flex items-center">
            <Link href="/">
              <Button variant="ghost" size="icon" className="mr-3">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold text-gray-900">Email Verified</h1>
          </div>
        </header>

        <div className="max-w-md mx-auto px-4 py-12 text-center">
          <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-4">Email Verified Successfully!</h2>
          <p className="text-gray-600 mb-6">
            Your email has been verified. You'll start receiving your daily lottery numbers tomorrow morning at 8:00 AM
            EST.
          </p>

          <Card className="mb-6 text-left">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Next Steps</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                <Mail className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium text-blue-900">First Email Tomorrow</p>
                  <p className="text-sm text-blue-700">Your first daily numbers email will arrive at 8:00 AM EST</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
                <CheckCircle className="h-5 w-5 text-red-600" />
                <div>
                  <p className="font-medium text-red-900">Pool Participation Active</p>
                  <p className="text-sm text-red-700">You're now part of the Detroit Metro Pool</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            <Link href="/dashboard">
              <Button className="w-full bg-red-600 hover:bg-red-700">Go to Dashboard</Button>
            </Link>
            <Link href="/email-preferences">
              <Button variant="outline" className="w-full bg-transparent">
                Manage Email Preferences
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/email-signup">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Verify Email</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-12">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
              <Mail className="h-6 w-6 text-blue-600" />
            </div>
            <CardTitle>Check Your Email</CardTitle>
            <CardDescription>We've sent a 6-digit verification code to your email address</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-700">
                <strong>john@example.com</strong>
              </p>
              <p className="text-xs text-blue-600 mt-1">Check your inbox and spam folder</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="code">Verification Code</Label>
              <Input
                id="code"
                type="text"
                maxLength={6}
                value={verificationCode}
                onChange={(e) => {
                  setVerificationCode(e.target.value.replace(/\D/g, ""))
                  setError("")
                }}
                placeholder="123456"
                className="text-center text-lg font-mono tracking-widest"
              />
            </div>

            {error && (
              <div className="flex items-center space-x-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            <Button
              className="w-full bg-red-600 hover:bg-red-700"
              onClick={handleVerify}
              disabled={isLoading || verificationCode.length !== 6}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Verifying...
                </>
              ) : (
                "Verify Email"
              )}
            </Button>

            <div className="text-center">
              <p className="text-sm text-gray-600 mb-2">Didn't receive the code?</p>
              <Button
                variant="outline"
                size="sm"
                onClick={handleResend}
                disabled={resendCooldown > 0}
                className="bg-transparent"
              >
                {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : "Resend Code"}
              </Button>
            </div>

            <div className="text-center text-xs text-gray-500">The verification code expires in 10 minutes</div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
