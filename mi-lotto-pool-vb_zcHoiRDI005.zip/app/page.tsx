"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { CustomButton } from "@/components/ui/custom-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import MichiganLogo from "@/components/ui/michigan-logo"
import LotteryNumberDisplay from "@/components/ui/lottery-number-display"
import StatsCard from "@/components/ui/stats-card"
import ProgressRing from "@/components/ui/progress-ring"
import TrustIndicators from "@/components/ui/trust-indicators"
import ResponsibleGaming from "@/components/ui/responsible-gaming"
import LegalCompliance from "@/components/ui/legal-compliance"
import PayoutTransparency from "@/components/ui/payout-transparency"
import SecurityFeatures from "@/components/ui/security-features"
import CustomerSupport from "@/components/ui/customer-support"
import {
  Users,
  DollarSign,
  Mail,
  Trophy,
  Shield,
  Star,
  Zap,
  Target,
  TrendingUp,
  MapPin,
  CheckCircle,
  AlertTriangle,
  Info,
  Award,
} from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showNumbers, setShowNumbers] = useState(false)
  const [currentStats, setCurrentStats] = useState({
    totalMembers: 12847,
    totalPools: 156,
    totalWinnings: 2847392,
    activeDraws: 8,
    avgPayout: 1250,
    successRate: 94.2,
  })

  const sampleNumbers = ["1234", "5678", "9012", "3456", "7890"]

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowNumbers(true)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      alert("Please enter a valid email address")
      setIsLoading(false)
      return
    }

    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsLoading(false)
    window.location.href = "/email-signup"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 michigan-pattern">
      <header className="glass border-b-2 border-white/30 sticky top-0 z-50">
        <div className="max-w-2xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <MichiganLogo size="lg" animated />
            <div className="flex items-center space-x-3">
              <Link href="/help">
                <CustomButton variant="outline" size="lg">
                  <Info className="h-5 w-5 mr-2" />
                  Help
                </CustomButton>
              </Link>
              <Badge
                variant="secondary"
                className="bg-gradient-to-r from-red-500 to-blue-500 text-white border-0 text-base px-4 py-2"
              >
                <MapPin className="h-5 w-5 mr-2" />
                Michigan Licensed
              </Badge>
            </div>
          </div>

          <div className="flex justify-center space-x-6 text-base text-gray-700 font-semibold">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-600" />
              <span>100% Secure</span>
            </div>
            <div className="flex items-center space-x-2">
              <Award className="h-5 w-5 text-blue-600" />
              <span>State Licensed</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-purple-600" />
              <span>Verified Safe</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-6 py-8">
        {/* Trust Indicators Section */}
        <div className="mb-8">
          <TrustIndicators />
        </div>

        <div className="text-center mb-12 space-y-8">
          <div className="relative">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-red-600 via-blue-600 to-red-600 bg-clip-text text-transparent mb-6 leading-tight">
              Michigan's Most Trusted Lottery Pool
            </h1>
          </div>

          <Card className="card-gradient border-3 mb-8">
            <CardContent className="py-8">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <Target className="h-8 w-8 text-red-600" />
                <h2 className="text-3xl font-bold text-gray-900">How It Works</h2>
              </div>
              <div className="space-y-4 text-left">
                <p className="text-xl text-gray-800 leading-relaxed font-medium">
                  <strong className="text-red-600">Our Purpose:</strong> We pool together up to 5,000 Michigan members
                  to cover every possible 4-digit lottery combination (0000-9999). With all 10,000 combinations covered,
                  we win $10,000 every single day!
                </p>
                <p className="text-xl text-gray-800 leading-relaxed font-medium">
                  <strong className="text-blue-600">Democratic Distribution:</strong> As a group, we vote on how to
                  distribute the daily winnings to members. This builds a community bank that grows to $3.65 million per
                  year.
                </p>
                <p className="text-xl text-gray-800 leading-relaxed font-medium">
                  <strong className="text-green-600">Everyone Wins Together:</strong> This gives people who never really
                  hit the lottery or play to win big a real chance at winning as part of our group. When we win,
                  everyone wins!
                </p>
              </div>
              <div className="mt-6 bg-yellow-50 p-4 rounded-xl border-2 border-yellow-300">
                <div className="flex items-center justify-center space-x-2">
                  <Trophy className="h-6 w-6 text-yellow-600" />
                  <p className="text-lg font-bold text-gray-900">
                    Goal: $10,000/day = $3.65 Million/year for the community
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="my-12 bg-white rounded-2xl p-8 shadow-xl border-2 border-gray-200">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <Info className="h-6 w-6 text-blue-600" />
              <p className="text-xl font-semibold text-gray-700">Today's Sample Numbers:</p>
            </div>
            <LotteryNumberDisplay numbers={sampleNumbers} size="lg" variant="default" showAnimation={showNumbers} />
            <p className="text-base text-gray-600 mt-4 font-medium">Actual numbers sent daily at 8:00 AM</p>
          </div>

          <div className="space-y-6">
            <Link href="/register">
              <CustomButton size="xl" className="w-full senior-friendly-button" icon={<Trophy className="h-6 w-6" />}>
                Join Pool - Only $5 to Start
              </CustomButton>
            </Link>

            <Link href="/email-signup">
              <CustomButton
                variant="success"
                size="xl"
                className="w-full senior-friendly-button"
                icon={<Mail className="h-6 w-6" />}
              >
                Get Free Numbers First - No Payment
              </CustomButton>
            </Link>

            <Link href="/login">
              <CustomButton variant="outline" size="xl" className="w-full senior-friendly-button">
                Already a Member? Sign In
              </CustomButton>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <StatsCard
            title="Verified Members"
            value={currentStats.totalMembers.toLocaleString()}
            subtitle="Michigan residents"
            icon={Users}
            trend={{ value: 12, label: "vs last month", positive: true }}
            variant="default"
            animated
          />
          <StatsCard
            title="Total Paid Out"
            value={`$${(currentStats.totalWinnings / 1000000).toFixed(1)}M`}
            subtitle="To winners"
            icon={DollarSign}
            trend={{ value: 8, label: "this quarter", positive: true }}
            variant="success"
            animated
          />
        </div>

        {/* Payout Transparency */}
        <div className="mb-8">
          <PayoutTransparency />
        </div>

        <Card className="card-gradient mb-8">
          <CardHeader className="text-center pb-4">
            <CardTitle className="flex items-center justify-center space-x-3 text-2xl">
              <Target className="h-7 w-7 text-red-600" />
              <span>Current Pool Status</span>
            </CardTitle>
            <p className="text-lg text-gray-700 font-medium mt-2">Detroit Metro Pool (Largest)</p>
          </CardHeader>
          <CardContent className="flex justify-center">
            <ProgressRing progress={75} size={160} color="#c41e3a" showPercentage={false} animated>
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600">3,785</div>
                <div className="text-base text-gray-600 font-medium">of 5,000</div>
                <div className="text-base text-green-600 font-bold mt-1">1,215 spots left</div>
              </div>
            </ProgressRing>
          </CardContent>
        </Card>

        <div className="space-y-6 mb-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">Why People Trust Us</h2>

          <Card className="card-custom">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center space-x-4 text-xl">
                <div className="p-3 bg-gradient-to-br from-red-500 to-blue-600 rounded-xl">
                  <Users className="h-7 w-7 text-white" />
                </div>
                <span>Michigan State Licensed</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4 text-lg leading-relaxed">
                We are fully licensed by the Michigan Gaming Control Board. Your money and winnings are protected by
                state law.
              </p>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="text-base text-green-700 font-bold">License #LG-2024-001 (Verified)</span>
              </div>
            </CardContent>
          </Card>

          <Card className="card-custom">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center space-x-4 text-xl">
                <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl">
                  <DollarSign className="h-7 w-7 text-white" />
                </div>
                <span>Guaranteed Payouts</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4 text-lg leading-relaxed">
                85% of all winnings go directly to winners. We guarantee 100% payout with escrow protection for your
                money.
              </p>
              <div className="flex items-center space-x-3">
                <TrendingUp className="h-6 w-6 text-green-600" />
                <span className="text-base text-green-700 font-bold">$2.8 Million Paid Out Successfully</span>
              </div>
            </CardContent>
          </Card>

          <Card className="card-custom">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center space-x-4 text-xl">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                  <Shield className="h-7 w-7 text-white" />
                </div>
                <span>Bank-Level Security</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4 text-lg leading-relaxed">
                Your information is protected with the same security technology that banks use. We verify every member's
                identity.
              </p>
              <div className="flex items-center space-x-3">
                <Shield className="h-6 w-6 text-blue-600" />
                <span className="text-base text-blue-700 font-bold">Bank-Grade 256-bit Encryption</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Security Features */}
        <div className="mb-8">
          <SecurityFeatures />
        </div>

        <Card className="card-gradient mb-8">
          <CardHeader className="text-center pb-4">
            <CardTitle className="flex items-center justify-center space-x-3 text-2xl">
              <Zap className="h-7 w-7 text-yellow-600" />
              <span>Start Risk-Free Today</span>
            </CardTitle>
            <p className="text-gray-700 text-lg font-medium mt-2">
              Get daily numbers • No payment required • Cancel anytime
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleEmailSignup} className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="email" className="senior-friendly-label">
                  Your Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="yourname@email.com"
                  className="input-custom text-lg"
                  required
                />
                <p className="text-base text-gray-600 font-medium">
                  We'll verify you're a Michigan resident during signup
                </p>
              </div>
              <CustomButton
                type="submit"
                className="w-full senior-friendly-button"
                loading={isLoading}
                icon={!isLoading ? <Star className="h-6 w-6" /> : undefined}
              >
                {isLoading ? "Checking Email..." : "Get Free Daily Numbers Now"}
              </CustomButton>
              <p className="text-base text-center text-gray-600 font-medium">
                ✓ No spam ever ✓ Unsubscribe anytime ✓ Michigan residents only
              </p>
            </form>
          </CardContent>
        </Card>

        {/* Customer Support */}
        <div className="mb-8">
          <CustomerSupport />
        </div>

        {/* Legal Compliance */}
        <div className="mb-8">
          <LegalCompliance />
        </div>

        {/* Responsible Gaming */}
        <div className="mb-8">
          <ResponsibleGaming />
        </div>

        <div className="text-center space-y-4 text-base text-gray-700 font-medium border-t-2 border-gray-300 pt-8">
          <div className="flex items-center justify-center space-x-6">
            <Link href="/help" className="hover:text-red-600 text-lg font-semibold">
              Help Center
            </Link>
            <Link href="/terms" className="hover:text-red-600 text-lg font-semibold">
              Terms of Service
            </Link>
            <Link href="/privacy" className="hover:text-red-600 text-lg font-semibold">
              Privacy Policy
            </Link>
            <Link href="/responsible-gaming" className="hover:text-red-600 text-lg font-semibold">
              Responsible Gaming
            </Link>
          </div>
          <p className="text-lg">© 2025 Michigan Lotto Pool LLC</p>
          <p className="text-lg">Licensed by Michigan Gaming Control Board</p>
          <p className="text-lg font-semibold">License #LG-2024-001</p>
          <p className="text-lg">Must be 18+ and Michigan resident to participate</p>
          <div className="flex items-center justify-center space-x-2 bg-yellow-50 p-4 rounded-xl border-2 border-yellow-300 mt-4">
            <AlertTriangle className="h-6 w-6 text-amber-600" />
            <span className="text-lg font-bold text-gray-800">Gambling problem? Call 1-800-270-7117 for help</span>
          </div>
        </div>
      </div>
    </div>
  )
}
