"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, CreditCard, DollarSign, Clock, CheckCircle, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function PaymentsPage() {
  const [paymentMethod, setPaymentMethod] = useState("")
  const [amount, setAmount] = useState("")

  const paymentHistory = [
    {
      id: 1,
      date: "Jan 5, 2025",
      amount: 50,
      pool: "Detroit Metro Pool",
      status: "completed",
      method: "Credit Card",
      numbers: 10,
    },
    {
      id: 2,
      date: "Jan 1, 2025",
      amount: 25,
      pool: "Grand Rapids Winners",
      status: "completed",
      method: "Bank Transfer",
      numbers: 5,
    },
    {
      id: 3,
      date: "Dec 28, 2024",
      amount: 75,
      pool: "Detroit Metro Pool",
      status: "pending",
      method: "Credit Card",
      numbers: 15,
    },
  ]

  const pendingPayments = [
    {
      pool: "Detroit Metro Pool",
      amount: 50,
      dueDate: "Jan 8, 2025",
      numbers: 10,
      priority: "high",
    },
    {
      pool: "Grand Rapids Winners",
      amount: 25,
      dueDate: "Jan 10, 2025",
      numbers: 5,
      priority: "medium",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      case "failed":
        return <Badge className="bg-red-100 text-red-800">Failed</Badge>
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge className="bg-red-100 text-red-800">High Priority</Badge>
      case "medium":
        return <Badge className="bg-blue-100 text-blue-800">Medium</Badge>
      case "low":
        return <Badge className="bg-gray-100 text-gray-800">Low</Badge>
      default:
        return <Badge variant="secondary">Normal</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Payments</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="pay">Make Payment</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Pending Payments</h2>
              <Badge variant="secondary">{pendingPayments.length} due</Badge>
            </div>

            {pendingPayments.map((payment, index) => (
              <Card key={index} className="border-l-4 border-l-red-500">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{payment.pool}</CardTitle>
                    {getPriorityBadge(payment.priority)}
                  </div>
                  <CardDescription>Due: {payment.dueDate}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <div>
                        <p className="text-sm text-gray-600">Amount Due</p>
                        <p className="text-xl font-bold text-red-600">${payment.amount}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Numbers</p>
                      <p className="text-xl font-bold text-blue-600">{payment.numbers}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 p-3 bg-red-50 rounded-lg">
                    <Clock className="h-4 w-4 text-red-600" />
                    <p className="text-sm text-red-700">Payment required to participate in next draw</p>
                  </div>

                  <Button className="w-full bg-red-600 hover:bg-red-700">Pay ${payment.amount} Now</Button>
                </CardContent>
              </Card>
            ))}

            {pendingPayments.length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">All Caught Up!</h3>
                  <p className="text-gray-600">You have no pending payments at this time.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="pay" className="space-y-4 mt-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Make a Payment</CardTitle>
                <CardDescription>Add funds to your pool participation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="pool">Select Pool</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose pool" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="detroit">Detroit Metro Pool</SelectItem>
                      <SelectItem value="grandrapids">Grand Rapids Winners</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="amount">Payment Amount</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="amount"
                      type="number"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <p className="text-xs text-gray-500">Minimum: $5.00 • Maximum: $500.00</p>
                </div>

                <div className="space-y-2">
                  <Label>Payment Method</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="payment"
                        value="card"
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className="text-red-600"
                      />
                      <CreditCard className="h-4 w-4 text-blue-600" />
                      <div className="flex-1">
                        <p className="font-medium">Credit/Debit Card</p>
                        <p className="text-sm text-gray-600">Instant processing</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="payment"
                        value="bank"
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className="text-red-600"
                      />
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <div className="flex-1">
                        <p className="font-medium">Bank Transfer (ACH)</p>
                        <p className="text-sm text-gray-600">1-3 business days</p>
                      </div>
                    </div>
                  </div>
                </div>

                {paymentMethod === "card" && (
                  <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
                    <div className="space-y-2">
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input id="cardNumber" placeholder="1234 5678 9012 3456" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="expiry">Expiry Date</Label>
                        <Input id="expiry" placeholder="MM/YY" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cvv">CVV</Label>
                        <Input id="cvv" placeholder="123" />
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === "bank" && (
                  <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
                    <div className="space-y-2">
                      <Label htmlFor="routing">Routing Number</Label>
                      <Input id="routing" placeholder="123456789" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="account">Account Number</Label>
                      <Input id="account" placeholder="1234567890" />
                    </div>
                  </div>
                )}

                <Button className="w-full bg-red-600 hover:bg-red-700" disabled={!amount || !paymentMethod}>
                  Process Payment
                </Button>
              </CardContent>
            </Card>

            {/* Security Notice */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-blue-900">Secure Payment Processing</p>
                    <p className="text-sm text-blue-700">
                      All payments are processed securely with 256-bit SSL encryption. Your financial information is
                      never stored on our servers.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Payment History</h2>
              <Badge variant="secondary">{paymentHistory.length} payments</Badge>
            </div>

            {paymentHistory.map((payment) => (
              <Card key={payment.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex-1">
                      <p className="font-medium">{payment.pool}</p>
                      <p className="text-sm text-gray-600">{payment.date}</p>
                    </div>
                    {getStatusBadge(payment.status)}
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Amount</p>
                      <p className="font-bold text-green-600">${payment.amount}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Method</p>
                      <p className="font-medium">{payment.method}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Numbers</p>
                      <p className="font-medium">{payment.numbers}</p>
                    </div>
                  </div>

                  {payment.status === "pending" && (
                    <div className="mt-3 flex items-center space-x-2 p-2 bg-yellow-50 rounded">
                      <AlertCircle className="h-4 w-4 text-yellow-600" />
                      <p className="text-sm text-yellow-700">Processing - may take 1-3 business days</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}

            <div className="text-center py-4">
              <Button variant="outline">Load More History</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
