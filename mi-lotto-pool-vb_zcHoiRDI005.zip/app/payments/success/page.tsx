"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Download, Mail, ArrowRight, Bitcoin } from "lucide-react"
import Link from "next/link"

export default function PaymentSuccessPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      <div className="max-w-md mx-auto px-4 py-12">
        {/* Success Icon */}
        <div className="text-center mb-8">
          <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h1>
          <p className="text-gray-600">Your payment has been processed successfully</p>
        </div>

        {/* Payment Details */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Payment Details</CardTitle>
            <CardDescription>Transaction completed on Jan 7, 2025</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600">Amount Paid</p>
                <p className="text-2xl font-bold text-green-600">$50.00</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Numbers Assigned</p>
                <p className="text-2xl font-bold text-blue-600">10</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Pool:</span>
                <span className="font-medium">Detroit Metro Pool</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Payment Method:</span>
                <span className="font-medium">Credit Card ****1234</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Transaction ID:</span>
                <span className="font-medium">TXN-2025-001234</span>
              </div>
            </div>

            <Badge className="w-full justify-center bg-green-100 text-green-800">Payment Confirmed</Badge>
          </CardContent>
        </Card>

        <Card className="mb-6 bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Bitcoin className="h-5 w-5 text-orange-500" />
              <span>Maximize Your Winnings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-gray-700">
              Convert any future winnings to Bitcoin automatically and potentially increase your profits over time.
            </p>
            <div className="p-3 bg-white/80 rounded text-xs">
              <p className="font-medium text-gray-900 mb-1">Example: $1,000 winning</p>
              <p className="text-gray-600">If BTC increases 25% → You gain extra $250</p>
            </div>
            <Link href="/settings/crypto-settings">
              <Button className="w-full bg-orange-600 hover:bg-orange-700">
                <Bitcoin className="h-4 w-4 mr-2" />
                Setup Auto-Conversion
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Next Steps */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">What's Next?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
              <Mail className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">Numbers Email Sent</p>
                <p className="text-sm text-blue-700">Your 10 lottery numbers have been emailed to you</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
              <CheckCircle className="h-5 w-5 text-red-600" />
              <div>
                <p className="font-medium text-red-900">Ready for Next Draw</p>
                <p className="text-sm text-red-700">You're all set for the January 8, 2025 draw</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="space-y-3">
          <Link href="/pools/1/numbers">
            <Button className="w-full bg-red-600 hover:bg-red-700">
              View My Numbers
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="bg-transparent">
              <Download className="h-4 w-4 mr-2" />
              Receipt
            </Button>
            <Link href="/dashboard">
              <Button variant="outline" className="w-full bg-transparent">
                Dashboard
              </Button>
            </Link>
          </div>
        </div>

        {/* Support */}
        <div className="text-center mt-8 p-4 bg-white rounded-lg">
          <p className="text-sm text-gray-600 mb-2">Need help with your payment?</p>
          <Link href="/support" className="text-red-600 hover:underline text-sm font-medium">
            Contact Support
          </Link>
        </div>
      </div>
    </div>
  )
}
