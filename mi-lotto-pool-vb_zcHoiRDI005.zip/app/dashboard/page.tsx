"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Users,
  DollarSign,
  Plus,
  Settings,
  Trophy,
  Calendar,
  Bell,
  Mail,
  Grid3x3,
  Bitcoin,
  Share2,
  HelpCircle,
} from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  const userPools = [
    {
      id: 1,
      name: "Detroit Metro Pool",
      members: 2847,
      maxMembers: 5000,
      status: "active",
      nextDraw: "2025-01-08",
      yourNumbers: ["1234", "5678", "9012"],
      totalInvested: 150,
      potentialWinning: 25000,
    },
    {
      id: 2,
      name: "Grand Rapids Winners",
      members: 1523,
      maxMembers: 3000,
      status: "active",
      nextDraw: "2025-01-08",
      yourNumbers: ["3456", "7890"],
      totalInvested: 100,
      potentialWinning: 15000,
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b-2">
        <div className="max-w-2xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Trophy className="h-8 w-8 text-red-600" />
            <h1 className="text-2xl font-bold text-gray-900">My Dashboard</h1>
          </div>
          <div className="flex items-center space-x-3">
            <Link href="/help">
              <Button variant="ghost" size="lg" className="min-w-[60px] min-h-[60px]">
                <HelpCircle className="h-7 w-7" />
              </Button>
            </Link>
            <Button variant="ghost" size="lg" className="min-w-[60px] min-h-[60px]">
              <Bell className="h-7 w-7" />
            </Button>
            <Link href="/settings/social-accounts">
              <Button variant="ghost" size="lg" className="min-w-[60px] min-h-[60px]">
                <Share2 className="h-7 w-7" />
              </Button>
            </Link>
            <Link href="/settings">
              <Button variant="ghost" size="lg" className="min-w-[60px] min-h-[60px]">
                <Settings className="h-7 w-7" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-6 py-8">
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-3 border-blue-300 mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                  <HelpCircle className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Need Help?</h3>
                  <p className="text-lg text-gray-700">Learn how to navigate the app</p>
                </div>
              </div>
              <Link href="/help">
                <Button size="lg" className="senior-friendly-button bg-blue-600 hover:bg-blue-700">
                  View Help Center
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 h-16 text-lg font-semibold">
            <TabsTrigger value="overview" className="text-base">
              Overview
            </TabsTrigger>
            <TabsTrigger value="pools" className="text-base">
              My Pools
            </TabsTrigger>
            <TabsTrigger value="voting" className="text-base">
              Voting
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-2">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-3">
                    <Users className="h-7 w-7 text-red-600" />
                    <span className="text-lg font-semibold text-gray-700">Active Pools</span>
                  </div>
                  <p className="text-4xl font-bold text-gray-900">2</p>
                </CardContent>
              </Card>
              <Card className="border-2">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-3">
                    <DollarSign className="h-7 w-7 text-green-600" />
                    <span className="text-lg font-semibold text-gray-700">Total Invested</span>
                  </div>
                  <p className="text-4xl font-bold text-gray-900">$250</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 border-2 border-orange-300">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center space-x-3 text-2xl">
                  <Bitcoin className="h-7 w-7 text-orange-600" />
                  <span>Bitcoin Conversion</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-lg font-semibold text-gray-700">Auto-Convert Status</p>
                      <p className="text-xl font-bold">Not Active</p>
                    </div>
                    <Badge className="bg-orange-200 text-orange-900 text-base px-4 py-2">Setup Required</Badge>
                  </div>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    Maximize your profits by automatically converting winnings to Bitcoin
                  </p>
                  <Link href="/settings/crypto-settings">
                    <Button className="w-full senior-friendly-button bg-orange-600 hover:bg-orange-700">
                      <Bitcoin className="h-6 w-6 mr-2" />
                      Setup Bitcoin Conversion
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center space-x-3 text-2xl">
                  <Mail className="h-7 w-7 text-blue-600" />
                  <span>Email Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-4">
                  <p className="text-2xl font-bold text-gray-900">Emails Sent Today</p>
                  <p className="text-3xl font-bold text-gray-700">5 / 5</p>
                  <Badge className="text-lg px-6 py-3 bg-green-100 text-green-800 font-bold">All Emails Sent</Badge>
                  <Link href="/settings/email-preferences">
                    <Button variant="outline" size="lg" className="mt-4 senior-friendly-button bg-transparent">
                      Change Email Settings
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center space-x-3 text-2xl">
                  <Calendar className="h-7 w-7 text-blue-600" />
                  <span>Next Draw Date</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-4">
                  <p className="text-4xl font-bold text-gray-900">Jan 8, 2025</p>
                  <p className="text-2xl text-gray-700 font-semibold">2 days remaining</p>
                  <Badge className="text-lg px-6 py-3 bg-green-100 text-green-800 font-bold">
                    All Numbers Distributed
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader className="pb-4">
                <CardTitle className="text-2xl">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="flex items-center space-x-4">
                  <div className="w-4 h-4 bg-red-600 rounded-full flex-shrink-0"></div>
                  <div className="flex-1">
                    <p className="text-lg font-semibold">Numbers distributed for Detroit Metro Pool</p>
                    <p className="text-base text-gray-600">2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-4 h-4 bg-green-600 rounded-full flex-shrink-0"></div>
                  <div className="flex-1">
                    <p className="text-lg font-semibold">Payment confirmed - $50</p>
                    <p className="text-base text-gray-600">1 day ago</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-4 h-4 bg-blue-600 rounded-full flex-shrink-0"></div>
                  <div className="flex-1">
                    <p className="text-lg font-semibold">New vote: Pool management changes</p>
                    <p className="text-base text-gray-600">2 days ago</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pools" className="space-y-6 mt-8">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">My Pools</h2>
              <Link href="/pools/join">
                <Button size="lg" className="senior-friendly-button">
                  <Plus className="h-6 w-6 mr-2" />
                  Join Pool
                </Button>
              </Link>
            </div>

            {userPools.map((pool) => (
              <Card key={pool.id} className="border-2">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-2xl">{pool.name}</CardTitle>
                    <Badge variant={pool.status === "active" ? "default" : "secondary"} className="text-lg px-4 py-2">
                      {pool.status}
                    </Badge>
                  </div>
                  <CardDescription className="text-lg mt-2">
                    {pool.members.toLocaleString()} / {pool.maxMembers.toLocaleString()} members
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Progress value={(pool.members / pool.maxMembers) * 100} className="h-3" />

                  <div className="grid grid-cols-2 gap-6 text-lg">
                    <div>
                      <p className="text-gray-600 font-semibold">Your Numbers</p>
                      <p className="font-bold text-xl">{pool.yourNumbers.length} assigned</p>
                    </div>
                    <div>
                      <p className="text-gray-600 font-semibold">Invested</p>
                      <p className="font-bold text-xl">${pool.totalInvested}</p>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Link href={`/pools/${pool.id}`} className="flex-1">
                        <Button variant="outline" className="w-full senior-friendly-button bg-transparent">
                          View Details
                        </Button>
                      </Link>
                      <Link href={`/pools/${pool.id}/numbers`} className="flex-1">
                        <Button className="w-full senior-friendly-button">My Numbers</Button>
                      </Link>
                    </div>
                    <Link href={`/pools/${pool.id}/all-combinations`} className="w-full">
                      <Button variant="outline" className="w-full senior-friendly-button bg-transparent">
                        <Grid3x3 className="h-6 w-6 mr-2" />
                        View All Combinations
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="voting" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Active Votes</h2>
              <Badge variant="secondary">3 pending</Badge>
            </div>

            {/* Fund Distribution Vote */}
            <Card className="border-l-red-500">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Fund Distribution Method</CardTitle>
                  <Badge className="bg-red-100 text-red-800">High Priority</Badge>
                </div>
                <CardDescription>Detroit Metro Pool • Ends in 2 days</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Vote on how winning funds should be distributed among pool members for the next 6 months.
                </p>

                <div className="space-y-3">
                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Equal Split (Current)</span>
                      <span className="text-sm text-gray-600">1,456 votes (51%)</span>
                    </div>
                    <Progress value={51} className="h-2 mb-2" />
                    <p className="text-xs text-gray-600">All winnings split equally among all members</p>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Investment-Based</span>
                      <span className="text-sm text-gray-600">892 votes (31%)</span>
                    </div>
                    <Progress value={31} className="h-2 mb-2" />
                    <p className="text-xs text-gray-600">Distribution based on individual investment amounts</p>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Hybrid Model</span>
                      <span className="text-sm text-gray-600">499 votes (18%)</span>
                    </div>
                    <Progress value={18} className="h-2 mb-2" />
                    <p className="text-xs text-gray-600">50% equal split, 50% investment-based</p>
                  </div>
                </div>

                <Link href="/voting/fund-distribution">
                  <Button className="w-full">View Details & Vote</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Pool Management Vote */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Pool Management Changes</CardTitle>
                <CardDescription>Detroit Metro Pool • Ends in 3 days</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Proposal to change the minimum investment amount from $5 to $10 per draw to increase potential
                  winnings.
                </p>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Yes (1,234 votes)</span>
                    <span>43%</span>
                  </div>
                  <Progress value={43} className="h-2" />
                  <div className="flex justify-between text-sm">
                    <span>No (1,613 votes)</span>
                    <span>57%</span>
                  </div>
                  <Progress value={57} className="h-2" />
                </div>

                <div className="flex space-x-2">
                  <Button variant="outline" className="flex-1 bg-transparent">
                    Vote No
                  </Button>
                  <Button className="flex-1">Vote Yes</Button>
                </div>

                <p className="text-xs text-gray-500 text-center">Voting ends in 3 days</p>
              </CardContent>
            </Card>

            {/* Administrator Vote */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">New Pool Administrator</CardTitle>
                <CardDescription>Grand Rapids Winners • Ends in 5 days</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Vote for the new pool administrator to replace the current one who is stepping down.
                </p>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Sarah Johnson</p>
                      <p className="text-sm text-gray-600">5 years experience</p>
                    </div>
                    <Button size="sm">Vote</Button>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Mike Chen</p>
                      <p className="text-sm text-gray-600">3 years experience</p>
                    </div>
                    <Button size="sm" variant="outline">
                      Vote
                    </Button>
                  </div>
                </div>

                <p className="text-xs text-gray-500 text-center">Voting ends in 5 days</p>
              </CardContent>
            </Card>

            {/* Create Vote CTA */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-blue-900">Propose New Vote</h3>
                    <p className="text-sm text-blue-700">Create a new community vote</p>
                  </div>
                  <Link href="/voting/create">
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Create Vote
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
