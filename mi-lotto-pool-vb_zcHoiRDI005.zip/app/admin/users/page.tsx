"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Users,
  Search,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  Ban,
  UserCheck,
  Download,
  Shield,
  Calendar,
  Mail,
  Phone,
  MapPin,
} from "lucide-react"
import Link from "next/link"

interface User {
  id: string
  firstName: string
  lastName: string
  email: string
  phone: string
  city: string
  county: string
  status: "pending" | "verified" | "rejected" | "suspended"
  joinedDate: string
  lastActive: string
  totalInvestment: number
  totalWinnings: number
  poolsJoined: number
  verificationLevel: "none" | "email" | "identity" | "full"
}

export default function AdminUsersPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [verificationFilter, setVerificationFilter] = useState<string>("all")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)

  // Mock user data
  const users: User[] = [
    {
      id: "1",
      firstName: "John",
      lastName: "Smith",
      email: "john.smith@email.com",
      phone: "(313) 555-0123",
      city: "Detroit",
      county: "Wayne",
      status: "verified",
      joinedDate: "2025-01-15",
      lastActive: "2025-01-20",
      totalInvestment: 250,
      totalWinnings: 0,
      poolsJoined: 3,
      verificationLevel: "full",
    },
    {
      id: "2",
      firstName: "Sarah",
      lastName: "Johnson",
      email: "sarah.j@email.com",
      phone: "(248) 555-0456",
      city: "Troy",
      county: "Oakland",
      status: "pending",
      joinedDate: "2025-01-19",
      lastActive: "2025-01-21",
      totalInvestment: 0,
      totalWinnings: 0,
      poolsJoined: 0,
      verificationLevel: "email",
    },
    {
      id: "3",
      firstName: "Michael",
      lastName: "Williams",
      email: "m.williams@email.com",
      phone: "(734) 555-0789",
      city: "Ann Arbor",
      county: "Washtenaw",
      status: "verified",
      joinedDate: "2025-01-10",
      lastActive: "2025-01-21",
      totalInvestment: 500,
      totalWinnings: 1200,
      poolsJoined: 5,
      verificationLevel: "full",
    },
    {
      id: "4",
      firstName: "Emily",
      lastName: "Davis",
      email: "emily.d@email.com",
      phone: "(517) 555-0321",
      city: "Lansing",
      county: "Ingham",
      status: "rejected",
      joinedDate: "2025-01-18",
      lastActive: "2025-01-18",
      totalInvestment: 0,
      totalWinnings: 0,
      poolsJoined: 0,
      verificationLevel: "identity",
    },
    {
      id: "5",
      firstName: "David",
      lastName: "Brown",
      email: "d.brown@email.com",
      phone: "(616) 555-0654",
      city: "Grand Rapids",
      county: "Kent",
      status: "suspended",
      joinedDate: "2024-12-05",
      lastActive: "2025-01-15",
      totalInvestment: 1200,
      totalWinnings: 350,
      poolsJoined: 8,
      verificationLevel: "full",
    },
  ]

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || user.status === statusFilter
    const matchesVerification = verificationFilter === "all" || user.verificationLevel === verificationFilter
    return matchesSearch && matchesStatus && matchesVerification
  })

  const stats = {
    total: users.length,
    verified: users.filter((u) => u.status === "verified").length,
    pending: users.filter((u) => u.status === "pending").length,
    rejected: users.filter((u) => u.status === "rejected").length,
    suspended: users.filter((u) => u.status === "suspended").length,
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "verified":
        return (
          <Badge className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Verified
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        )
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-800">
            <XCircle className="h-3 w-3 mr-1" />
            Rejected
          </Badge>
        )
      case "suspended":
        return (
          <Badge className="bg-gray-100 text-gray-800">
            <Ban className="h-3 w-3 mr-1" />
            Suspended
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getVerificationBadge = (level: string) => {
    switch (level) {
      case "full":
        return <Badge className="bg-blue-100 text-blue-800">Full KYC</Badge>
      case "identity":
        return <Badge className="bg-purple-100 text-purple-800">ID Only</Badge>
      case "email":
        return <Badge className="bg-gray-100 text-gray-800">Email Only</Badge>
      default:
        return <Badge variant="outline">None</Badge>
    }
  }

  const handleExportUsers = () => {
    // Export to CSV logic
    const csv = [
      [
        "ID",
        "Name",
        "Email",
        "Phone",
        "City",
        "County",
        "Status",
        "Verification",
        "Joined",
        "Investment",
        "Winnings",
      ].join(","),
      ...filteredUsers.map((u) =>
        [
          u.id,
          `${u.firstName} ${u.lastName}`,
          u.email,
          u.phone,
          u.city,
          u.county,
          u.status,
          u.verificationLevel,
          u.joinedDate,
          u.totalInvestment,
          u.totalWinnings,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `users-export-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">User Management</h1>
            <p className="text-gray-600">Manage and monitor all Michigan Lotto Pool members</p>
          </div>
          <Link href="/admin">
            <CustomButton variant="outline">
              <Shield className="h-4 w-4 mr-2" />
              Admin Dashboard
            </CustomButton>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
                <Users className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Verified</p>
                  <p className="text-2xl font-bold text-green-600">{stats.verified}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Rejected</p>
                  <p className="text-2xl font-bold text-red-600">{stats.rejected}</p>
                </div>
                <XCircle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Suspended</p>
                  <p className="text-2xl font-bold text-gray-600">{stats.suspended}</p>
                </div>
                <Ban className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by name or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
              <Select value={verificationFilter} onValueChange={setVerificationFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by verification" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="full">Full KYC</SelectItem>
                  <SelectItem value="identity">ID Only</SelectItem>
                  <SelectItem value="email">Email Only</SelectItem>
                  <SelectItem value="none">None</SelectItem>
                </SelectContent>
              </Select>
              <CustomButton onClick={handleExportUsers}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </CustomButton>
            </div>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card>
          <CardHeader>
            <CardTitle>Users ({filteredUsers.length})</CardTitle>
            <CardDescription>View and manage user accounts and verification status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Verification</TableHead>
                    <TableHead>Activity</TableHead>
                    <TableHead>Financials</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">
                            {user.firstName} {user.lastName}
                          </p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                          <p className="text-xs text-gray-400">{user.phone}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <p className="font-medium">{user.city}</p>
                          <p className="text-gray-500">{user.county} County</p>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(user.status)}</TableCell>
                      <TableCell>{getVerificationBadge(user.verificationLevel)}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <p>Joined: {new Date(user.joinedDate).toLocaleDateString()}</p>
                          <p className="text-gray-500">Last: {new Date(user.lastActive).toLocaleDateString()}</p>
                          <p className="text-blue-600">{user.poolsJoined} pools</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <p className="text-red-600">${user.totalInvestment} invested</p>
                          <p className="text-green-600">${user.totalWinnings} won</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <CustomButton variant="outline" size="sm" onClick={() => setSelectedUser(user)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View
                            </CustomButton>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>
                                {selectedUser?.firstName} {selectedUser?.lastName}
                              </DialogTitle>
                              <DialogDescription>User details and verification information</DialogDescription>
                            </DialogHeader>
                            {selectedUser && (
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-sm text-gray-500">Status</p>
                                    {getStatusBadge(selectedUser.status)}
                                  </div>
                                  <div>
                                    <p className="text-sm text-gray-500">Verification Level</p>
                                    {getVerificationBadge(selectedUser.verificationLevel)}
                                  </div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-sm text-gray-500 flex items-center">
                                      <Mail className="h-4 w-4 mr-1" />
                                      Email
                                    </p>
                                    <p className="font-medium">{selectedUser.email}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-gray-500 flex items-center">
                                      <Phone className="h-4 w-4 mr-1" />
                                      Phone
                                    </p>
                                    <p className="font-medium">{selectedUser.phone}</p>
                                  </div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-sm text-gray-500 flex items-center">
                                      <MapPin className="h-4 w-4 mr-1" />
                                      Location
                                    </p>
                                    <p className="font-medium">
                                      {selectedUser.city}, {selectedUser.county} County
                                    </p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-gray-500 flex items-center">
                                      <Calendar className="h-4 w-4 mr-1" />
                                      Member Since
                                    </p>
                                    <p className="font-medium">
                                      {new Date(selectedUser.joinedDate).toLocaleDateString()}
                                    </p>
                                  </div>
                                </div>
                                <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                                  <div>
                                    <p className="text-sm text-gray-500">Total Investment</p>
                                    <p className="text-xl font-bold text-red-600">${selectedUser.totalInvestment}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-gray-500">Total Winnings</p>
                                    <p className="text-xl font-bold text-green-600">${selectedUser.totalWinnings}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-gray-500">Pools Joined</p>
                                    <p className="text-xl font-bold text-blue-600">{selectedUser.poolsJoined}</p>
                                  </div>
                                </div>
                                <div className="flex space-x-2 pt-4">
                                  {selectedUser.status === "pending" && (
                                    <>
                                      <CustomButton className="flex-1">
                                        <UserCheck className="h-4 w-4 mr-2" />
                                        Approve
                                      </CustomButton>
                                      <CustomButton variant="destructive" className="flex-1">
                                        <XCircle className="h-4 w-4 mr-2" />
                                        Reject
                                      </CustomButton>
                                    </>
                                  )}
                                  {selectedUser.status === "verified" && (
                                    <CustomButton variant="destructive" className="w-full">
                                      <Ban className="h-4 w-4 mr-2" />
                                      Suspend Account
                                    </CustomButton>
                                  )}
                                  {selectedUser.status === "suspended" && (
                                    <CustomButton className="w-full">
                                      <CheckCircle className="h-4 w-4 mr-2" />
                                      Reactivate Account
                                    </CustomButton>
                                  )}
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
