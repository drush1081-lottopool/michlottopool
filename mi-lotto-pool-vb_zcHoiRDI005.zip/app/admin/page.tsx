"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  Shield,
  FileText,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  CheckCircle,
  Clock,
  XCircle,
  Activity,
  Files,
  UserCog,
} from "lucide-react"
import Link from "next/link"

export default function AdminDashboardPage() {
  const stats = {
    totalUsers: 12847,
    pendingVerifications: 23,
    verifiedUsers: 12632,
    rejectedUsers: 47,
    suspendedUsers: 8,
    totalRevenue: 487230,
    activeAudits: 2,
    complianceScore: 98.5,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <Shield className="h-10 w-10 text-red-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600">Michigan Lotto Pool Management Center</p>
            </div>
          </div>
          <Badge variant="outline" className="text-red-600 border-red-600">
            Administrator Access
          </Badge>
        </div>

        {/* Alert for Pending Items */}
        {stats.pendingVerifications > 0 && (
          <Card className="mb-6 border-yellow-200 bg-yellow-50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="h-6 w-6 text-yellow-600" />
                  <div>
                    <p className="font-semibold text-yellow-900">Action Required</p>
                    <p className="text-sm text-yellow-700">
                      {stats.pendingVerifications} user verifications awaiting review
                    </p>
                  </div>
                </div>
                <Link href="/admin/users?filter=pending">
                  <CustomButton>Review Now</CustomButton>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +12% this month
                  </p>
                </div>
                <Users className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Review</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.pendingVerifications}</p>
                  <p className="text-xs text-gray-500 mt-1">Awaiting action</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Verified Users</p>
                  <p className="text-2xl font-bold text-green-600">{stats.verifiedUsers.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {((stats.verifiedUsers / stats.totalUsers) * 100).toFixed(1)}% of total
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Compliance Score</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.complianceScore}%</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Excellent
                  </p>
                </div>
                <Shield className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Navigation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          <Link href="/admin/roles">
            <Card className="card-custom hover:shadow-2xl transition-all cursor-pointer h-full">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <UserCog className="h-6 w-6 text-purple-600" />
                  <span>Role Management</span>
                </CardTitle>
                <CardDescription>Manage staff roles and permissions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Administrators</span>
                    <Badge className="bg-red-100 text-red-800">2</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Moderators</span>
                    <Badge className="bg-blue-100 text-blue-800">6</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Helpers</span>
                    <Badge className="bg-green-100 text-green-800">7</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Active Now</span>
                    <span className="text-sm font-medium">12 online</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/users">
            <Card className="card-custom hover:shadow-2xl transition-all cursor-pointer h-full">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-6 w-6 text-red-600" />
                  <span>User Management</span>
                </CardTitle>
                <CardDescription>View, verify, and manage all user accounts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Verified Users</span>
                    <Badge className="bg-green-100 text-green-800">{stats.verifiedUsers.toLocaleString()}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Pending Review</span>
                    <Badge className="bg-yellow-100 text-yellow-800">{stats.pendingVerifications}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Rejected</span>
                    <Badge className="bg-red-100 text-red-800">{stats.rejectedUsers}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Suspended</span>
                    <Badge className="bg-gray-100 text-gray-800">{stats.suspendedUsers}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/compliance">
            <Card className="card-custom hover:shadow-2xl transition-all cursor-pointer h-full">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-6 w-6 text-blue-600" />
                  <span>Compliance Monitoring</span>
                </CardTitle>
                <CardDescription>Track compliance status and audit trails</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Active Audits</span>
                    <Badge className="bg-blue-100 text-blue-800">{stats.activeAudits}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Compliance Score</span>
                    <Badge className="bg-green-100 text-green-800">{stats.complianceScore}%</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Last Audit</span>
                    <span className="text-sm font-medium">Jan 15, 2025</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Next Audit Due</span>
                    <span className="text-sm font-medium">Feb 15, 2025</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/tax-reporting">
            <Card className="card-custom hover:shadow-2xl transition-all cursor-pointer h-full">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-6 w-6 text-purple-600" />
                  <span>Tax Reporting</span>
                </CardTitle>
                <CardDescription>Manage 1099 forms and tax documentation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">2024 Tax Year</span>
                    <Badge className="bg-purple-100 text-purple-800">152 Forms</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Pending Forms</span>
                    <Badge className="bg-yellow-100 text-yellow-800">7</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Total Reported</span>
                    <span className="text-sm font-medium">$1.2M</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">IRS Deadline</span>
                    <span className="text-sm font-medium text-red-600">Jan 31, 2025</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/documents">
            <Card className="card-custom hover:shadow-2xl transition-all cursor-pointer h-full">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Files className="h-6 w-6 text-indigo-600" />
                  <span>Document Management</span>
                </CardTitle>
                <CardDescription>View and verify user documents</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Total Documents</span>
                    <Badge className="bg-indigo-100 text-indigo-800">8,524</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Pending Review</span>
                    <Badge className="bg-yellow-100 text-yellow-800">47</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Verified</span>
                    <Badge className="bg-green-100 text-green-800">8,423</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Storage Used</span>
                    <span className="text-sm font-medium">12.4 GB</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/financials">
            <Card className="card-custom hover:shadow-2xl transition-all cursor-pointer h-full">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="h-6 w-6 text-green-600" />
                  <span>Financial Overview</span>
                </CardTitle>
                <CardDescription>Monitor revenue, payouts, and transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Total Revenue</span>
                    <span className="text-sm font-bold text-green-600">${stats.totalRevenue.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">This Month</span>
                    <Badge className="bg-green-100 text-green-800">$42,350</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Pending Payouts</span>
                    <Badge className="bg-yellow-100 text-yellow-800">$18,200</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Growth</span>
                    <span className="text-sm font-medium text-green-600 flex items-center">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      +24%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-gray-600" />
              <span>Recent Activity</span>
            </CardTitle>
            <CardDescription>Latest user verifications and system events</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="font-medium">User Verified</p>
                    <p className="text-sm text-gray-500">Sarah Johnson - Troy, MI</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">2 min ago</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b">
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5 text-yellow-500" />
                  <div>
                    <p className="font-medium">Verification Pending</p>
                    <p className="text-sm text-gray-500">Michael Davis - Ann Arbor, MI</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">15 min ago</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b">
                <div className="flex items-center space-x-3">
                  <XCircle className="h-5 w-5 text-red-500" />
                  <div>
                    <p className="font-medium">Verification Rejected</p>
                    <p className="text-sm text-gray-500">Invalid ID document</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">1 hour ago</span>
              </div>
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center space-x-3">
                  <Shield className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="font-medium">Compliance Audit Completed</p>
                    <p className="text-sm text-gray-500">Score: 98.5% - Excellent</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">3 hours ago</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
