"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Download, Upload, Send, CheckCircle, AlertTriangle, Clock, DollarSign, Search } from "lucide-react"
import Link from "next/link"

interface TaxRecord {
  id: string
  userId: string
  userName: string
  email: string
  year: number
  totalWinnings: number
  taxableAmount: number
  formType: "1099-MISC" | "W-2G"
  status: "pending" | "generated" | "sent" | "filed"
  generatedDate?: string
  sentDate?: string
  filedDate?: string
}

export default function TaxReportingPage() {
  const [selectedYear, setSelectedYear] = useState("2024")
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  // Mock tax records
  const taxRecords: TaxRecord[] = [
    {
      id: "1",
      userId: "user1",
      userName: "John Smith",
      email: "john.smith@email.com",
      year: 2024,
      totalWinnings: 15420,
      taxableAmount: 15420,
      formType: "1099-MISC",
      status: "sent",
      generatedDate: "2025-01-10",
      sentDate: "2025-01-12",
    },
    {
      id: "2",
      userId: "user2",
      userName: "Michael Williams",
      email: "m.williams@email.com",
      year: 2024,
      totalWinnings: 1200,
      taxableAmount: 1200,
      formType: "1099-MISC",
      status: "generated",
      generatedDate: "2025-01-15",
    },
    {
      id: "3",
      userId: "user3",
      userName: "Sarah Johnson",
      email: "sarah.j@email.com",
      year: 2024,
      totalWinnings: 850,
      taxableAmount: 850,
      formType: "1099-MISC",
      status: "generated",
      generatedDate: "2025-01-15",
    },
    {
      id: "4",
      userId: "user4",
      userName: "David Brown",
      email: "d.brown@email.com",
      year: 2024,
      totalWinnings: 3250,
      taxableAmount: 3250,
      formType: "1099-MISC",
      status: "filed",
      generatedDate: "2025-01-08",
      sentDate: "2025-01-10",
      filedDate: "2025-01-15",
    },
    {
      id: "5",
      userId: "user5",
      userName: "Emily Davis",
      email: "emily.d@email.com",
      year: 2024,
      totalWinnings: 7890,
      taxableAmount: 7890,
      formType: "1099-MISC",
      status: "pending",
    },
  ]

  const filteredRecords = taxRecords.filter((record) => {
    const matchesSearch =
      record.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || record.status === statusFilter
    const matchesYear = record.year.toString() === selectedYear
    return matchesSearch && matchesStatus && matchesYear
  })

  const stats = {
    totalRecords: taxRecords.length,
    totalTaxable: taxRecords.reduce((sum, r) => sum + r.taxableAmount, 0),
    pending: taxRecords.filter((r) => r.status === "pending").length,
    generated: taxRecords.filter((r) => r.status === "generated").length,
    sent: taxRecords.filter((r) => r.status === "sent").length,
    filed: taxRecords.filter((r) => r.status === "filed").length,
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "filed":
        return (
          <Badge className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Filed
          </Badge>
        )
      case "sent":
        return (
          <Badge className="bg-blue-100 text-blue-800">
            <Send className="h-3 w-3 mr-1" />
            Sent
          </Badge>
        )
      case "generated":
        return (
          <Badge className="bg-purple-100 text-purple-800">
            <FileText className="h-3 w-3 mr-1" />
            Generated
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  const handleGenerateAll = () => {
    alert("Generating all pending 1099 forms...")
  }

  const handleBulkSend = () => {
    alert("Sending all generated forms via email...")
  }

  const handleFileWithIRS = () => {
    alert("Filing all forms with IRS...")
  }

  const handleExportCSV = () => {
    const csv = [
      ["ID", "Name", "Email", "Year", "Total Winnings", "Taxable Amount", "Form Type", "Status"].join(","),
      ...filteredRecords.map((r) =>
        [r.id, r.userName, r.email, r.year, r.totalWinnings, r.taxableAmount, r.formType, r.status].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `tax-records-${selectedYear}.csv`
    a.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Tax Reporting</h1>
            <p className="text-gray-600">Manage 1099 forms and IRS reporting for Michigan Lotto Pool</p>
          </div>
          <Link href="/admin">
            <CustomButton variant="outline">Back to Admin</CustomButton>
          </Link>
        </div>

        {/* Important Deadline Alert */}
        <Card className="mb-6 border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <AlertTriangle className="h-6 w-6 text-red-600" />
                <div>
                  <p className="font-semibold text-red-900">IRS Filing Deadline: January 31, 2025</p>
                  <p className="text-sm text-red-700">
                    All 1099-MISC forms must be filed with the IRS and sent to recipients by this date
                  </p>
                </div>
              </div>
              <Badge className="bg-red-600 text-white">5 days left</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Forms</p>
                  <p className="text-2xl font-bold">{stats.totalRecords}</p>
                  <p className="text-xs text-gray-500 mt-1">For {selectedYear}</p>
                </div>
                <FileText className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Taxable</p>
                  <p className="text-2xl font-bold text-green-600">${stats.totalTaxable.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 mt-1">Reported to IRS</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
                  <p className="text-xs text-gray-500 mt-1">Need generation</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Filed</p>
                  <p className="text-2xl font-bold text-green-600">{stats.filed}</p>
                  <p className="text-xs text-gray-500 mt-1">With IRS</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <CustomButton onClick={handleGenerateAll} className="flex-1">
                <FileText className="h-4 w-4 mr-2" />
                Generate All Forms ({stats.pending})
              </CustomButton>
              <CustomButton onClick={handleBulkSend} variant="outline" className="flex-1">
                <Send className="h-4 w-4 mr-2" />
                Send Generated ({stats.generated})
              </CustomButton>
              <CustomButton
                onClick={handleFileWithIRS}
                className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600"
              >
                <Upload className="h-4 w-4 mr-2" />
                File with IRS ({stats.sent})
              </CustomButton>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by name or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Select year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2023">2023</SelectItem>
                  <SelectItem value="2022">2022</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="generated">Generated</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="filed">Filed</SelectItem>
                </SelectContent>
              </Select>
              <CustomButton onClick={handleExportCSV} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </CustomButton>
            </div>
          </CardContent>
        </Card>

        {/* Tax Records Table */}
        <Card>
          <CardHeader>
            <CardTitle>Tax Records ({filteredRecords.length})</CardTitle>
            <CardDescription>1099-MISC forms for lottery winnings over $600 in {selectedYear}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Year</TableHead>
                    <TableHead>Total Winnings</TableHead>
                    <TableHead>Form Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Dates</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{record.userName}</p>
                          <p className="text-sm text-gray-500">{record.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>{record.year}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-semibold text-green-600">${record.totalWinnings.toLocaleString()}</p>
                          <p className="text-xs text-gray-500">Taxable: ${record.taxableAmount.toLocaleString()}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{record.formType}</Badge>
                      </TableCell>
                      <TableCell>{getStatusBadge(record.status)}</TableCell>
                      <TableCell>
                        <div className="text-sm space-y-1">
                          {record.generatedDate && (
                            <p className="text-gray-600">Gen: {new Date(record.generatedDate).toLocaleDateString()}</p>
                          )}
                          {record.sentDate && (
                            <p className="text-blue-600">Sent: {new Date(record.sentDate).toLocaleDateString()}</p>
                          )}
                          {record.filedDate && (
                            <p className="text-green-600">Filed: {new Date(record.filedDate).toLocaleDateString()}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          {record.status === "pending" && (
                            <CustomButton size="sm">
                              <FileText className="h-3 w-3 mr-1" />
                              Generate
                            </CustomButton>
                          )}
                          {record.status === "generated" && (
                            <CustomButton size="sm" variant="outline">
                              <Send className="h-3 w-3 mr-1" />
                              Send
                            </CustomButton>
                          )}
                          {(record.status === "sent" || record.status === "generated" || record.status === "filed") && (
                            <CustomButton size="sm" variant="outline">
                              <Download className="h-3 w-3 mr-1" />
                              Download
                            </CustomButton>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Help Section */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-lg">Tax Reporting Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div>
                <p className="font-semibold text-gray-900">Who needs a 1099-MISC?</p>
                <p className="text-gray-600">
                  Any member who won $600 or more in lottery winnings during the tax year.
                </p>
              </div>
              <div>
                <p className="font-semibold text-gray-900">Filing Deadlines</p>
                <p className="text-gray-600">
                  • January 31: Send copies to recipients and file with IRS
                  <br />• February 28: Paper filing deadline (if applicable)
                  <br />• March 31: Electronic filing deadline (if applicable)
                </p>
              </div>
              <div>
                <p className="font-semibold text-gray-900">Required Information</p>
                <p className="text-gray-600">
                  Legal name, address, SSN/TIN, total winnings amount, and withholding information (if applicable).
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
