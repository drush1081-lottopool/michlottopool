"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Shield, UserCog, Search, Plus, Edit, Trash2, AlertTriangle, CheckCircle } from "lucide-react"
import Link from "next/link"

interface StaffMember {
  id: string
  name: string
  email: string
  role: "admin" | "moderator" | "helper"
  status: "active" | "suspended"
  assignedDate: string
  lastActive: string
  permissions: string[]
}

export default function RoleManagementPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [roleFilter, setRoleFilter] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedMember, setSelectedMember] = useState<StaffMember | null>(null)

  const [newStaff, setNewStaff] = useState({
    email: "",
    role: "helper" as "admin" | "moderator" | "helper",
  })

  // Mock data
  const staffMembers: StaffMember[] = [
    {
      id: "1",
      name: "John Admin",
      email: "john@michiganlotto.com",
      role: "admin",
      status: "active",
      assignedDate: "2024-01-15",
      lastActive: "2 hours ago",
      permissions: ["full_access", "user_management", "financial", "compliance", "system_settings"],
    },
    {
      id: "2",
      name: "Sarah Moderator",
      email: "sarah@michiganlotto.com",
      role: "moderator",
      status: "active",
      assignedDate: "2024-03-20",
      lastActive: "30 minutes ago",
      permissions: ["user_verification", "document_review", "compliance_monitoring", "support"],
    },
    {
      id: "3",
      name: "Mike Helper",
      email: "mike@michiganlotto.com",
      role: "helper",
      status: "active",
      assignedDate: "2024-06-10",
      lastActive: "5 minutes ago",
      permissions: ["view_users", "basic_support"],
    },
    {
      id: "4",
      name: "Emily Moderator",
      email: "emily@michiganlotto.com",
      role: "moderator",
      status: "active",
      assignedDate: "2024-04-05",
      lastActive: "1 hour ago",
      permissions: ["user_verification", "document_review", "compliance_monitoring", "support"],
    },
  ]

  const rolePermissions = {
    admin: {
      title: "Administrator",
      description: "Full system access and control",
      permissions: [
        "Full user management",
        "Financial oversight and reporting",
        "System configuration",
        "Staff management (assign/remove roles)",
        "Compliance and audit control",
        "Payment processing",
        "Database access",
        "All moderator and helper permissions",
      ],
    },
    moderator: {
      title: "Moderator",
      description: "User verification and compliance monitoring",
      permissions: [
        "Review and approve user verifications",
        "Access document management",
        "Monitor compliance status",
        "Handle user support tickets",
        "View financial reports (read-only)",
        "Access audit logs (read-only)",
        "All helper permissions",
      ],
    },
    helper: {
      title: "Helper",
      description: "Basic support and monitoring",
      permissions: [
        "View user profiles (limited)",
        "Answer basic support questions",
        "Flag issues for moderator review",
        "View pool statistics",
        "Access knowledge base",
      ],
    },
  }

  const stats = {
    totalStaff: 15,
    admins: 2,
    moderators: 6,
    helpers: 7,
    activeNow: 12,
  }

  const handleAddStaff = async () => {
    console.log("[v0] Adding staff member:", newStaff)
    // In production: API call to add staff member
    setIsAddDialogOpen(false)
    setNewStaff({ email: "", role: "helper" })
  }

  const handleRemoveRole = async (memberId: string) => {
    if (confirm("Are you sure you want to remove this staff member's role?")) {
      console.log("[v0] Removing role for member:", memberId)
      // In production: API call to remove role
    }
  }

  const handleSuspend = async (memberId: string) => {
    if (confirm("Are you sure you want to suspend this staff member?")) {
      console.log("[v0] Suspending member:", memberId)
      // In production: API call to suspend
    }
  }

  const filteredStaff = staffMembers.filter((member) => {
    const matchesSearch =
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.email.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesRole = roleFilter === "all" || member.role === roleFilter
    return matchesSearch && matchesRole
  })

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-red-100 text-red-800"
      case "moderator":
        return "bg-blue-100 text-blue-800"
      case "helper":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Shield className="h-10 w-10 text-red-600" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Role Management</h1>
                <p className="text-gray-600">Assign and manage staff roles and permissions</p>
              </div>
            </div>
            <Link href="/admin">
              <CustomButton variant="outline">Back to Admin</CustomButton>
            </Link>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-600">Total Staff</p>
                <p className="text-2xl font-bold">{stats.totalStaff}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-600">Administrators</p>
                <p className="text-2xl font-bold text-red-600">{stats.admins}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-600">Moderators</p>
                <p className="text-2xl font-bold text-blue-600">{stats.moderators}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-600">Helpers</p>
                <p className="text-2xl font-bold text-green-600">{stats.helpers}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-600">Active Now</p>
                <p className="text-2xl font-bold">{stats.activeNow}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Role Descriptions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {Object.entries(rolePermissions).map(([key, role]) => (
            <Card key={key} className="card-custom">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <UserCog className="h-5 w-5 text-red-600" />
                  <span>{role.title}</span>
                </CardTitle>
                <CardDescription>{role.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {role.permissions.map((permission, idx) => (
                    <li key={idx} className="flex items-start space-x-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{permission}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Staff Management */}
        <Card className="card-custom">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Staff Members</CardTitle>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <CustomButton>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Staff Member
                  </CustomButton>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Staff Member</DialogTitle>
                    <DialogDescription>Assign a role to a new staff member</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newStaff.email}
                        onChange={(e) => setNewStaff({ ...newStaff, email: e.target.value })}
                        placeholder="staff@michiganlotto.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <Select
                        value={newStaff.role}
                        onValueChange={(value: any) => setNewStaff({ ...newStaff, role: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="helper">Helper</SelectItem>
                          <SelectItem value="moderator">Moderator</SelectItem>
                          <SelectItem value="admin">Administrator</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <CustomButton onClick={handleAddStaff} className="w-full">
                      Add Staff Member
                    </CustomButton>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {/* Search and Filter */}
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by name or email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="admin">Administrators</SelectItem>
                  <SelectItem value="moderator">Moderators</SelectItem>
                  <SelectItem value="helper">Helpers</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Staff Table */}
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Staff Member</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Assigned Date</TableHead>
                    <TableHead>Last Active</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStaff.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{member.name}</p>
                          <p className="text-sm text-gray-500">{member.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(member.role)}>
                          {member.role.charAt(0).toUpperCase() + member.role.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            member.status === "active" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                          }
                        >
                          {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">{member.assignedDate}</TableCell>
                      <TableCell className="text-sm text-gray-600">{member.lastActive}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <CustomButton variant="outline" size="sm" onClick={() => setSelectedMember(member)}>
                            <Edit className="h-4 w-4" />
                          </CustomButton>
                          <CustomButton variant="outline" size="sm" onClick={() => handleSuspend(member.id)}>
                            <AlertTriangle className="h-4 w-4" />
                          </CustomButton>
                          <CustomButton variant="outline" size="sm" onClick={() => handleRemoveRole(member.id)}>
                            <Trash2 className="h-4 w-4" />
                          </CustomButton>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
