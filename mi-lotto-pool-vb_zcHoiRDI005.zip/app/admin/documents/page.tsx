"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Download, Upload, Eye, Trash2, Search, Shield, File, ImageIcon, CheckCircle } from "lucide-react"
import Link from "next/link"

interface Document {
  id: string
  userId: string
  userName: string
  type: "id_front" | "id_back" | "selfie" | "proof_of_address" | "tax_form" | "legal"
  filename: string
  uploadDate: string
  size: number
  status: "pending" | "verified" | "rejected"
  verifiedBy?: string
  verifiedDate?: string
}

export default function DocumentManagementPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  // Mock documents
  const documents: Document[] = [
    {
      id: "1",
      userId: "user1",
      userName: "John Smith",
      type: "id_front",
      filename: "drivers_license_front.jpg",
      uploadDate: "2025-01-15",
      size: 2.4,
      status: "verified",
      verifiedBy: "admin@milottopool.com",
      verifiedDate: "2025-01-16",
    },
    {
      id: "2",
      userId: "user1",
      userName: "John Smith",
      type: "id_back",
      filename: "drivers_license_back.jpg",
      uploadDate: "2025-01-15",
      size: 2.2,
      status: "verified",
      verifiedBy: "admin@milottopool.com",
      verifiedDate: "2025-01-16",
    },
    {
      id: "3",
      userId: "user2",
      userName: "Sarah Johnson",
      type: "id_front",
      filename: "state_id_front.jpg",
      uploadDate: "2025-01-19",
      size: 3.1,
      status: "pending",
    },
    {
      id: "4",
      userId: "user2",
      userName: "Sarah Johnson",
      type: "selfie",
      filename: "selfie_with_id.jpg",
      uploadDate: "2025-01-19",
      size: 2.8,
      status: "pending",
    },
    {
      id: "5",
      userId: "user3",
      userName: "Michael Williams",
      type: "tax_form",
      filename: "w9_2024.pdf",
      uploadDate: "2025-01-10",
      size: 0.5,
      status: "verified",
      verifiedBy: "admin@milottopool.com",
      verifiedDate: "2025-01-11",
    },
  ]

  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.filename.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = typeFilter === "all" || doc.type === typeFilter
    const matchesStatus = statusFilter === "all" || doc.status === statusFilter
    return matchesSearch && matchesType && matchesStatus
  })

  const stats = {
    total: documents.length,
    pending: documents.filter((d) => d.status === "pending").length,
    verified: documents.filter((d) => d.status === "verified").length,
    rejected: documents.filter((d) => d.status === "rejected").length,
    totalSize: documents.reduce((sum, d) => sum + d.size, 0),
  }

  const getDocumentTypeBadge = (type: string) => {
    const types: Record<string, { label: string; color: string }> = {
      id_front: { label: "ID Front", color: "bg-blue-100 text-blue-800" },
      id_back: { label: "ID Back", color: "bg-blue-100 text-blue-800" },
      selfie: { label: "Selfie", color: "bg-purple-100 text-purple-800" },
      proof_of_address: { label: "Address Proof", color: "bg-green-100 text-green-800" },
      tax_form: { label: "Tax Form", color: "bg-orange-100 text-orange-800" },
      legal: { label: "Legal Doc", color: "bg-gray-100 text-gray-800" },
    }
    const typeInfo = types[type] || { label: type, color: "bg-gray-100 text-gray-800" }
    return <Badge className={typeInfo.color}>{typeInfo.label}</Badge>
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "verified":
        return <Badge className="bg-green-100 text-green-800">Verified</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      case "rejected":
        return <Badge className="bg-red-100 text-red-800">Rejected</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getFileIcon = (filename: string) => {
    if (filename.endsWith(".pdf")) return <FileText className="h-5 w-5 text-red-500" />
    if (filename.match(/\.(jpg|jpeg|png|gif)$/i)) return <ImageIcon className="h-5 w-5 text-blue-500" />
    return <File className="h-5 w-5 text-gray-500" />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Document Management</h1>
            <p className="text-gray-600">Secure storage and verification of user documents</p>
          </div>
          <Link href="/admin">
            <CustomButton variant="outline">Back to Admin</CustomButton>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Docs</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
                <FileText className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
                </div>
                <Upload className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Verified</p>
                  <p className="text-2xl font-bold text-green-600">{stats.verified}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Rejected</p>
                  <p className="text-2xl font-bold text-red-600">{stats.rejected}</p>
                </div>
                <Trash2 className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Storage</p>
                  <p className="text-2xl font-bold">{stats.totalSize.toFixed(1)}MB</p>
                </div>
                <Shield className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Security Notice */}
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3">
              <Shield className="h-6 w-6 text-blue-600" />
              <div>
                <p className="font-semibold text-blue-900">Secure Document Storage</p>
                <p className="text-sm text-blue-700">
                  All documents are encrypted at rest using AES-256 encryption and stored in compliance with Michigan
                  data protection laws
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by user or filename..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="id_front">ID Front</SelectItem>
                  <SelectItem value="id_back">ID Back</SelectItem>
                  <SelectItem value="selfie">Selfie</SelectItem>
                  <SelectItem value="proof_of_address">Address Proof</SelectItem>
                  <SelectItem value="tax_form">Tax Forms</SelectItem>
                  <SelectItem value="legal">Legal Documents</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Documents Table */}
        <Card>
          <CardHeader>
            <CardTitle>Documents ({filteredDocuments.length})</CardTitle>
            <CardDescription>View and manage all uploaded user documents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Document</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Upload Date</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Verified By</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDocuments.map((doc) => (
                    <TableRow key={doc.id}>
                      <TableCell>
                        <p className="font-medium">{doc.userName}</p>
                        <p className="text-xs text-gray-500">ID: {doc.userId}</p>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {getFileIcon(doc.filename)}
                          <span className="text-sm">{doc.filename}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getDocumentTypeBadge(doc.type)}</TableCell>
                      <TableCell>{new Date(doc.uploadDate).toLocaleDateString()}</TableCell>
                      <TableCell>{doc.size.toFixed(1)} MB</TableCell>
                      <TableCell>{getStatusBadge(doc.status)}</TableCell>
                      <TableCell>
                        {doc.verifiedBy ? (
                          <div className="text-sm">
                            <p className="text-gray-600">{doc.verifiedBy}</p>
                            <p className="text-xs text-gray-400">
                              {doc.verifiedDate && new Date(doc.verifiedDate).toLocaleDateString()}
                            </p>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <CustomButton size="sm" variant="outline">
                            <Eye className="h-3 w-3 mr-1" />
                            View
                          </CustomButton>
                          {doc.status === "pending" && (
                            <>
                              <CustomButton size="sm">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Verify
                              </CustomButton>
                            </>
                          )}
                          <CustomButton size="sm" variant="outline">
                            <Download className="h-3 w-3 mr-1" />
                            Download
                          </CustomButton>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Document Retention Policy */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-lg">Document Retention Policy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div>
                <p className="font-semibold text-gray-900">Storage Duration</p>
                <p className="text-gray-600">
                  Identity verification documents are retained for 7 years after account closure as required by Michigan
                  gaming regulations.
                </p>
              </div>
              <div>
                <p className="font-semibold text-gray-900">Security Standards</p>
                <p className="text-gray-600">
                  All documents are encrypted using AES-256 encryption at rest and TLS 1.3 in transit. Access is logged
                  and audited.
                </p>
              </div>
              <div>
                <p className="font-semibold text-gray-900">Compliance</p>
                <p className="text-gray-600">
                  Document management complies with Michigan Gaming Control Board regulations, GLBA, and state data
                  protection laws.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
