"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, AlertTriangle, Activity, Download, Search, FileText, Users, DollarSign, Lock } from "lucide-react"
import Link from "next/link"

interface ComplianceMetric {
  category: string
  score: number
  status: "excellent" | "good" | "warning" | "critical"
  lastCheck: string
  issues: number
}

interface AuditLog {
  id: string
  timestamp: string
  action: string
  entity: string
  user: string
  ipAddress: string
  details: string
  severity: "info" | "warning" | "critical"
}

export default function CompliancePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [severityFilter, setSeverityFilter] = useState("all")
  const [dateRange, setDateRange] = useState("7days")

  // Mock compliance metrics
  const metrics: ComplianceMetric[] = [
    {
      category: "KYC/Identity Verification",
      score: 98.5,
      status: "excellent",
      lastCheck: "2025-01-21",
      issues: 0,
    },
    {
      category: "Tax Reporting Compliance",
      score: 95.2,
      status: "excellent",
      lastCheck: "2025-01-20",
      issues: 1,
    },
    {
      category: "Data Protection (GLBA)",
      score: 97.8,
      status: "excellent",
      lastCheck: "2025-01-21",
      issues: 0,
    },
    {
      category: "Gaming Board Regulations",
      score: 99.1,
      status: "excellent",
      lastCheck: "2025-01-21",
      issues: 0,
    },
    {
      category: "Anti-Money Laundering (AML)",
      score: 96.5,
      status: "excellent",
      lastCheck: "2025-01-20",
      issues: 0,
    },
    {
      category: "Payment Security (PCI DSS)",
      score: 88.3,
      status: "good",
      lastCheck: "2025-01-19",
      issues: 3,
    },
  ]

  // Mock audit logs
  const auditLogs: AuditLog[] = [
    {
      id: "1",
      timestamp: "2025-01-21 14:32:15",
      action: "User Verification Approved",
      entity: "user_12345",
      user: "admin@milottopool.com",
      ipAddress: "192.168.1.100",
      details: "Verified identity documents for John Smith",
      severity: "info",
    },
    {
      id: "2",
      timestamp: "2025-01-21 14:28:03",
      action: "Tax Form Generated",
      entity: "tax_form_567",
      user: "system",
      ipAddress: "internal",
      details: "Generated 1099-MISC for Michael Williams ($15,420)",
      severity: "info",
    },
    {
      id: "3",
      timestamp: "2025-01-21 14:15:47",
      action: "Failed Login Attempt",
      entity: "user_98765",
      user: "unknown",
      ipAddress: "203.0.113.42",
      details: "Multiple failed login attempts detected",
      severity: "warning",
    },
    {
      id: "4",
      timestamp: "2025-01-21 13:52:18",
      action: "Payout Processed",
      entity: "payout_234",
      user: "admin@milottopool.com",
      ipAddress: "192.168.1.100",
      details: "Processed payout of $12,500 to Sarah Johnson",
      severity: "info",
    },
    {
      id: "5",
      timestamp: "2025-01-21 13:30:22",
      action: "Document Accessed",
      entity: "doc_456",
      user: "admin@milottopool.com",
      ipAddress: "192.168.1.100",
      details: "Viewed identity document for David Brown",
      severity: "info",
    },
    {
      id: "6",
      timestamp: "2025-01-21 12:45:09",
      action: "User Account Suspended",
      entity: "user_45678",
      user: "admin@milottopool.com",
      ipAddress: "192.168.1.100",
      details: "Suspended account due to suspicious activity",
      severity: "critical",
    },
  ]

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.entity.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.user.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSeverity = severityFilter === "all" || log.severity === severityFilter
    return matchesSearch && matchesSeverity
  })

  const overallScore = (metrics.reduce((sum, m) => sum + m.score, 0) / metrics.length).toFixed(1)
  const totalIssues = metrics.reduce((sum, m) => sum + m.issues, 0)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "excellent":
        return <Badge className="bg-green-100 text-green-800">Excellent</Badge>
      case "good":
        return <Badge className="bg-blue-100 text-blue-800">Good</Badge>
      case "warning":
        return <Badge className="bg-yellow-100 text-yellow-800">Warning</Badge>
      case "critical":
        return <Badge className="bg-red-100 text-red-800">Critical</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "info":
        return <Badge className="bg-blue-100 text-blue-800">Info</Badge>
      case "warning":
        return <Badge className="bg-yellow-100 text-yellow-800">Warning</Badge>
      case "critical":
        return <Badge className="bg-red-100 text-red-800">Critical</Badge>
      default:
        return <Badge>{severity}</Badge>
    }
  }

  const handleExportAuditLog = () => {
    const csv = [
      ["Timestamp", "Action", "Entity", "User", "IP Address", "Details", "Severity"].join(","),
      ...filteredLogs.map((log) =>
        [log.timestamp, log.action, log.entity, log.user, log.ipAddress, log.details, log.severity].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `audit-log-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Compliance Monitoring</h1>
            <p className="text-gray-600">Track compliance status and audit trails for Michigan Lotto Pool</p>
          </div>
          <Link href="/admin">
            <CustomButton variant="outline">Back to Admin</CustomButton>
          </Link>
        </div>

        {/* Overall Score Card */}
        <Card className="mb-6 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                  <span className="text-3xl font-bold text-white">{overallScore}</span>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">Overall Compliance Score</p>
                  <p className="text-gray-600">Excellent standing with Michigan Gaming Control Board</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <Badge className="bg-green-600 text-white">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      All Systems Compliant
                    </Badge>
                    {totalIssues > 0 && (
                      <Badge className="bg-yellow-100 text-yellow-800">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        {totalIssues} Minor Issues
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Last Full Audit</p>
                <p className="text-lg font-semibold">January 15, 2025</p>
                <p className="text-sm text-gray-600 mt-2">Next Audit Due</p>
                <p className="text-lg font-semibold text-red-600">February 15, 2025</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Verified Users</p>
                  <p className="text-2xl font-bold">12,632</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    98.5% compliant
                  </p>
                </div>
                <Users className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Tax Forms Filed</p>
                  <p className="text-2xl font-bold">152</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    On schedule
                  </p>
                </div>
                <FileText className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Secure Transactions</p>
                  <p className="text-2xl font-bold">8,547</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <Lock className="h-3 w-3 mr-1" />
                    PCI compliant
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Audit Events</p>
                  <p className="text-2xl font-bold">1,243</p>
                  <p className="text-xs text-blue-600 flex items-center mt-1">
                    <Activity className="h-3 w-3 mr-1" />
                    Last 7 days
                  </p>
                </div>
                <Activity className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Compliance Metrics */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Compliance Categories</CardTitle>
            <CardDescription>Detailed breakdown by regulatory category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metrics.map((metric) => (
                <div key={metric.category} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-gray-900">{metric.category}</p>
                      {getStatusBadge(metric.status)}
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>Score: {metric.score}%</span>
                      <span>Last Check: {new Date(metric.lastCheck).toLocaleDateString()}</span>
                      {metric.issues > 0 && (
                        <span className="text-yellow-600 flex items-center">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          {metric.issues} issue{metric.issues !== 1 ? "s" : ""}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="ml-4">
                    <div className="w-24 h-24 relative">
                      <svg className="transform -rotate-90 w-24 h-24">
                        <circle
                          cx="48"
                          cy="48"
                          r="40"
                          stroke="currentColor"
                          strokeWidth="8"
                          fill="transparent"
                          className="text-gray-200"
                        />
                        <circle
                          cx="48"
                          cy="48"
                          r="40"
                          stroke="currentColor"
                          strokeWidth="8"
                          fill="transparent"
                          strokeDasharray={`${2 * Math.PI * 40}`}
                          strokeDashoffset={`${2 * Math.PI * 40 * (1 - metric.score / 100)}`}
                          className={
                            metric.status === "excellent"
                              ? "text-green-500"
                              : metric.status === "good"
                                ? "text-blue-500"
                                : metric.status === "warning"
                                  ? "text-yellow-500"
                                  : "text-red-500"
                          }
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-lg font-bold">{metric.score}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Audit Trail */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Audit Trail</CardTitle>
                <CardDescription>Complete log of all system activities and admin actions</CardDescription>
              </div>
              <CustomButton onClick={handleExportAuditLog}>
                <Download className="h-4 w-4 mr-2" />
                Export Log
              </CustomButton>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search audit logs..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severity</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="24hours">Last 24 Hours</SelectItem>
                  <SelectItem value="7days">Last 7 Days</SelectItem>
                  <SelectItem value="30days">Last 30 Days</SelectItem>
                  <SelectItem value="90days">Last 90 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Entity</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="whitespace-nowrap text-sm">{log.timestamp}</TableCell>
                      <TableCell className="font-medium">{log.action}</TableCell>
                      <TableCell className="text-sm text-gray-600">{log.entity}</TableCell>
                      <TableCell className="text-sm">{log.user}</TableCell>
                      <TableCell className="text-sm text-gray-600">{log.ipAddress}</TableCell>
                      <TableCell>{getSeverityBadge(log.severity)}</TableCell>
                      <TableCell className="text-sm text-gray-600 max-w-md truncate">{log.details}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Compliance Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Regulatory Compliance Framework</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="font-semibold text-gray-900 mb-2">Michigan Gaming Control Board</p>
                <p className="text-sm text-gray-600 mb-2">License #LG-2024-001</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Annual compliance audits required</li>
                  <li>• KYC/AML procedures mandatory</li>
                  <li>• Real-time transaction monitoring</li>
                  <li>• 7-year record retention</li>
                </ul>
              </div>
              <div>
                <p className="font-semibold text-gray-900 mb-2">Federal Regulations</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Bank Secrecy Act (BSA) compliance</li>
                  <li>• Gramm-Leach-Bliley Act (GLBA) data protection</li>
                  <li>• IRS reporting for winnings over $600</li>
                  <li>• PCI DSS for payment security</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
