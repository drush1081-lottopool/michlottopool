"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { AlertCircle, CheckCircle, Upload, Shield, MapPin, User, CreditCard } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Link from "next/link"

export default function IdentityVerificationPage() {
  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [verificationStatus, setVerificationStatus] = useState<"pending" | "approved" | "rejected">("pending")

  // Form data
  const [personalInfo, setPersonalInfo] = useState({
    firstName: "",
    lastName: "",
    dateOfBirth: "",
    ssn: "",
  })

  const [addressInfo, setAddressInfo] = useState({
    street: "",
    city: "",
    state: "Michigan",
    zipCode: "",
    county: "",
    yearsAtAddress: "",
  })

  const [documentInfo, setDocumentInfo] = useState({
    idType: "",
    idNumber: "",
    expirationDate: "",
    frontImage: null as File | null,
    backImage: null as File | null,
    selfieImage: null as File | null,
  })

  const [agreements, setAgreements] = useState({
    age: false,
    residency: false,
    terms: false,
    responsibleGaming: false,
    taxReporting: false,
  })

  const handleFileUpload = (field: "frontImage" | "backImage" | "selfieImage", file: File | null) => {
    setDocumentInfo((prev) => ({ ...prev, [field]: file }))
  }

  const handleSubmitStep1 = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)
    setStep(2)
  }

  const handleSubmitStep2 = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)
    setStep(3)
  }

  const handleSubmitStep3 = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)
    setStep(4)
  }

  const handleFinalSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsLoading(false)
    setVerificationStatus("approved")
    setStep(5)
  }

  const michiganCounties = [
    "Wayne",
    "Oakland",
    "Macomb",
    "Kent",
    "Genesee",
    "Washtenaw",
    "Ingham",
    "Ottawa",
    "Kalamazoo",
    "Livingston",
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-2xl mx-auto py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Shield className="h-12 w-12 text-red-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Identity Verification (KYC)</h1>
          <p className="text-gray-600">
            Required by Michigan Gaming Control Board and federal law for lottery pool participation
          </p>
          <div className="flex items-center justify-center space-x-2 mt-4">
            <Badge variant="outline">
              <MapPin className="h-3 w-3 mr-1" />
              Michigan Residents Only
            </Badge>
            <Badge variant="outline" className="bg-blue-50">
              <Shield className="h-3 w-3 mr-1" />
              AML/KYC Compliant
            </Badge>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between items-center">
            {[1, 2, 3, 4, 5].map((s) => (
              <div key={s} className="flex flex-col items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    step >= s ? "bg-gradient-to-r from-red-600 to-blue-600 text-white" : "bg-gray-200 text-gray-500"
                  }`}
                >
                  {step > s ? <CheckCircle className="h-5 w-5" /> : s}
                </div>
                <span className="text-xs mt-2 text-gray-600">
                  {s === 1 && "Personal"}
                  {s === 2 && "Address"}
                  {s === 3 && "Documents"}
                  {s === 4 && "Agreements"}
                  {s === 5 && "Complete"}
                </span>
                {s < 5 && <div className={`h-1 w-full ${step > s ? "bg-red-600" : "bg-gray-200"} mt-4`} />}
              </div>
            ))}
          </div>
        </div>

        {/* Legal Notice */}
        <Alert className="mb-6 bg-blue-50 border-blue-200">
          <Shield className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Know Your Customer (KYC) Requirement:</strong> Federal and Michigan state law requires identity
            verification for all lottery pool participants. All information is encrypted, stored securely, and used only
            for verification, tax reporting, and compliance purposes.
          </AlertDescription>
        </Alert>

        {/* Step 1: Personal Information */}
        {step === 1 && (
          <Card className="card-custom">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="h-5 w-5 text-red-600" />
                <span>Personal Information</span>
              </CardTitle>
              <CardDescription>Enter your legal name and date of birth as they appear on your ID</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitStep1} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Legal First Name</Label>
                    <Input
                      id="firstName"
                      value={personalInfo.firstName}
                      onChange={(e) => setPersonalInfo({ ...personalInfo, firstName: e.target.value })}
                      className="input-custom"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Legal Last Name</Label>
                    <Input
                      id="lastName"
                      value={personalInfo.lastName}
                      onChange={(e) => setPersonalInfo({ ...personalInfo, lastName: e.target.value })}
                      className="input-custom"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dob">Date of Birth</Label>
                  <Input
                    id="dob"
                    type="date"
                    value={personalInfo.dateOfBirth}
                    onChange={(e) => setPersonalInfo({ ...personalInfo, dateOfBirth: e.target.value })}
                    className="input-custom"
                    max={new Date(Date.now() - 567648000000).toISOString().split("T")[0]} // 18 years ago
                    required
                  />
                  <p className="text-xs text-gray-500">You must be 18 or older to participate</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ssn">Social Security Number (Last 4 Digits)</Label>
                  <Input
                    id="ssn"
                    type="text"
                    value={personalInfo.ssn}
                    onChange={(e) => setPersonalInfo({ ...personalInfo, ssn: e.target.value.slice(0, 4) })}
                    className="input-custom"
                    placeholder="####"
                    maxLength={4}
                    pattern="\d{4}"
                    required
                  />
                  <p className="text-xs text-gray-500">Required for tax reporting on winnings over $600</p>
                </div>

                <CustomButton type="submit" className="w-full" loading={isLoading}>
                  Continue to Address Verification
                </CustomButton>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Michigan Address Verification */}
        {step === 2 && (
          <Card className="card-custom">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-red-600" />
                <span>Michigan Residency Verification</span>
              </CardTitle>
              <CardDescription>Confirm your current Michigan address</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitStep2} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="street">Street Address</Label>
                  <Input
                    id="street"
                    value={addressInfo.street}
                    onChange={(e) => setAddressInfo({ ...addressInfo, street: e.target.value })}
                    className="input-custom"
                    placeholder="123 Main Street"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      value={addressInfo.city}
                      onChange={(e) => setAddressInfo({ ...addressInfo, city: e.target.value })}
                      className="input-custom"
                      placeholder="Detroit"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="zipCode">ZIP Code</Label>
                    <Input
                      id="zipCode"
                      value={addressInfo.zipCode}
                      onChange={(e) => setAddressInfo({ ...addressInfo, zipCode: e.target.value })}
                      className="input-custom"
                      placeholder="48201"
                      pattern="\d{5}"
                      maxLength={5}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="county">County</Label>
                  <Select
                    value={addressInfo.county}
                    onValueChange={(value) => setAddressInfo({ ...addressInfo, county: value })}
                  >
                    <SelectTrigger className="input-custom">
                      <SelectValue placeholder="Select your county" />
                    </SelectTrigger>
                    <SelectContent>
                      {michiganCounties.map((county) => (
                        <SelectItem key={county} value={county}>
                          {county} County
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="yearsAtAddress">Years at Current Address</Label>
                  <Select
                    value={addressInfo.yearsAtAddress}
                    onValueChange={(value) => setAddressInfo({ ...addressInfo, yearsAtAddress: value })}
                  >
                    <SelectTrigger className="input-custom">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="<1">Less than 1 year</SelectItem>
                      <SelectItem value="1-2">1-2 years</SelectItem>
                      <SelectItem value="3-5">3-5 years</SelectItem>
                      <SelectItem value="5+">5+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex space-x-2">
                  <CustomButton type="button" variant="outline" onClick={() => setStep(1)} className="w-full">
                    Back
                  </CustomButton>
                  <CustomButton type="submit" className="w-full" loading={isLoading}>
                    Continue to Documents
                  </CustomButton>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Document Upload */}
        {step === 3 && (
          <Card className="card-custom">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CreditCard className="h-5 w-5 text-red-600" />
                <span>Document Upload</span>
              </CardTitle>
              <CardDescription>Upload a valid Michigan ID or Driver's License</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitStep3} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="idType">ID Type</Label>
                  <Select
                    value={documentInfo.idType}
                    onValueChange={(value) => setDocumentInfo({ ...documentInfo, idType: value })}
                  >
                    <SelectTrigger className="input-custom">
                      <SelectValue placeholder="Select ID type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="drivers_license">Michigan Driver's License</SelectItem>
                      <SelectItem value="state_id">Michigan State ID</SelectItem>
                      <SelectItem value="passport">U.S. Passport (with proof of MI residency)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="idNumber">ID Number</Label>
                    <Input
                      id="idNumber"
                      value={documentInfo.idNumber}
                      onChange={(e) => setDocumentInfo({ ...documentInfo, idNumber: e.target.value })}
                      className="input-custom"
                      placeholder="Enter ID number"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expiration">Expiration Date</Label>
                    <Input
                      id="expiration"
                      type="date"
                      value={documentInfo.expirationDate}
                      onChange={(e) => setDocumentInfo({ ...documentInfo, expirationDate: e.target.value })}
                      className="input-custom"
                      min={new Date().toISOString().split("T")[0]}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>ID Front (Clear photo)</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-red-400 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload("frontImage", e.target.files?.[0] || null)}
                        className="hidden"
                        id="frontImage"
                        required
                      />
                      <label htmlFor="frontImage" className="cursor-pointer">
                        <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                        <p className="text-sm text-gray-600">
                          {documentInfo.frontImage ? documentInfo.frontImage.name : "Click to upload front of ID"}
                        </p>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>ID Back (Clear photo)</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-red-400 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload("backImage", e.target.files?.[0] || null)}
                        className="hidden"
                        id="backImage"
                        required
                      />
                      <label htmlFor="backImage" className="cursor-pointer">
                        <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                        <p className="text-sm text-gray-600">
                          {documentInfo.backImage ? documentInfo.backImage.name : "Click to upload back of ID"}
                        </p>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Selfie Holding ID</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-red-400 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload("selfieImage", e.target.files?.[0] || null)}
                        className="hidden"
                        id="selfieImage"
                        required
                      />
                      <label htmlFor="selfieImage" className="cursor-pointer">
                        <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                        <p className="text-sm text-gray-600">
                          {documentInfo.selfieImage ? documentInfo.selfieImage.name : "Click to upload selfie with ID"}
                        </p>
                      </label>
                    </div>
                    <p className="text-xs text-gray-500">
                      Hold your ID next to your face. Ensure both are clearly visible.
                    </p>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <CustomButton type="button" variant="outline" onClick={() => setStep(2)} className="w-full">
                    Back
                  </CustomButton>
                  <CustomButton type="submit" className="w-full" loading={isLoading}>
                    Continue to Agreements
                  </CustomButton>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Legal Agreements */}
        {step === 4 && (
          <Card className="card-custom">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-red-600" />
                <span>Legal Agreements</span>
              </CardTitle>
              <CardDescription>Review and accept the required terms</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleFinalSubmit} className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                    <Checkbox
                      id="age"
                      checked={agreements.age}
                      onCheckedChange={(checked) => setAgreements({ ...agreements, age: checked as boolean })}
                      required
                    />
                    <div className="flex-1">
                      <Label htmlFor="age" className="font-medium cursor-pointer">
                        Age Confirmation
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">
                        I confirm that I am 18 years of age or older and legally able to participate in lottery
                        activities in Michigan.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                    <Checkbox
                      id="residency"
                      checked={agreements.residency}
                      onCheckedChange={(checked) => setAgreements({ ...agreements, residency: checked as boolean })}
                      required
                    />
                    <div className="flex-1">
                      <Label htmlFor="residency" className="font-medium cursor-pointer">
                        Michigan Residency
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">
                        I confirm that I am a current resident of Michigan and the address provided is my primary
                        residence.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                    <Checkbox
                      id="terms"
                      checked={agreements.terms}
                      onCheckedChange={(checked) => setAgreements({ ...agreements, terms: checked as boolean })}
                      required
                    />
                    <div className="flex-1">
                      <Label htmlFor="terms" className="font-medium cursor-pointer">
                        Terms of Service
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">
                        I have read and agree to the{" "}
                        <Link href="/terms" className="text-red-600 hover:underline">
                          Terms of Service
                        </Link>{" "}
                        and{" "}
                        <Link href="/privacy" className="text-red-600 hover:underline">
                          Privacy Policy
                        </Link>
                        .
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 p-4 bg-amber-50 rounded-lg border border-amber-200">
                    <Checkbox
                      id="responsible"
                      checked={agreements.responsibleGaming}
                      onCheckedChange={(checked) =>
                        setAgreements({ ...agreements, responsibleGaming: checked as boolean })
                      }
                      required
                    />
                    <div className="flex-1">
                      <Label htmlFor="responsible" className="font-medium cursor-pointer">
                        Responsible Gaming
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">
                        I understand the risks of gambling and will play responsibly. If I have a gambling problem, I
                        will call 1-800-270-7117 for help.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                    <Checkbox
                      id="tax"
                      checked={agreements.taxReporting}
                      onCheckedChange={(checked) => setAgreements({ ...agreements, taxReporting: checked as boolean })}
                      required
                    />
                    <div className="flex-1">
                      <Label htmlFor="tax" className="font-medium cursor-pointer">
                        Tax Reporting Consent
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">
                        I understand that winnings over $600 will be reported to the IRS and I will receive a 1099-MISC
                        form for tax purposes.
                      </p>
                    </div>
                  </div>
                </div>

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Your information will be verified within 24-48 hours. You'll receive an email notification when your
                    account is approved.
                  </AlertDescription>
                </Alert>

                <div className="flex space-x-2">
                  <CustomButton type="button" variant="outline" onClick={() => setStep(3)} className="w-full">
                    Back
                  </CustomButton>
                  <CustomButton
                    type="submit"
                    className="w-full"
                    loading={isLoading}
                    disabled={!Object.values(agreements).every(Boolean)}
                  >
                    Submit for Verification
                  </CustomButton>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 5: Completion */}
        {step === 5 && (
          <Card className="card-custom text-center">
            <CardContent className="pt-8 pb-8">
              <div className="flex justify-center mb-6">
                <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-12 w-12 text-white" />
                </div>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Verification Submitted!</h2>
              <p className="text-gray-600 mb-6">
                Your identity verification has been submitted successfully. Our compliance team will review your
                information within 24-48 hours.
              </p>
              <div className="bg-blue-50 rounded-lg p-4 mb-6">
                <p className="text-sm text-blue-800">
                  <strong>What's Next?</strong>
                  <br />
                  You'll receive an email once your verification is complete. In the meantime, you can explore the
                  platform but won't be able to join pools or make payments until verification is approved.
                </p>
              </div>
              <Link href="/dashboard">
                <CustomButton className="w-full">Go to Dashboard</CustomButton>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Help Text */}
        <div className="mt-6 text-center text-sm text-gray-500">
          <p>
            Questions about verification?{" "}
            <Link href="/support" className="text-red-600 hover:underline">
              Contact Support
            </Link>
          </p>
          <p className="mt-2">Verification required by Michigan Gaming Control Board regulations</p>
        </div>
      </div>
    </div>
  )
}
