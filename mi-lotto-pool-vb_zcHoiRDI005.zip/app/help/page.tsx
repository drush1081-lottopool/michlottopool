"use client"

import type React from "react"
import { CustomButton } from "@/components/ui/custom-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import MichiganLogo from "@/components/ui/michigan-logo"
import {
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Home,
  UserPlus,
  LogIn,
  Users,
  DollarSign,
  Mail,
  Vote,
  Settings,
  Shield,
  Phone,
  MessageCircle,
  Target,
  TrendingUp,
  CheckCircle,
  FileText,
  CreditCard,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface FAQItem {
  question: string
  answer: string
  category: string
  icon: React.ReactNode
}

export default function HelpPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const faqData: FAQItem[] = [
    {
      category: "Getting Started",
      question: "How do I join the Michigan Lotto Pool?",
      answer:
        'Click the "Join Pool - Only $5 to Start" button on the home page, then fill out the registration form with your email, password, and Michigan address. You\'ll need to verify your identity and residency before you can join a pool.',
      icon: <UserPlus className="h-5 w-5" />,
    },
    {
      category: "Getting Started",
      question: "Can I try it for free before paying?",
      answer:
        'Yes! Click "Get Free Numbers First" on the home page to receive daily lottery numbers via email without any payment. This lets you see how the system works before joining.',
      icon: <Mail className="h-5 w-5" />,
    },
    {
      category: "Getting Started",
      question: "How do I log in after registering?",
      answer:
        'Click "Already a Member? Sign In" on the home page, or visit /login. Enter your email and password to access your dashboard.',
      icon: <LogIn className="h-5 w-5" />,
    },
    {
      category: "How It Works",
      question: "What is the purpose of this app?",
      answer:
        "We pool together up to 5,000 members to cover every possible 4-digit lottery combination (0000-9999). When we win the $10,000 prize daily, the group votes on how to distribute the funds. This gives people who never really hit the lottery a chance to win big as part of our group. Everyone wins together!",
      icon: <Target className="h-5 w-5" />,
    },
    {
      category: "How It Works",
      question: "How does the pool cover all combinations?",
      answer:
        "There are exactly 10,000 possible 4-digit combinations (0000-9999). When our pool reaches 5,000 members, each member is assigned 2 combinations. This ensures we cover every possible number and win $10,000 every single day.",
      icon: <CheckCircle className="h-5 w-5" />,
    },
    {
      category: "How It Works",
      question: "How do we decide how to split the winnings?",
      answer:
        "All pool members vote democratically on distribution methods. You can vote for equal split, investment-based distribution, hybrid models, or other options. The voting page (/voting/fund-distribution) shows all active proposals.",
      icon: <Vote className="h-5 w-5" />,
    },
    {
      category: "Navigation",
      question: "Where is my dashboard?",
      answer:
        "After logging in, you'll automatically be directed to your dashboard at /dashboard. You can also click on your name or profile icon in the navigation menu to return to the dashboard anytime.",
      icon: <Home className="h-5 w-5" />,
    },
    {
      category: "Navigation",
      question: "How do I view my pool numbers?",
      answer:
        "Go to your dashboard and click on any pool you're a member of. Then click 'View My Numbers' to see your assigned combinations. You can also view ALL 10,000 combinations by clicking 'View All Combinations'.",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      category: "Navigation",
      question: "How do I join or create a pool?",
      answer:
        "From your dashboard, click 'Browse Available Pools' to see pools you can join, or click 'Create New Pool' to start your own. Each pool can have up to 5,000 members.",
      icon: <Users className="h-5 w-5" />,
    },
    {
      category: "Payments",
      question: "How do I make a payment?",
      answer:
        "Click 'Make Payment' from your dashboard or visit /payments. You can pay with credit card, debit card, or bank transfer. The minimum contribution is $5 and maximum is $500 per transaction.",
      icon: <CreditCard className="h-5 w-5" />,
    },
    {
      category: "Payments",
      question: "Is my payment information secure?",
      answer:
        "Yes! We use bank-grade 256-bit encryption and are PCI DSS compliant. We never store your full credit card information. All payments are processed through Stripe, a trusted payment processor.",
      icon: <Shield className="h-5 w-5" />,
    },
    {
      category: "Payments",
      question: "Can I convert my winnings to Bitcoin?",
      answer:
        "Yes! Visit /settings/crypto-settings to set up automatic Bitcoin conversion. You can set minimum thresholds and manage your crypto wallet addresses.",
      icon: <TrendingUp className="h-5 w-5" />,
    },
    {
      category: "Voting",
      question: "How do I vote on fund distribution?",
      answer:
        "Visit /voting/fund-distribution to see active voting proposals. Click on any proposal to view details and cast your vote. You can also create new proposals if you have ideas for distribution.",
      icon: <Vote className="h-5 w-5" />,
    },
    {
      category: "Voting",
      question: "When do voting periods close?",
      answer:
        "Each voting proposal has a deadline displayed on the voting page. Most votes run for 7-14 days to give all members time to participate. Results are automatically calculated when voting closes.",
      icon: <Vote className="h-5 w-5" />,
    },
    {
      category: "Account Settings",
      question: "How do I update my email preferences?",
      answer:
        "Visit /email-preferences from your dashboard settings. You can control daily number emails, winning notifications, pool updates, and voting alerts.",
      icon: <Settings className="h-5 w-5" />,
    },
    {
      category: "Account Settings",
      question: "How do I link my social media accounts?",
      answer:
        "Go to /settings/social-accounts to connect your Facebook, Twitter, Instagram, LinkedIn, or YouTube accounts. This helps build community trust and verify your identity.",
      icon: <MessageCircle className="h-5 w-5" />,
    },
    {
      category: "Security",
      question: "Why do I need to verify my identity (KYC)?",
      answer:
        "Identity verification (KYC) is required by Michigan law for all lottery pool members. It protects against fraud, money laundering, and ensures only Michigan residents participate. Visit /verify/identity to complete verification.",
      icon: <Shield className="h-5 w-5" />,
    },
    {
      category: "Security",
      question: "What documents do I need for verification?",
      answer:
        "You'll need a government-issued photo ID (driver's license or passport) and proof of Michigan residency (utility bill, lease agreement, or bank statement). All documents are encrypted and stored securely.",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      category: "Winning",
      question: "How do I know if my numbers won?",
      answer:
        "You'll receive an email notification immediately when any of your assigned numbers win. You can also check your dashboard for real-time winning updates and payout history.",
      icon: <DollarSign className="h-5 w-5" />,
    },
    {
      category: "Winning",
      question: "How do I receive my winnings?",
      answer:
        "Winnings are distributed according to the current voting decision. Payouts can be sent via direct deposit, check, or converted to Bitcoin. You'll receive tax forms (1099-MISC) for winnings over $600.",
      icon: <DollarSign className="h-5 w-5" />,
    },
  ]

  const categories = Array.from(new Set(faqData.map((item) => item.category)))

  const navigationGuides = [
    {
      title: "Home Page",
      path: "/",
      icon: <Home className="h-6 w-6" />,
      description: "View stats, join pools, and get free daily numbers",
    },
    {
      title: "Dashboard",
      path: "/dashboard",
      icon: <Home className="h-6 w-6" />,
      description: "Your personal hub for pools, payments, and account info",
    },
    {
      title: "Browse Pools",
      path: "/pools/join",
      icon: <Users className="h-6 w-6" />,
      description: "Find and join available lottery pools",
    },
    {
      title: "View All Combinations",
      path: "/pools/[id]/all-combinations",
      icon: <FileText className="h-6 w-6" />,
      description: "See all 10,000 lottery combinations and assignments",
    },
    {
      title: "Make Payment",
      path: "/payments",
      icon: <CreditCard className="h-6 w-6" />,
      description: "Add funds to your account or pool",
    },
    {
      title: "Vote on Distribution",
      path: "/voting/fund-distribution",
      icon: <Vote className="h-6 w-6" />,
      description: "Vote on how to distribute pool winnings",
    },
    {
      title: "Identity Verification",
      path: "/verify/identity",
      icon: <Shield className="h-6 w-6" />,
      description: "Complete KYC verification (required by law)",
    },
    {
      title: "Email Preferences",
      path: "/email-preferences",
      icon: <Mail className="h-6 w-6" />,
      description: "Manage your email notification settings",
    },
    {
      title: "Social Accounts",
      path: "/settings/social-accounts",
      icon: <MessageCircle className="h-6 w-6" />,
      description: "Link your social media profiles",
    },
    {
      title: "Crypto Settings",
      path: "/settings/crypto-settings",
      icon: <TrendingUp className="h-6 w-6" />,
      description: "Set up Bitcoin conversion for winnings",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50">
      <header className="glass border-b-2 border-white/30 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/">
              <MichiganLogo size="lg" animated />
            </Link>
            <Link href="/dashboard">
              <CustomButton variant="outline" size="lg">
                Back to Dashboard
              </CustomButton>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-red-500 to-blue-600 rounded-full mb-6">
            <HelpCircle className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">Help Center</h1>
          <p className="text-2xl text-gray-700 leading-relaxed">
            Everything you need to know about navigating the Michigan Lotto Pool app
          </p>
        </div>

        {/* Contact Support Card */}
        <Card className="card-custom mb-12 border-3">
          <CardHeader>
            <CardTitle className="flex items-center space-x-3 text-2xl">
              <Phone className="h-7 w-7 text-blue-600" />
              <span>Need More Help?</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-xl text-gray-700 leading-relaxed">
              Can't find what you're looking for? Our support team is here to help!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3 bg-blue-50 p-4 rounded-xl border-2 border-blue-200">
                <Phone className="h-6 w-6 text-blue-600" />
                <div>
                  <p className="font-bold text-lg text-gray-900">Call Us</p>
                  <p className="text-lg text-blue-600 font-semibold">1-800-MI-LOTTO</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-green-50 p-4 rounded-xl border-2 border-green-200">
                <Mail className="h-6 w-6 text-green-600" />
                <div>
                  <p className="font-bold text-lg text-gray-900">Email Us</p>
                  <p className="text-lg text-green-600 font-semibold">support@milottopool.com</p>
                </div>
              </div>
            </div>
            <p className="text-base text-gray-600 font-medium">Average response time: Under 5 minutes</p>
          </CardContent>
        </Card>

        {/* Navigation Guide */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Quick Navigation Guide</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {navigationGuides.map((guide, index) => (
              <Link href={guide.path.includes("[id]") ? "/dashboard" : guide.path} key={index}>
                <Card className="card-custom hover:shadow-xl transition-all duration-300 cursor-pointer h-full border-2">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="p-3 bg-gradient-to-br from-red-500 to-blue-600 rounded-xl flex-shrink-0">
                        {guide.icon}
                        <span className="text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{guide.title}</h3>
                        <p className="text-base text-gray-700 leading-relaxed">{guide.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>

          {categories.map((category) => (
            <div key={category} className="mb-8">
              <Badge
                variant="secondary"
                className="bg-gradient-to-r from-red-500 to-blue-600 text-white text-lg px-4 py-2 mb-4"
              >
                {category}
              </Badge>

              <div className="space-y-3">
                {faqData
                  .filter((item) => item.category === category)
                  .map((item, index) => {
                    const globalIndex = faqData.indexOf(item)
                    const isOpen = openIndex === globalIndex

                    return (
                      <Card key={globalIndex} className="card-custom border-2">
                        <CardHeader
                          className="cursor-pointer hover:bg-gray-50 transition-colors"
                          onClick={() => setOpenIndex(isOpen ? null : globalIndex)}
                        >
                          <CardTitle className="flex items-center justify-between text-xl">
                            <div className="flex items-center space-x-3">
                              <div className="p-2 bg-blue-100 rounded-lg">{item.icon}</div>
                              <span className="text-gray-900">{item.question}</span>
                            </div>
                            {isOpen ? (
                              <ChevronUp className="h-6 w-6 text-gray-600 flex-shrink-0" />
                            ) : (
                              <ChevronDown className="h-6 w-6 text-gray-600 flex-shrink-0" />
                            )}
                          </CardTitle>
                        </CardHeader>
                        {isOpen && (
                          <CardContent className="pt-0">
                            <p className="text-lg text-gray-700 leading-relaxed pl-14">{item.answer}</p>
                          </CardContent>
                        )}
                      </Card>
                    )
                  })}
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <Card className="card-gradient border-3">
          <CardContent className="text-center py-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Still Have Questions?</h2>
            <p className="text-xl text-gray-700 mb-8 leading-relaxed">
              Our support team is available 24/7 to help you succeed
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="tel:1-800-645-6886">
                <CustomButton size="xl" className="senior-friendly-button w-full sm:w-auto">
                  <Phone className="h-6 w-6 mr-2" />
                  Call Support Now
                </CustomButton>
              </a>
              <a href="mailto:support@milottopool.com">
                <CustomButton variant="outline" size="xl" className="senior-friendly-button w-full sm:w-auto">
                  <Mail className="h-6 w-6 mr-2" />
                  Email Support
                </CustomButton>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
