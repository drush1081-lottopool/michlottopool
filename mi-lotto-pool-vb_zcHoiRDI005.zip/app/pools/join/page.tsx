"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, DollarSign, Search, MapPin } from "lucide-react"
import Link from "next/link"

export default function JoinPoolPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const availablePools = [
    {
      id: 1,
      name: "Detroit Metro Pool",
      location: "Detroit, MI",
      members: 2847,
      maxMembers: 5000,
      minInvestment: 5,
      nextDraw: "Jan 8, 2025",
      description: "The largest and most active pool in Detroit metro area",
      status: "open",
    },
    {
      id: 2,
      name: "Ann Arbor University Pool",
      location: "Ann Arbor, MI",
      members: 892,
      maxMembers: 1500,
      minInvestment: 10,
      nextDraw: "Jan 8, 2025",
      description: "Pool for University of Michigan community",
      status: "open",
    },
    {
      id: 3,
      name: "Lansing State Workers",
      location: "Lansing, MI",
      members: 1456,
      maxMembers: 2000,
      minInvestment: 8,
      nextDraw: "Jan 8, 2025",
      description: "Exclusive pool for Michigan state employees",
      status: "verification_required",
    },
    {
      id: 4,
      name: "Grand Rapids Winners",
      location: "Grand Rapids, MI",
      members: 2999,
      maxMembers: 3000,
      minInvestment: 5,
      nextDraw: "Jan 8, 2025",
      description: "Almost full! Join the winning tradition",
      status: "almost_full",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return <Badge className="bg-green-100 text-green-800">Open</Badge>
      case "almost_full":
        return <Badge className="bg-yellow-100 text-yellow-800">Almost Full</Badge>
      case "verification_required":
        return <Badge className="bg-blue-100 text-blue-800">Verification Required</Badge>
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Join a Pool</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {/* Search */}
        <div className="mb-6">
          <Label htmlFor="search" className="sr-only">
            Search pools
          </Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              id="search"
              placeholder="Search pools by name or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Create New Pool CTA */}
        <Card className="mb-6 bg-red-50 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-red-900">Create Your Own Pool</h3>
                <p className="text-sm text-red-700">Start a new pool in your area</p>
              </div>
              <Link href="/pools/create">
                <Button size="sm" className="bg-red-600 hover:bg-red-700">
                  Create
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Available Pools */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">Available Pools</h2>

          {availablePools.map((pool) => (
            <Card key={pool.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{pool.name}</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <MapPin className="h-3 w-3 mr-1" />
                      {pool.location}
                    </CardDescription>
                  </div>
                  {getStatusBadge(pool.status)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">{pool.description}</p>

                {/* Pool Stats */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Members</span>
                    <span className="font-medium">
                      {pool.members.toLocaleString()} / {pool.maxMembers.toLocaleString()}
                    </span>
                  </div>
                  <Progress value={(pool.members / pool.maxMembers) * 100} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-green-600" />
                    <div>
                      <p className="text-gray-600">Min Investment</p>
                      <p className="font-medium">${pool.minInvestment}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-gray-600">Next Draw</p>
                    <p className="font-medium">{pool.nextDraw}</p>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Link href={`/pools/${pool.id}/details`} className="flex-1">
                    <Button variant="outline" className="w-full bg-transparent">
                      View Details
                    </Button>
                  </Link>
                  <Link href={`/pools/${pool.id}/join`} className="flex-1">
                    <Button
                      className="w-full"
                      disabled={pool.status === "almost_full" && pool.members >= pool.maxMembers}
                    >
                      {pool.status === "verification_required" ? "Apply" : "Join Pool"}
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
