"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Mail, Download, Eye, EyeOff, Grid3x3 } from "lucide-react"
import Link from "next/link"

export default function MyNumbersPage() {
  const [showNumbers, setShowNumbers] = useState(false)

  const myNumbers = [
    { number: "1234", status: "active", lastChecked: "Jan 5, 2025" },
    { number: "5678", status: "active", lastChecked: "Jan 5, 2025" },
    { number: "9012", status: "active", lastChecked: "Jan 5, 2025" },
    { number: "3456", status: "pending", lastChecked: "Jan 4, 2025" },
    { number: "7890", status: "active", lastChecked: "Jan 5, 2025" },
  ]

  const emailHistory = [
    {
      date: "Jan 5, 2025",
      subject: "Your Numbers for Jan 8 Draw",
      numbers: 5,
      status: "delivered",
    },
    {
      date: "Jan 1, 2025",
      subject: "Your Numbers for Jan 4 Draw",
      numbers: 5,
      status: "delivered",
    },
    {
      date: "Dec 28, 2024",
      subject: "Your Numbers for Jan 1 Draw",
      numbers: 5,
      status: "delivered",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">My Numbers</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {/* Pool Info */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Detroit Metro Pool</CardTitle>
            <CardDescription>Next Draw: January 8, 2025</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Your Numbers</p>
                <p className="text-2xl font-bold text-blue-600">5</p>
              </div>
              <div>
                <p className="text-gray-600">Investment</p>
                <p className="text-2xl font-bold text-green-600">$25</p>
              </div>
            </div>
            <Link href="/pools/1/all-combinations" className="mt-4 block">
              <Button variant="outline" className="w-full bg-transparent">
                <Grid3x3 className="h-4 w-4 mr-2" />
                View All Pool Combinations
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Tabs defaultValue="current" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="current">Current Numbers</TabsTrigger>
            <TabsTrigger value="history">Email History</TabsTrigger>
          </TabsList>

          <TabsContent value="current" className="space-y-4 mt-6">
            {/* Privacy Toggle */}
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Your Assigned Numbers</h2>
              <Button variant="outline" size="sm" onClick={() => setShowNumbers(!showNumbers)}>
                {showNumbers ? <EyeOff className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
                {showNumbers ? "Hide" : "Show"}
              </Button>
            </div>

            {/* Numbers List */}
            <div className="space-y-3">
              {myNumbers.map((item, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl font-mono font-bold text-blue-600">
                          {showNumbers ? item.number : "••••"}
                        </div>
                        <div>
                          <Badge
                            variant={item.status === "active" ? "default" : "secondary"}
                            className={item.status === "active" ? "bg-green-100 text-green-800" : ""}
                          >
                            {item.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right text-sm text-gray-500">
                        <p>Last checked</p>
                        <p>{item.lastChecked}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <Button className="w-full bg-transparent" variant="outline">
                <Mail className="h-4 w-4 mr-2" />
                Resend Numbers Email
              </Button>
              <Button className="w-full bg-transparent" variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download Numbers (PDF)
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-4 mt-6">
            <h2 className="text-lg font-semibold">Email History</h2>

            <div className="space-y-3">
              {emailHistory.map((email, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{email.subject}</p>
                        <p className="text-sm text-gray-600">{email.numbers} numbers sent</p>
                        <p className="text-xs text-gray-500">{email.date}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          {email.status}
                        </Badge>
                        <Button variant="ghost" size="sm">
                          <Mail className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center py-4">
              <Button variant="outline">Load More History</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
