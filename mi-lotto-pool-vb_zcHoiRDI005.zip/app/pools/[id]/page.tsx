"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Users, DollarSign, Calendar, Grid3x3, TrendingUp } from "lucide-react"
import Link from "next/link"
import { CommentsSection } from "@/components/ui/comments-section"

export default function PoolDetailsPage() {
  const pool = {
    id: 1,
    name: "Detroit Metro Pool",
    members: 2847,
    maxMembers: 5000,
    status: "active",
    nextDraw: "Jan 8, 2025",
    totalInvested: 14235,
    potentialPrize: 5000000,
    yourNumbers: 5,
    yourInvestment: 150,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{pool.name}</h1>
            <Badge variant={pool.status === "active" ? "default" : "secondary"} className="mt-1">
              {pool.status}
            </Badge>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Users className="h-5 w-5 text-blue-600" />
                <span>Pool Members</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-gray-900 mb-2">
                {pool.members.toLocaleString()} / {pool.maxMembers.toLocaleString()}
              </p>
              <Progress value={(pool.members / pool.maxMembers) * 100} className="h-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2 text-lg">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span>Total Pool Investment</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">${pool.totalInvested.toLocaleString()}</p>
              <p className="text-sm text-gray-600 mt-2">Potential Prize: ${pool.potentialPrize.toLocaleString()}</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Calendar className="h-5 w-5 text-red-600" />
              <span>Your Pool Status</span>
            </CardTitle>
            <CardDescription>Next Draw: {pool.nextDraw}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Your Numbers</p>
                <p className="text-2xl font-bold text-blue-600">{pool.yourNumbers}</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Your Investment</p>
                <p className="text-2xl font-bold text-green-600">${pool.yourInvestment}</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <Link href={`/pools/${pool.id}/numbers`} className="flex-1">
                <Button className="w-full">View My Numbers</Button>
              </Link>
              <Link href={`/pools/${pool.id}/all-combinations`} className="flex-1">
                <Button variant="outline" className="w-full bg-transparent">
                  <Grid3x3 className="h-4 w-4 mr-2" />
                  All Combinations
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <span>Recent Pool Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className="w-2 h-2 bg-green-600 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">32 new members joined today</p>
                <p className="text-xs text-gray-500">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">All numbers distributed for next draw</p>
                <p className="text-xs text-gray-500">5 hours ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className="w-2 h-2 bg-yellow-600 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Pool voting started for fund distribution</p>
                <p className="text-xs text-gray-500">1 day ago</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <CommentsSection poolId={pool.id.toString()} title="Pool Community Discussion" />
      </div>
    </div>
  )
}
