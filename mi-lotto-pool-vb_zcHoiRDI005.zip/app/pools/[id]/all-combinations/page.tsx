"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Search, Download, Filter } from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AllCombinationsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 50

  // Generate all 10,000 possible 4-digit combinations (0000-9999)
  const allCombinations = useMemo(() => {
    const combinations = []
    for (let i = 0; i <= 9999; i++) {
      const number = i.toString().padStart(4, "0")
      // Mock data: some numbers are assigned to members
      const isAssigned = Math.random() > 0.7
      const memberName = isAssigned ? `Member ${Math.floor(Math.random() * 100) + 1}` : null

      combinations.push({
        number,
        isAssigned,
        memberName,
        status: isAssigned ? "assigned" : "available",
      })
    }
    return combinations
  }, [])

  // Filter combinations
  const filteredCombinations = useMemo(() => {
    let filtered = allCombinations

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter((combo) => combo.number.includes(searchQuery))
    }

    // Apply status filter
    if (filterType === "assigned") {
      filtered = filtered.filter((combo) => combo.isAssigned)
    } else if (filterType === "available") {
      filtered = filtered.filter((combo) => !combo.isAssigned)
    }

    return filtered
  }, [allCombinations, searchQuery, filterType])

  // Paginate results
  const totalPages = Math.ceil(filteredCombinations.length / itemsPerPage)
  const paginatedCombinations = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage
    return filteredCombinations.slice(startIndex, startIndex + itemsPerPage)
  }, [filteredCombinations, currentPage])

  // Statistics
  const stats = useMemo(() => {
    const assigned = allCombinations.filter((c) => c.isAssigned).length
    const available = allCombinations.length - assigned
    return {
      total: allCombinations.length,
      assigned,
      available,
      assignedPercentage: ((assigned / allCombinations.length) * 100).toFixed(1),
    }
  }, [allCombinations])

  const handleDownloadAll = () => {
    const csvContent = [
      "Number,Status,Member",
      ...filteredCombinations.map((c) => `${c.number},${c.status},${c.memberName || "N/A"}`),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "lottery-combinations.csv"
    a.click()
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon" className="mr-3">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold text-gray-900">All Combinations</h1>
              <p className="text-sm text-gray-600">Detroit Metro Pool</p>
            </div>
          </div>
          <Button onClick={handleDownloadAll} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-1">Total</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-1">Assigned</p>
                <p className="text-2xl font-bold text-green-600">{stats.assigned.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-1">Available</p>
                <p className="text-2xl font-bold text-blue-600">{stats.available.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-1">Coverage</p>
                <p className="text-2xl font-bold text-red-600">{stats.assignedPercentage}%</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Search & Filter</CardTitle>
            <CardDescription>
              Showing {filteredCombinations.length.toLocaleString()} of {stats.total.toLocaleString()} combinations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search by number (e.g., 1234)"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                  maxLength={4}
                />
              </div>
              <Select
                value={filterType}
                onValueChange={(value) => {
                  setFilterType(value)
                  setCurrentPage(1)
                }}
              >
                <SelectTrigger className="w-full sm:w-[180px]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Numbers</SelectItem>
                  <SelectItem value="assigned">Assigned Only</SelectItem>
                  <SelectItem value="available">Available Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Combinations Grid */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">
              Combinations {currentPage} of {totalPages}
            </CardTitle>
            <CardDescription>4-digit lottery number combinations (0000-9999)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {paginatedCombinations.map((combo) => (
                <div
                  key={combo.number}
                  className={`p-3 border rounded-lg ${
                    combo.isAssigned ? "bg-green-50 border-green-200" : "bg-white border-gray-200"
                  }`}
                >
                  <div className="text-center">
                    <p className="text-xl font-mono font-bold text-gray-900 mb-1">{combo.number}</p>
                    <Badge
                      variant={combo.isAssigned ? "default" : "secondary"}
                      className={`text-xs ${
                        combo.isAssigned ? "bg-green-600 text-white" : "bg-gray-200 text-gray-700"
                      }`}
                    >
                      {combo.status}
                    </Badge>
                    {combo.memberName && <p className="text-xs text-gray-600 mt-1 truncate">{combo.memberName}</p>}
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-6 flex items-center justify-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                <div className="flex items-center space-x-1">
                  {currentPage > 2 && (
                    <>
                      <Button variant="ghost" size="sm" onClick={() => setCurrentPage(1)}>
                        1
                      </Button>
                      {currentPage > 3 && <span className="text-gray-400">...</span>}
                    </>
                  )}
                  {currentPage > 1 && (
                    <Button variant="ghost" size="sm" onClick={() => setCurrentPage(currentPage - 1)}>
                      {currentPage - 1}
                    </Button>
                  )}
                  <Button variant="default" size="sm">
                    {currentPage}
                  </Button>
                  {currentPage < totalPages && (
                    <Button variant="ghost" size="sm" onClick={() => setCurrentPage(currentPage + 1)}>
                      {currentPage + 1}
                    </Button>
                  )}
                  {currentPage < totalPages - 1 && (
                    <>
                      {currentPage < totalPages - 2 && <span className="text-gray-400">...</span>}
                      <Button variant="ghost" size="sm" onClick={() => setCurrentPage(totalPages)}>
                        {totalPages}
                      </Button>
                    </>
                  )}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
            )}

            {filteredCombinations.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">No combinations found matching your search.</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-4 bg-transparent"
                  onClick={() => {
                    setSearchQuery("")
                    setFilterType("all")
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
