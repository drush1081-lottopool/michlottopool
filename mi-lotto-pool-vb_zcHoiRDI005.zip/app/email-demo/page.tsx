"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Mail, Eye } from "lucide-react"
import Link from "next/link"
import DailyEmailPreview from "@/components/daily-email-preview"

export default function EmailDemoPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Email Preview</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {/* Info Card */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Eye className="h-5 w-5 text-blue-600" />
              <span>Daily Email Preview</span>
            </CardTitle>
            <CardDescription>See exactly what your daily lottery numbers email will look like</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Delivery Time:</span>
                <span className="font-medium">8:00 AM EST Daily</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Email Type:</span>
                <span className="font-medium">HTML + Plain Text</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Mobile Optimized:</span>
                <span className="font-medium text-green-600">Yes</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Email Preview */}
        <DailyEmailPreview />

        {/* Actions */}
        <div className="mt-6 space-y-3">
          <Link href="/email-signup">
            <Button className="w-full bg-red-600 hover:bg-red-700">
              <Mail className="h-4 w-4 mr-2" />
              Sign Up for Daily Emails
            </Button>
          </Link>

          <div className="grid grid-cols-2 gap-3">
            <Link href="/email-preferences">
              <Button variant="outline" className="w-full bg-transparent">
                Email Settings
              </Button>
            </Link>
            <Link href="/register">
              <Button variant="outline" className="w-full bg-transparent">
                Full Registration
              </Button>
            </Link>
          </div>
        </div>

        {/* Features */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-blue-900">Email Features</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm text-blue-700 space-y-2">
              <li className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                <span>Mobile-responsive design</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                <span>Large, easy-to-read numbers</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                <span>Pool information included</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                <span>Draw time and date</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                <span>Easy unsubscribe options</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
