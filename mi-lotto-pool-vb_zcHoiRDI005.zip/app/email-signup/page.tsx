"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Mail, Clock, Shield, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function EmailSignupPage() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    email: "",
    firstName: "",
    lastName: "",
    phone: "",
    city: "",
    zipCode: "",
    emailPreferences: {
      dailyNumbers: true,
      drawResults: true,
      poolUpdates: true,
      votingAlerts: true,
    },
    selectedPool: "",
  })

  const availablePools = [
    { id: "detroit", name: "Detroit Metro Pool", members: 2847, minInvestment: 5 },
    { id: "grandrapids", name: "Grand Rapids Winners", members: 1523, minInvestment: 5 },
    { id: "annarbor", name: "Ann Arbor University Pool", members: 892, minInvestment: 10 },
  ]

  const handleEmailSubmit = () => {
    if (formData.email) {
      setStep(2)
    }
  }

  const handleCompleteSignup = () => {
    setStep(3)
  }

  if (step === 3) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-md mx-auto px-4 py-4 flex items-center">
            <Link href="/">
              <Button variant="ghost" size="icon" className="mr-3">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold text-gray-900">Email Signup Complete</h1>
          </div>
        </header>

        <div className="max-w-md mx-auto px-4 py-12 text-center">
          <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-4">Welcome to Michigan Lotto Pool!</h2>
          <p className="text-gray-600 mb-6">
            Your email signup is complete. You'll start receiving your daily pool numbers tomorrow morning.
          </p>

          <Card className="mb-6 text-left">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">What to Expect</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Daily Numbers Email</p>
                  <p className="text-sm text-gray-600">Sent every morning at 8:00 AM EST</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Clock className="h-5 w-5 text-red-600" />
                <div>
                  <p className="font-medium">Draw Results</p>
                  <p className="text-sm text-gray-600">Results sent within 1 hour of each draw</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Shield className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Pool Updates</p>
                  <p className="text-sm text-gray-600">Important announcements and voting alerts</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            <Link href="/register">
              <Button className="w-full bg-red-600 hover:bg-red-700">Complete Full Registration</Button>
            </Link>
            <Link href="/email-preferences">
              <Button variant="outline" className="w-full bg-transparent">
                Manage Email Preferences
              </Button>
            </Link>
          </div>

          <p className="text-xs text-gray-500 mt-6">You can unsubscribe or modify your preferences at any time</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Email Signup</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {/* Progress Indicator */}
        <div className="flex items-center justify-center mb-6">
          <div className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 1 ? "bg-red-600 text-white" : "bg-gray-200 text-gray-600"
              }`}
            >
              1
            </div>
            <div className={`w-8 h-1 ${step >= 2 ? "bg-red-600" : "bg-gray-200"}`}></div>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 2 ? "bg-red-600 text-white" : "bg-gray-200 text-gray-600"
              }`}
            >
              2
            </div>
          </div>
        </div>

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-red-600" />
                <span>Get Daily Pool Numbers</span>
              </CardTitle>
              <CardDescription>
                Enter your email to receive lottery numbers daily - no payment required to start
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="john@example.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pool">Choose Your Pool</Label>
                <Select onValueChange={(value) => setFormData({ ...formData, selectedPool: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a pool to join" />
                  </SelectTrigger>
                  <SelectContent>
                    {availablePools.map((pool) => (
                      <SelectItem key={pool.id} value={pool.id}>
                        <div className="flex items-center justify-between w-full">
                          <span>{pool.name}</span>
                          <Badge variant="secondary" className="ml-2">
                            {pool.members} members
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Benefits */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">What You'll Get:</h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Daily lottery numbers delivered to your inbox</li>
                  <li>• Draw results and winning notifications</li>
                  <li>• Pool updates and voting opportunities</li>
                  <li>• No payment required to start receiving numbers</li>
                </ul>
              </div>

              <Button
                className="w-full bg-red-600 hover:bg-red-700"
                onClick={handleEmailSubmit}
                disabled={!formData.email || !formData.selectedPool}
              >
                Continue
              </Button>

              <p className="text-xs text-gray-500 text-center">
                By continuing, you agree to receive emails from Michigan Lotto Pool
              </p>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Complete Your Profile</CardTitle>
              <CardDescription>Help us personalize your experience and verify Michigan residency</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder="John"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder="Doe"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number (Optional)</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="(248) 555-0123"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">Michigan City</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Detroit"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="zipCode">ZIP Code</Label>
                  <Input
                    id="zipCode"
                    value={formData.zipCode}
                    onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
                    placeholder="48201"
                  />
                </div>
              </div>

              {/* Email Preferences */}
              <div className="space-y-3">
                <Label>Email Preferences</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="dailyNumbers"
                      checked={formData.emailPreferences.dailyNumbers}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          emailPreferences: { ...formData.emailPreferences, dailyNumbers: checked as boolean },
                        })
                      }
                    />
                    <Label htmlFor="dailyNumbers" className="text-sm">
                      Daily lottery numbers (8:00 AM EST)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="drawResults"
                      checked={formData.emailPreferences.drawResults}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          emailPreferences: { ...formData.emailPreferences, drawResults: checked as boolean },
                        })
                      }
                    />
                    <Label htmlFor="drawResults" className="text-sm">
                      Draw results and winning notifications
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="poolUpdates"
                      checked={formData.emailPreferences.poolUpdates}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          emailPreferences: { ...formData.emailPreferences, poolUpdates: checked as boolean },
                        })
                      }
                    />
                    <Label htmlFor="poolUpdates" className="text-sm">
                      Pool updates and announcements
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="votingAlerts"
                      checked={formData.emailPreferences.votingAlerts}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          emailPreferences: { ...formData.emailPreferences, votingAlerts: checked as boolean },
                        })
                      }
                    />
                    <Label htmlFor="votingAlerts" className="text-sm">
                      Voting alerts and community decisions
                    </Label>
                  </div>
                </div>
              </div>

              <Button
                className="w-full bg-red-600 hover:bg-red-700"
                onClick={handleCompleteSignup}
                disabled={!formData.firstName || !formData.lastName || !formData.city || !formData.zipCode}
              >
                Complete Email Signup
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
