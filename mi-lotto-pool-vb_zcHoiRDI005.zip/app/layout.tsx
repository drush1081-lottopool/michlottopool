import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Michigan Lotto Pool - Join Michigan's Premier Lottery Pool",
  description:
    "Pool resources with up to 5,000 Michigan residents and maximize your chances of winning the 4-digit lottery. Get daily numbers by email, secure payments, and democratic pool management.",
  keywords: "Michigan lottery, lottery pool, 4-digit lottery, Michigan residents, lottery numbers, email notifications",
  authors: [{ name: "Michigan Lotto Pool" }],
  creator: "Michigan Lotto Pool",
  publisher: "Michigan Lotto Pool",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://milottopool.com"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Michigan Lotto Pool - Join Michigan's Premier Lottery Pool",
    description:
      "Pool resources with up to 5,000 Michigan residents and maximize your chances of winning the 4-digit lottery.",
    url: "https://milottopool.com",
    siteName: "Michigan Lotto Pool",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Michigan Lotto Pool",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Michigan Lotto Pool - Join Michigan's Premier Lottery Pool",
    description:
      "Pool resources with up to 5,000 Michigan residents and maximize your chances of winning the 4-digit lottery.",
    images: ["/og-image.jpg"],
  },
  verification: {
    google: "your-google-verification-code",
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta name="theme-color" content="#dc2626" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
