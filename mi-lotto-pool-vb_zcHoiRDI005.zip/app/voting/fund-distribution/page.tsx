"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, DollarSign, Users, Clock, MessageSquare } from "lucide-react"
import Link from "next/link"

export default function FundDistributionVotePage() {
  const [selectedOption, setSelectedOption] = useState("")
  const [comment, setComment] = useState("")
  const [hasVoted, setHasVoted] = useState(false)

  const distributionOptions = [
    {
      id: "equal",
      title: "Equal Split Distribution",
      description: "All winnings are divided equally among all pool members regardless of investment amount",
      votes: 1456,
      percentage: 51,
      pros: ["Simple and fair", "Encourages participation", "No complex calculations"],
      cons: ["Doesn't reward higher investment", "May discourage large investors"],
      example: "If pool wins $10,000 with 100 members, each gets $100",
    },
    {
      id: "investment",
      title: "Investment-Based Distribution",
      description: "Winnings distributed proportionally based on each member's total investment amount",
      votes: 892,
      percentage: 31,
      pros: ["Rewards higher investment", "Proportional to risk taken", "Encourages larger contributions"],
      cons: ["Complex calculations", "May exclude smaller investors", "Creates inequality"],
      example: "If you invested $50 out of $5,000 total, you get 1% of winnings",
    },
    {
      id: "hybrid",
      title: "Hybrid Distribution Model",
      description: "50% of winnings split equally, 50% distributed based on investment amounts",
      votes: 499,
      percentage: 18,
      pros: ["Balances fairness and investment", "Partial reward for higher investment", "Compromise solution"],
      cons: ["Still complex", "May not satisfy either group fully"],
      example: "50% split equally, 50% by investment ratio",
    },
  ]

  const handleVote = () => {
    if (selectedOption) {
      setHasVoted(true)
    }
  }

  if (hasVoted) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-md mx-auto px-4 py-4 flex items-center">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon" className="mr-3">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold text-gray-900">Vote Submitted</h1>
          </div>
        </header>

        <div className="max-w-md mx-auto px-4 py-12 text-center">
          <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <DollarSign className="h-8 w-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Vote Submitted Successfully!</h2>
          <p className="text-gray-600 mb-6">
            Your vote on fund distribution has been recorded. Results will be implemented after voting closes.
          </p>
          <div className="space-y-3">
            <Link href="/dashboard">
              <Button className="w-full">Return to Dashboard</Button>
            </Link>
            <Link href="/voting/results">
              <Button variant="outline" className="w-full text-red-600 bg-transparent">
                View All Voting Results
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Fund Distribution Vote</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {/* Vote Info */}
        <Card className="mb-6 bg-red-50 border-red-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Detroit Metro Pool</CardTitle>
              <Badge className="bg-red-100 text-red-800">
                <Clock className="h-3 w-3 mr-1" />2 days left
              </Badge>
            </div>
            <CardDescription>Fund Distribution Method Vote</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-red-600" />
                <div>
                  <p className="text-gray-600">Total Voters</p>
                  <p className="font-bold">2,847</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-gray-600">Pool Fund</p>
                  <p className="font-bold">$142,350</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Results */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Current Results</CardTitle>
            <CardDescription>Live voting results • Updates every 5 minutes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {distributionOptions.map((option) => (
              <div key={option.id} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{option.title}</span>
                  <span className="text-gray-600">
                    {option.votes} votes ({option.percentage}%)
                  </span>
                </div>
                <Progress value={option.percentage} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Voting Form */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Cast Your Vote</CardTitle>
            <CardDescription>Choose your preferred fund distribution method</CardDescription>
          </CardHeader>
          <CardContent>
            <RadioGroup value={selectedOption} onValueChange={setSelectedOption}>
              {distributionOptions.map((option) => (
                <div key={option.id} className="space-y-3">
                  <div className="flex items-start space-x-3 p-4 border rounded-lg">
                    <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor={option.id} className="font-medium cursor-pointer">
                        {option.title}
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">{option.description}</p>

                      {/* Example */}
                      <div className="mt-2 p-2 bg-gray-50 rounded text-xs">
                        <p className="font-medium text-gray-700">Example:</p>
                        <p className="text-gray-600">{option.example}</p>
                      </div>

                      {/* Pros and Cons */}
                      <div className="mt-3 grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <p className="font-medium text-green-700 mb-1">Pros:</p>
                          <ul className="text-green-600 space-y-1">
                            {option.pros.map((pro, index) => (
                              <li key={index}>• {pro}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <p className="font-medium text-red-700 mb-1">Cons:</p>
                          <ul className="text-red-600 space-y-1">
                            {option.cons.map((con, index) => (
                              <li key={index}>• {con}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Comment Section */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <MessageSquare className="h-5 w-5" />
              <span>Add Comment (Optional)</span>
            </CardTitle>
            <CardDescription>Share your thoughts on the distribution methods</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Explain your choice or suggest improvements..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="min-h-[100px]"
            />
          </CardContent>
        </Card>

        {/* Submit Vote */}
        <div className="space-y-3">
          <Button className="w-full bg-red-600 hover:bg-red-700" onClick={handleVote} disabled={!selectedOption}>
            Submit Vote
          </Button>
          <p className="text-xs text-gray-500 text-center">
            Your vote is anonymous and cannot be changed once submitted
          </p>
        </div>
      </div>
    </div>
  )
}
