"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, TrendingUp, Clock, CheckCircle, Users } from "lucide-react"
import Link from "next/link"

export default function VotingResultsPage() {
  const activeVotes = [
    {
      id: 1,
      title: "Fund Distribution Method",
      pool: "Detroit Metro Pool",
      totalVotes: 2847,
      timeLeft: "2 days",
      status: "active",
      results: [
        { option: "Equal Split", votes: 1456, percentage: 51 },
        { option: "Investment-Based", votes: 892, percentage: 31 },
        { option: "Hybrid Model", votes: 499, percentage: 18 },
      ],
    },
    {
      id: 2,
      title: "Minimum Investment Change",
      pool: "Detroit Metro Pool",
      totalVotes: 2847,
      timeLeft: "3 days",
      status: "active",
      results: [
        { option: "Keep $5 minimum", votes: 1613, percentage: 57 },
        { option: "Increase to $10", votes: 1234, percentage: 43 },
      ],
    },
  ]

  const completedVotes = [
    {
      id: 3,
      title: "Pool Size Expansion",
      pool: "Detroit Metro Pool",
      completedDate: "Dec 28, 2024",
      totalVotes: 2756,
      status: "passed",
      winningOption: "Expand to 5,000 members",
      results: [
        { option: "Expand to 5,000 members", votes: 1654, percentage: 60 },
        { option: "Keep at 3,000 members", votes: 1102, percentage: 40 },
      ],
    },
    {
      id: 4,
      title: "Weekly vs Bi-weekly Draws",
      pool: "Grand Rapids Winners",
      completedDate: "Dec 20, 2024",
      totalVotes: 1523,
      status: "passed",
      winningOption: "Weekly draws",
      results: [
        { option: "Weekly draws", votes: 914, percentage: 60 },
        { option: "Bi-weekly draws", votes: 609, percentage: 40 },
      ],
    },
    {
      id: 5,
      title: "Emergency Fund Creation",
      pool: "Ann Arbor University Pool",
      completedDate: "Dec 15, 2024",
      totalVotes: 892,
      status: "failed",
      winningOption: "No emergency fund",
      results: [
        { option: "No emergency fund", votes: 534, percentage: 60 },
        { option: "Create 5% emergency fund", votes: 358, percentage: 40 },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Voting Results</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        <Tabs defaultValue="active" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="active">Active Votes</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Active Voting</h2>
              <Badge variant="secondary">{activeVotes.length} active</Badge>
            </div>

            {activeVotes.map((vote) => (
              <Card key={vote.id} className="border-l-4 border-l-red-500">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{vote.title}</CardTitle>
                    <Badge className="bg-red-100 text-red-800">
                      <Clock className="h-3 w-3 mr-1" />
                      {vote.timeLeft}
                    </Badge>
                  </div>
                  <CardDescription>{vote.pool}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center space-x-1">
                      <Users className="h-4 w-4 text-gray-500" />
                      <span>{vote.totalVotes.toLocaleString()} total votes</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <TrendingUp className="h-4 w-4 text-green-500" />
                      <span>Live results</span>
                    </span>
                  </div>

                  <div className="space-y-3">
                    {vote.results.map((result, index) => (
                      <div key={index} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">{result.option}</span>
                          <span className="text-gray-600">
                            {result.votes} votes ({result.percentage}%)
                          </span>
                        </div>
                        <Progress value={result.percentage} className="h-2" />
                      </div>
                    ))}
                  </div>

                  <Link href={vote.id === 1 ? "/voting/fund-distribution" : "#"}>
                    <Button variant="outline" className="w-full bg-transparent">
                      View Details & Vote
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="completed" className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Completed Votes</h2>
              <Badge variant="secondary">{completedVotes.length} completed</Badge>
            </div>

            {completedVotes.map((vote) => (
              <Card
                key={vote.id}
                className={`border-l-4 ${vote.status === "passed" ? "border-l-green-500" : "border-l-red-500"}`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{vote.title}</CardTitle>
                    <Badge
                      variant={vote.status === "passed" ? "default" : "secondary"}
                      className={vote.status === "passed" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      {vote.status}
                    </Badge>
                  </div>
                  <CardDescription>
                    {vote.pool} • Completed {vote.completedDate}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm font-medium text-gray-900">Winning Option:</p>
                    <p className="text-sm text-gray-700">{vote.winningOption}</p>
                  </div>

                  <div className="text-sm text-gray-600 mb-3">
                    <span className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{vote.totalVotes.toLocaleString()} total votes</span>
                    </span>
                  </div>

                  <div className="space-y-2">
                    {vote.results.map((result, index) => (
                      <div key={index} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className={`${index === 0 ? "font-medium" : ""}`}>{result.option}</span>
                          <span className="text-gray-600">
                            {result.votes} votes ({result.percentage}%)
                          </span>
                        </div>
                        <Progress value={result.percentage} className={`h-2 ${index === 0 ? "bg-green-100" : ""}`} />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}

            <div className="text-center py-4">
              <Button variant="outline">Load More History</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
