"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, Plus, Trash2, Vote } from "lucide-react"
import Link from "next/link"

export default function CreateVotePage() {
  const [voteType, setVoteType] = useState("")
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [duration, setDuration] = useState("")
  const [options, setOptions] = useState(["", ""])
  const [requiresMinimum, setRequiresMinimum] = useState(false)

  const addOption = () => {
    setOptions([...options, ""])
  }

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index))
    }
  }

  const updateOption = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  const voteTypes = [
    { id: "fund-distribution", label: "Fund Distribution", description: "How winnings should be distributed" },
    { id: "pool-management", label: "Pool Management", description: "Changes to pool rules or operations" },
    { id: "administrator", label: "Administrator Election", description: "Choose pool administrators" },
    { id: "policy", label: "Policy Change", description: "Modify pool policies or procedures" },
    { id: "other", label: "Other", description: "Custom voting topic" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Create Vote</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {/* Admin Notice */}
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Vote className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <p className="font-medium text-blue-900">Pool Administrator</p>
                <p className="text-sm text-blue-700">
                  Only pool administrators can create new votes. All votes require approval before going live.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <form className="space-y-6">
          {/* Vote Type */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Vote Type</CardTitle>
              <CardDescription>Select the type of vote you want to create</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup value={voteType} onValueChange={setVoteType}>
                {voteTypes.map((type) => (
                  <div key={type.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                    <RadioGroupItem value={type.id} id={type.id} className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor={type.id} className="font-medium cursor-pointer">
                        {type.label}
                      </Label>
                      <p className="text-sm text-gray-600">{type.description}</p>
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Basic Information */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Vote Details</CardTitle>
              <CardDescription>Provide the basic information for your vote</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Vote Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Change Fund Distribution Method"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Explain what this vote is about and why it's important..."
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="duration">Voting Duration</Label>
                <Select onValueChange={setDuration}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select voting period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 days</SelectItem>
                    <SelectItem value="7">1 week</SelectItem>
                    <SelectItem value="14">2 weeks</SelectItem>
                    <SelectItem value="30">1 month</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Vote Options */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Vote Options</CardTitle>
              <CardDescription>Add the options that members can vote on</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="flex-1">
                    <Input
                      value={option}
                      onChange={(e) => updateOption(index, e.target.value)}
                      placeholder={`Option ${index + 1}`}
                    />
                  </div>
                  {options.length > 2 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeOption(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}

              {options.length < 5 && (
                <Button type="button" variant="outline" onClick={addOption} className="w-full bg-transparent">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Option
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Advanced Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Advanced Settings</CardTitle>
              <CardDescription>Additional voting requirements and settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox id="minimum" checked={requiresMinimum} onCheckedChange={setRequiresMinimum} />
                <Label htmlFor="minimum" className="text-sm">
                  Require minimum 50% participation to pass
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="anonymous" defaultChecked />
                <Label htmlFor="anonymous" className="text-sm">
                  Anonymous voting (recommended)
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="comments" />
                <Label htmlFor="comments" className="text-sm">
                  Allow comments on vote
                </Label>
              </div>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="space-y-3">
            <Button className="w-full" disabled={!voteType || !title || options.some((opt) => !opt.trim())}>
              Submit for Approval
            </Button>
            <p className="text-xs text-gray-500 text-center">
              Your vote will be reviewed by pool administrators before going live
            </p>
          </div>
        </form>
      </div>
    </div>
  )
}
