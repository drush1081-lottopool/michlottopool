"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Vote, Clock } from "lucide-react"
import Link from "next/link"
import { CommentsSection } from "@/components/ui/comments-section"

export default function VoteDetailsPage() {
  const vote = {
    id: "1",
    title: "Fund Distribution Method",
    description: "Vote on how winning funds should be distributed among pool members for the next 6 months.",
    poolName: "Detroit Metro Pool",
    endsIn: "2 days",
    totalVotes: 2847,
    options: [
      {
        id: 1,
        title: "Equal Split (Current)",
        description: "All winnings split equally among all members",
        votes: 1456,
        percentage: 51,
      },
      {
        id: 2,
        title: "Investment-Based",
        description: "Distribution based on individual investment amounts",
        votes: 892,
        percentage: 31,
      },
      {
        id: 3,
        title: "Hybrid Model",
        description: "50% equal split, 50% investment-based",
        votes: 499,
        percentage: 18,
      },
    ],
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{vote.title}</h1>
            <p className="text-sm text-gray-600">{vote.poolName}</p>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <Card className="border-red-500">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Vote className="h-5 w-5 text-red-600" />
                <span>Community Vote</span>
              </CardTitle>
              <Badge className="bg-red-100 text-red-800">High Priority</Badge>
            </div>
            <CardDescription>
              <div className="flex items-center space-x-2 mt-2">
                <Clock className="h-4 w-4" />
                <span>Ends in {vote.endsIn}</span>
              </div>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">{vote.description}</p>
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">
                <strong>{vote.totalVotes.toLocaleString()}</strong> members have voted so far
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Voting Options</CardTitle>
            <CardDescription>Select your preferred option</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {vote.options.map((option) => (
              <div
                key={option.id}
                className="p-4 border rounded-lg hover:border-red-500 cursor-pointer transition-colors"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">{option.title}</h3>
                    <p className="text-sm text-gray-600">{option.description}</p>
                  </div>
                  <Badge variant="secondary">{option.votes.toLocaleString()} votes</Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Support</span>
                    <span className="font-medium">{option.percentage}%</span>
                  </div>
                  <Progress value={option.percentage} className="h-2" />
                </div>
                <Button className="w-full mt-3">Vote for this option</Button>
              </div>
            ))}
          </CardContent>
        </Card>

        <CommentsSection voteId={vote.id} title="Discussion & Comments" />
      </div>
    </div>
  )
}
