"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, AlertTriangle, Loader2 } from "lucide-react"
import { CustomButton } from "@/components/ui/custom-button"

interface ReadinessCheck {
  ready: boolean
  checks: {
    database: boolean
    email: boolean
    payments: boolean
    storage: boolean
    security: boolean
  }
  errors: string[]
  message: string
}

export default function SetupPage() {
  const [readiness, setReadiness] = useState<ReadinessCheck | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkReadiness()
  }, [])

  const checkReadiness = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/setup/check-readiness")
      const data = await response.json()
      setReadiness(data)
    } catch (error) {
      console.error("Failed to check readiness:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-red-50 p-4">
      <div className="max-w-4xl mx-auto py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent mb-4">
            Michigan Lotto Pool Setup
          </h1>
          <p className="text-gray-600">System Readiness Check</p>
        </div>

        {loading ? (
          <Card className="card-custom">
            <CardContent className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
              <span className="ml-3 text-gray-600">Checking system status...</span>
            </CardContent>
          </Card>
        ) : readiness ? (
          <>
            <Card className="card-custom mb-6">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Overall Status</CardTitle>
                  {readiness.ready ? (
                    <Badge className="bg-green-500">Ready to Launch</Badge>
                  ) : (
                    <Badge className="bg-red-500">Configuration Needed</Badge>
                  )}
                </div>
                <CardDescription>{readiness.message}</CardDescription>
              </CardHeader>
            </Card>

            <div className="grid gap-4 mb-6">
              <CheckItem
                title="Database Connection"
                description="PostgreSQL database configured and accessible"
                status={readiness.checks.database}
              />
              <CheckItem
                title="Email Service"
                description="Email provider configured for daily notifications"
                status={readiness.checks.email}
              />
              <CheckItem
                title="Payment Processing"
                description="Stripe configured for payments and payouts"
                status={readiness.checks.payments}
              />
              <CheckItem
                title="File Storage"
                description="Document storage for KYC and tax documents"
                status={readiness.checks.storage}
              />
              <CheckItem
                title="Security Configuration"
                description="JWT secrets and cron authentication configured"
                status={readiness.checks.security}
              />
            </div>

            {readiness.errors.length > 0 && (
              <Card className="card-custom mb-6 border-red-200">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-600">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    Configuration Errors
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {readiness.errors.map((error, index) => (
                      <li key={index} className="text-sm text-red-600 flex items-start">
                        <XCircle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                        {error}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            <Card className="card-custom">
              <CardHeader>
                <CardTitle>Next Steps</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-semibold text-sm">1. Review Deployment Guide</h3>
                  <p className="text-sm text-gray-600">
                    Read <code className="bg-gray-100 px-2 py-1 rounded">DEPLOYMENT_GUIDE.md</code> for complete setup
                    instructions
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-semibold text-sm">2. Configure Environment Variables</h3>
                  <p className="text-sm text-gray-600">
                    Copy <code className="bg-gray-100 px-2 py-1 rounded">.env.example</code> to{" "}
                    <code className="bg-gray-100 px-2 py-1 rounded">.env.local</code> and fill in all values
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-semibold text-sm">3. Run Database Scripts</h3>
                  <p className="text-sm text-gray-600">
                    Execute SQL scripts in <code className="bg-gray-100 px-2 py-1 rounded">scripts/</code> folder in
                    your database
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-semibold text-sm">4. Complete Legal Requirements</h3>
                  <p className="text-sm text-gray-600">
                    Consult with Michigan gaming attorney and obtain necessary licenses before accepting payments
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-semibold text-sm">5. Test All Features</h3>
                  <p className="text-sm text-gray-600">Run closed beta with friends/family before public launch</p>
                </div>

                <CustomButton onClick={checkReadiness} className="w-full mt-6">
                  Re-check System Status
                </CustomButton>
              </CardContent>
            </Card>
          </>
        ) : null}
      </div>
    </div>
  )
}

function CheckItem({ title, description, status }: { title: string; description: string; status: boolean }) {
  return (
    <Card className="card-custom">
      <CardContent className="flex items-start justify-between py-4">
        <div className="flex-1">
          <h3 className="font-semibold mb-1">{title}</h3>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
        {status ? (
          <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0 ml-4" />
        ) : (
          <XCircle className="h-6 w-6 text-red-500 flex-shrink-0 ml-4" />
        )}
      </CardContent>
    </Card>
  )
}
