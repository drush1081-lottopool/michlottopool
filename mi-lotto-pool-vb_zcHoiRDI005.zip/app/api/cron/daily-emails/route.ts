import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    // Verify cron job authentication
    const authHeader = request.headers.get("authorization")
    const cronSecret = process.env.CRON_SECRET || "default-secret"

    if (authHeader !== `Bearer ${cronSecret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Trigger daily email sending
    const response = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/api/email/daily-numbers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    })

    const result = await response.json()

    return NextResponse.json(
      {
        success: true,
        message: "Daily emails triggered successfully",
        result,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Cron job error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
