import { NextResponse } from "next/server"

// System readiness check endpoint
export async function GET() {
  const checks = {
    database: false,
    email: false,
    payments: false,
    storage: false,
    security: false,
  }

  const errors: string[] = []

  // Check database connection
  try {
    if (process.env.DATABASE_URL) {
      checks.database = true
    } else {
      errors.push("DATABASE_URL not configured")
    }
  } catch (error) {
    errors.push("Database connection failed")
  }

  // Check email service
  if (process.env.RESEND_API_KEY || process.env.SENDGRID_API_KEY || process.env.AWS_ACCESS_KEY_ID) {
    checks.email = true
  } else {
    errors.push("Email service not configured")
  }

  // Check payment processing
  if (process.env.STRIPE_SECRET_KEY && process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) {
    checks.payments = true
  } else {
    errors.push("Stripe not configured")
  }

  // Check file storage
  if (process.env.BLOB_READ_WRITE_TOKEN || process.env.AWS_S3_BUCKET) {
    checks.storage = true
  } else {
    errors.push("File storage not configured")
  }

  // Check security settings
  if (process.env.JWT_SECRET && process.env.CRON_SECRET) {
    checks.security = true
  } else {
    errors.push("Security secrets not configured")
  }

  const allReady = Object.values(checks).every((check) => check === true)

  return NextResponse.json({
    ready: allReady,
    checks,
    errors,
    message: allReady ? "System is ready for deployment!" : "Please complete missing configuration before launching",
  })
}
