import { type NextRequest, NextResponse } from "next/server"

// Mock data
const emailSubscribers: any[] = []
const pools: any[] = [
  { id: "detroit", name: "Detroit Metro Pool", drawTime: "7:29 PM EST" },
  { id: "grandrapids", name: "Grand Rapids Winners", drawTime: "7:29 PM EST" },
  { id: "annarbor", name: "Ann Arbor University Pool", drawTime: "7:29 PM EST" },
]

export async function POST(request: NextRequest) {
  try {
    // This would typically be called by a cron job
    const today = new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    let emailsSent = 0

    for (const subscriber of emailSubscribers) {
      if (subscriber.subscribed && subscriber.emailPreferences.dailyNumbers) {
        const pool = pools.find((p) => p.id === subscriber.selectedPool)
        const numbers = generateDailyNumbers(subscriber.id)

        await sendDailyNumbersEmail(subscriber, pool, numbers, today)
        emailsSent++
      }
    }

    return NextResponse.json(
      {
        message: `Daily numbers sent to ${emailsSent} subscribers`,
        date: today,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Daily numbers error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

function generateDailyNumbers(subscriberId: string): string[] {
  // Generate 5 random 4-digit numbers for the subscriber
  const numbers: string[] = []
  const seed = Number.parseInt(subscriberId) + new Date().getDate()

  for (let i = 0; i < 5; i++) {
    const num = ((seed * (i + 1) * 1234) % 10000).toString().padStart(4, "0")
    numbers.push(num)
  }

  return numbers
}

async function sendDailyNumbersEmail(subscriber: any, pool: any, numbers: string[], date: string) {
  // Mock email sending - replace with actual email service
  const emailContent = {
    to: subscriber.email,
    subject: `Your Daily Numbers - ${date}`,
    html: generateEmailHTML(subscriber, pool, numbers, date),
  }

  console.log(`Daily numbers email sent to ${subscriber.email}`)
  return true
}

function generateEmailHTML(subscriber: any, pool: any, numbers: string[], date: string): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Your Daily Numbers - ${date}</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f8fafc; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #dc2626, #2563eb); color: white; padding: 20px; text-align: center; }
        .content { padding: 30px; }
        .numbers-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0; }
        .number-box { background: #fef2f2; border: 2px solid #fecaca; border-radius: 8px; padding: 15px; text-align: center; }
        .number { font-size: 24px; font-weight: bold; color: #dc2626; font-family: monospace; }
        .pool-info { background: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0; }
        .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🏆 MI Lotto Pool</h1>
          <p>Your Daily Numbers</p>
        </div>
        <div class="content">
          <h2>Good morning, ${subscriber.firstName}! 🌅</h2>
          <p>Here are your lottery numbers for ${date}:</p>
          
          <div class="numbers-grid">
            ${numbers.map((num) => `<div class="number-box"><div class="number">${num}</div></div>`).join("")}
          </div>
          
          <div class="pool-info">
            <strong>Pool:</strong> ${pool?.name || "Unknown Pool"}<br>
            <strong>Draw Time:</strong> ${pool?.drawTime || "7:29 PM EST"}
          </div>
          
          <p style="text-align: center; font-size: 18px; margin: 30px 0;">
            <strong>Good luck! 🍀</strong>
          </p>
          
          <p style="text-align: center; color: #6b7280;">
            Results will be sent after tonight's draw
          </p>
        </div>
        <div class="footer">
          <p>Michigan Lotto Pool | <a href="https://milottopool.com/email-preferences">Manage Preferences</a> | <a href="https://milottopool.com/unsubscribe">Unsubscribe</a></p>
        </div>
      </div>
    </body>
    </html>
  `
}
