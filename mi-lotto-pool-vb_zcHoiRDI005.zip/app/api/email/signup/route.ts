import { type NextRequest, NextResponse } from "next/server"

// Mock database for email subscribers
const emailSubscribers: any[] = []

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, firstName, lastName, phone, city, zipCode, selectedPool, emailPreferences } = body

    // Validation
    if (!email || !firstName || !lastName || !selectedPool) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if email already exists
    const existingSubscriber = emailSubscribers.find((sub) => sub.email === email)
    if (existingSubscriber) {
      return NextResponse.json({ error: "Email already subscribed" }, { status: 409 })
    }

    // Create subscriber
    const newSubscriber = {
      id: Date.now().toString(),
      email,
      firstName,
      lastName,
      phone,
      city,
      zipCode,
      selectedPool,
      emailPreferences: emailPreferences || {
        dailyNumbers: true,
        drawResults: true,
        poolUpdates: true,
        votingAlerts: true,
      },
      subscribed: true,
      createdAt: new Date().toISOString(),
    }

    emailSubscribers.push(newSubscriber)

    // Send welcome email
    await sendWelcomeEmail(newSubscriber)

    return NextResponse.json(
      {
        message: "Email signup successful",
        subscriberId: newSubscriber.id,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Email signup error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function sendWelcomeEmail(subscriber: any) {
  // Mock email sending
  console.log(`Welcome email sent to ${subscriber.email}`)

  // In production, integrate with email service
  return true
}
