import { type NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"

// Mock database - replace with actual database
const users: any[] = []

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { firstName, lastName, email, phone, address, city, zipCode, password, terms, michigan, dailyEmail } = body

    // Validation
    if (!firstName || !lastName || !email || !password) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    if (!terms || !michigan) {
      return NextResponse.json({ error: "Must agree to terms and verify Michigan residency" }, { status: 400 })
    }

    // Check if user already exists
    const existingUser = users.find((user) => user.email === email)
    if (existingUser) {
      return NextResponse.json({ error: "User already exists" }, { status: 409 })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const newUser = {
      id: Date.now().toString(),
      firstName,
      lastName,
      email,
      phone,
      address,
      city,
      zipCode,
      password: hashedPassword,
      emailPreferences: {
        dailyNumbers: dailyEmail,
        drawResults: true,
        poolUpdates: true,
        votingAlerts: true,
      },
      verified: false,
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)

    // Generate verification token
    const verificationToken = jwt.sign(
      { userId: newUser.id, email: newUser.email },
      process.env.JWT_SECRET || "fallback-secret",
      { expiresIn: "24h" },
    )

    // Send verification email (mock)
    await sendVerificationEmail(email, verificationToken)

    return NextResponse.json(
      {
        message: "User registered successfully. Please check your email for verification.",
        userId: newUser.id,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function sendVerificationEmail(email: string, token: string) {
  // Mock email sending - replace with actual email service
  console.log(`Verification email sent to ${email} with token: ${token}`)

  // In production, use a service like:
  // - SendGrid
  // - AWS SES
  // - Nodemailer with SMTP

  return true
}
