"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Mail, Clock, Bell, Settings, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function EmailPreferencesPage() {
  const [preferences, setPreferences] = useState({
    dailyNumbers: true,
    drawResults: true,
    poolUpdates: true,
    votingAlerts: true,
    winningAlerts: true,
    paymentReminders: true,
  })

  const [schedule, setSchedule] = useState({
    dailyTime: "08:00",
    timezone: "EST",
    frequency: "daily",
  })

  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Email Preferences</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6">
        {/* Success Message */}
        {saved && (
          <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center space-x-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <p className="text-sm text-green-700">Preferences saved successfully!</p>
          </div>
        )}

        {/* Email Types */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Mail className="h-5 w-5 text-red-600" />
              <span>Email Notifications</span>
            </CardTitle>
            <CardDescription>Choose which emails you'd like to receive</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start space-x-3 p-3 border rounded-lg">
                <Checkbox
                  id="dailyNumbers"
                  checked={preferences.dailyNumbers}
                  onCheckedChange={(checked) => setPreferences({ ...preferences, dailyNumbers: checked as boolean })}
                />
                <div className="flex-1">
                  <Label htmlFor="dailyNumbers" className="font-medium cursor-pointer">
                    Daily Lottery Numbers
                  </Label>
                  <p className="text-sm text-gray-600">Your assigned numbers sent every morning</p>
                  <Badge className="mt-1 bg-red-100 text-red-800">Essential</Badge>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 border rounded-lg">
                <Checkbox
                  id="drawResults"
                  checked={preferences.drawResults}
                  onCheckedChange={(checked) => setPreferences({ ...preferences, drawResults: checked as boolean })}
                />
                <div className="flex-1">
                  <Label htmlFor="drawResults" className="font-medium cursor-pointer">
                    Draw Results
                  </Label>
                  <p className="text-sm text-gray-600">Winning numbers and pool results</p>
                  <Badge className="mt-1 bg-blue-100 text-blue-800">Recommended</Badge>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 border rounded-lg">
                <Checkbox
                  id="winningAlerts"
                  checked={preferences.winningAlerts}
                  onCheckedChange={(checked) => setPreferences({ ...preferences, winningAlerts: checked as boolean })}
                />
                <div className="flex-1">
                  <Label htmlFor="winningAlerts" className="font-medium cursor-pointer">
                    Winning Alerts
                  </Label>
                  <p className="text-sm text-gray-600">Immediate notifications when you win</p>
                  <Badge className="mt-1 bg-green-100 text-green-800">Important</Badge>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 border rounded-lg">
                <Checkbox
                  id="poolUpdates"
                  checked={preferences.poolUpdates}
                  onCheckedChange={(checked) => setPreferences({ ...preferences, poolUpdates: checked as boolean })}
                />
                <div className="flex-1">
                  <Label htmlFor="poolUpdates" className="font-medium cursor-pointer">
                    Pool Updates
                  </Label>
                  <p className="text-sm text-gray-600">Pool announcements and changes</p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 border rounded-lg">
                <Checkbox
                  id="votingAlerts"
                  checked={preferences.votingAlerts}
                  onCheckedChange={(checked) => setPreferences({ ...preferences, votingAlerts: checked as boolean })}
                />
                <div className="flex-1">
                  <Label htmlFor="votingAlerts" className="font-medium cursor-pointer">
                    Voting Alerts
                  </Label>
                  <p className="text-sm text-gray-600">New votes and community decisions</p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 border rounded-lg">
                <Checkbox
                  id="paymentReminders"
                  checked={preferences.paymentReminders}
                  onCheckedChange={(checked) =>
                    setPreferences({ ...preferences, paymentReminders: checked as boolean })
                  }
                />
                <div className="flex-1">
                  <Label htmlFor="paymentReminders" className="font-medium cursor-pointer">
                    Payment Reminders
                  </Label>
                  <p className="text-sm text-gray-600">Reminders for upcoming payments</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Email Schedule */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Clock className="h-5 w-5 text-blue-600" />
              <span>Email Schedule</span>
            </CardTitle>
            <CardDescription>Customize when you receive your daily numbers</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dailyTime">Daily Numbers Time</Label>
                <Input
                  id="dailyTime"
                  type="time"
                  value={schedule.dailyTime}
                  onChange={(e) => setSchedule({ ...schedule, dailyTime: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="timezone">Timezone</Label>
                <Select
                  value={schedule.timezone}
                  onValueChange={(value) => setSchedule({ ...schedule, timezone: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EST">Eastern (EST)</SelectItem>
                    <SelectItem value="CST">Central (CST)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="frequency">Email Frequency</Label>
              <Select
                value={schedule.frequency}
                onValueChange={(value) => setSchedule({ ...schedule, frequency: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly Summary</SelectItem>
                  <SelectItem value="draw-days">Draw Days Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Email Preview */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Email Preview</CardTitle>
            <CardDescription>See what your daily numbers email will look like</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg border">
              <div className="text-sm">
                <div className="font-medium text-gray-900 mb-2">Subject: Your Daily Numbers - Jan 8, 2025</div>
                <div className="text-gray-600 space-y-2">
                  <p>
                    <strong>Good morning, John!</strong>
                  </p>
                  <p>Here are your lottery numbers for today's draw:</p>
                  <div className="bg-white p-3 rounded border my-3">
                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div className="font-mono font-bold text-red-600">1234</div>
                      <div className="font-mono font-bold text-red-600">5678</div>
                      <div className="font-mono font-bold text-red-600">9012</div>
                      <div className="font-mono font-bold text-red-600">3456</div>
                    </div>
                  </div>
                  <p>
                    <strong>Pool:</strong> Detroit Metro Pool
                  </p>
                  <p>
                    <strong>Draw Time:</strong> 7:29 PM EST
                  </p>
                  <p>Good luck! 🍀</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="space-y-3">
          <Button className="w-full bg-red-600 hover:bg-red-700" onClick={handleSave}>
            <Settings className="h-4 w-4 mr-2" />
            Save Preferences
          </Button>

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="bg-transparent">
              <Mail className="h-4 w-4 mr-2" />
              Test Email
            </Button>
            <Button variant="outline" className="bg-transparent">
              <Bell className="h-4 w-4 mr-2" />
              Unsubscribe
            </Button>
          </div>
        </div>

        {/* Help */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <h4 className="font-medium text-blue-900 mb-2">Email Delivery Tips</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Check your spam folder if emails don't arrive</li>
              <li>• Add noreply@milottopool.com to your contacts</li>
              <li>• Emails are sent Monday through Sunday</li>
              <li>• Contact support if you miss multiple emails</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
