"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Trophy } from "lucide-react"

interface DailyEmailPreviewProps {
  userName?: string
  poolName?: string
  numbers?: string[]
  drawTime?: string
  date?: string
}

export default function DailyEmailPreview({
  userName = "John",
  poolName = "Detroit Metro Pool",
  numbers = ["1234", "5678", "9012", "3456", "7890"],
  drawTime = "7:29 PM EST",
  date = "January 8, 2025",
}: DailyEmailPreviewProps) {
  return (
    <Card className="max-w-md mx-auto bg-white border-2 border-gray-200">
      {/* Email Header */}
      <CardHeader className="bg-gradient-to-r from-red-600 to-blue-600 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Trophy className="h-5 w-5" />
            <span className="font-bold">MI Lotto Pool</span>
          </div>
          <Badge className="bg-white text-red-600">Daily Numbers</Badge>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {/* Greeting */}
        <div className="mb-4">
          <h2 className="text-xl font-bold text-gray-900">Good morning, {userName}! 🌅</h2>
          <p className="text-gray-600">Here are your lottery numbers for {date}</p>
        </div>

        {/* Numbers Display */}
        <div className="bg-gradient-to-br from-red-50 to-blue-50 p-4 rounded-lg mb-4">
          <h3 className="font-semibold text-gray-900 mb-3 text-center">Your Numbers</h3>
          <div className="grid grid-cols-2 gap-3">
            {numbers.map((number, index) => (
              <div key={index} className="bg-white p-3 rounded-lg border-2 border-red-200 text-center">
                <div className="text-2xl font-bold font-mono text-red-600">{number}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Pool Info */}
        <div className="bg-blue-50 p-4 rounded-lg mb-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-600">Pool</p>
              <p className="font-semibold text-blue-900">{poolName}</p>
            </div>
            <div>
              <p className="text-gray-600">Draw Time</p>
              <p className="font-semibold text-blue-900 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                {drawTime}
              </p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center space-y-2">
          <p className="text-lg font-semibold text-gray-900">Good luck! 🍀</p>
          <p className="text-sm text-gray-600">Results will be sent after tonight's draw</p>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-gray-200 text-center">
          <p className="text-xs text-gray-500">Michigan Lotto Pool • Manage preferences • Unsubscribe</p>
        </div>
      </CardContent>
    </Card>
  )
}
