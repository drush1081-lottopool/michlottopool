"use client"

import { FileText, Scale, MapPin, Calendar, Info } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function LegalCompliance() {
  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center space-x-2 text-blue-800">
          <Scale className="h-5 w-5" />
          <span>Legal & Compliance</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-2 text-sm text-blue-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Michigan Gaming License</span>
            </div>
            <Badge className="bg-green-100 text-green-800 text-xs">Active</Badge>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4" />
              <span>Michigan Residents Only</span>
            </div>
            <Badge className="bg-blue-100 text-blue-800 text-xs">Verified</Badge>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>Age Verification (18+)</span>
            </div>
            <Badge className="bg-purple-100 text-purple-800 text-xs">Required</Badge>
          </div>
        </div>

        <div className="pt-2 border-t border-blue-200">
          <p className="text-xs text-blue-600">
            <Info className="h-3 w-3 inline mr-1" />
            Licensed by Michigan Gaming Control Board. License #LG-2024-001
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
