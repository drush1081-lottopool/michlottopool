"use client"

import { cn } from "@/lib/utils"

import { Trophy, Star, Zap } from "lucide-react"

interface MichiganLogoProps {
  size?: "sm" | "md" | "lg" | "xl"
  animated?: boolean
  variant?: "default" | "minimal" | "badge"
}

export default function MichiganLogo({ size = "md", animated = false, variant = "default" }: MichiganLogoProps) {
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-12 w-12",
    lg: "h-16 w-16",
    xl: "h-24 w-24",
  }

  const textSizeClasses = {
    sm: "text-sm",
    md: "text-lg",
    lg: "text-2xl",
    xl: "text-4xl",
  }

  if (variant === "minimal") {
    return (
      <div className="flex items-center space-x-2">
        <div
          className={cn(
            "bg-gradient-to-br from-red-600 to-blue-600 rounded-xl flex items-center justify-center",
            sizeClasses[size],
            animated && "animate-pulse-slow",
          )}
        >
          <Trophy className="h-1/2 w-1/2 text-white" />
        </div>
        <span
          className={cn(
            "font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent",
            textSizeClasses[size],
          )}
        >
          MI Lotto
        </span>
      </div>
    )
  }

  if (variant === "badge") {
    return (
      <div className="relative">
        <div
          className={cn(
            "bg-gradient-to-br from-red-600 via-blue-600 to-red-600 rounded-full p-1",
            sizeClasses[size],
            animated && "animate-spin-slow",
          )}
        >
          <div className="bg-white rounded-full h-full w-full flex items-center justify-center">
            <Trophy className="h-1/2 w-1/2 text-red-600" />
          </div>
        </div>
        <Star className="absolute -top-1 -right-1 h-4 w-4 text-yellow-400 animate-pulse" />
      </div>
    )
  }

  return (
    <div className="flex items-center space-x-3">
      <div className="relative">
        <div
          className={cn(
            "bg-gradient-to-br from-red-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg",
            sizeClasses[size],
            animated && "animate-float",
          )}
        >
          <Trophy className="h-1/2 w-1/2 text-white" />
        </div>
        <div className="absolute -top-1 -right-1">
          <Zap className="h-4 w-4 text-yellow-400 animate-pulse" />
        </div>
      </div>
      <div className="flex flex-col">
        <span
          className={cn(
            "font-bold bg-gradient-to-r from-red-600 to-blue-600 bg-clip-text text-transparent",
            textSizeClasses[size],
          )}
        >
          Michigan Lotto Pool
        </span>
        <span className="text-xs text-gray-500 font-medium">The Great Lakes State</span>
      </div>
    </div>
  )
}
