"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

interface LotteryNumberDisplayProps {
  numbers: string[]
  animated?: boolean
  size?: "sm" | "md" | "lg" | "xl"
  variant?: "default" | "gold" | "silver" | "bronze"
  showAnimation?: boolean
}

export default function LotteryNumberDisplay({
  numbers,
  animated = false,
  size = "md",
  variant = "default",
  showAnimation = false,
}: LotteryNumberDisplayProps) {
  const [displayNumbers, setDisplayNumbers] = useState<string[]>([])
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    if (showAnimation) {
      setIsAnimating(true)
      // Animate numbers appearing one by one
      numbers.forEach((number, index) => {
        setTimeout(() => {
          setDisplayNumbers((prev) => [...prev, number])
        }, index * 300)
      })

      setTimeout(
        () => {
          setIsAnimating(false)
        },
        numbers.length * 300 + 500,
      )
    } else {
      setDisplayNumbers(numbers)
    }
  }, [numbers, showAnimation])

  const sizeClasses = {
    sm: "text-lg p-2 min-w-[3rem]",
    md: "text-2xl p-3 min-w-[4rem]",
    lg: "text-3xl p-4 min-w-[5rem]",
    xl: "text-4xl p-6 min-w-[6rem]",
  }

  const variantClasses = {
    default: "bg-gradient-to-br from-red-500 to-blue-600 text-white shadow-lg",
    gold: "bg-gradient-to-br from-yellow-400 to-orange-500 text-white shadow-lg shadow-yellow-500/25",
    silver: "bg-gradient-to-br from-gray-300 to-gray-500 text-white shadow-lg shadow-gray-500/25",
    bronze: "bg-gradient-to-br from-orange-400 to-red-500 text-white shadow-lg shadow-orange-500/25",
  }

  return (
    <div className="flex flex-wrap gap-3 justify-center">
      {displayNumbers.map((number, index) => (
        <div
          key={index}
          className={cn(
            "lottery-ball font-mono font-bold rounded-xl text-center flex items-center justify-center transform transition-all duration-500",
            sizeClasses[size],
            variantClasses[variant],
            animated && "animate-bounce-slow",
            isAnimating && "animate-float",
            "hover:scale-110 hover:shadow-xl cursor-pointer",
          )}
          style={{
            animationDelay: `${index * 0.1}s`,
          }}
        >
          <span className="relative z-10">{number}</span>
        </div>
      ))}
    </div>
  )
}
