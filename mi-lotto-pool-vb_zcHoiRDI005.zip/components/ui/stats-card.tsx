"use client"

import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface StatsCardProps {
  title: string
  value: string | number
  subtitle?: string
  icon: LucideIcon
  trend?: {
    value: number
    label: string
    positive: boolean
  }
  variant?: "default" | "success" | "warning" | "error"
  animated?: boolean
}

export default function StatsCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  variant = "default",
  animated = false,
}: StatsCardProps) {
  const variantClasses = {
    default: "from-blue-500 to-purple-600",
    success: "from-green-500 to-emerald-600",
    warning: "from-yellow-400 to-orange-500",
    error: "from-red-500 to-pink-600",
  }

  return (
    <div
      className={cn(
        "card-custom p-6 relative overflow-hidden group",
        animated && "hover:scale-105 transition-transform duration-300",
      )}
    >
      {/* Background gradient */}
      <div
        className={cn(
          "absolute inset-0 bg-gradient-to-br opacity-5 group-hover:opacity-10 transition-opacity duration-300",
          variantClasses[variant],
        )}
      />

      {/* Content */}
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className={cn("p-3 rounded-xl bg-gradient-to-br shadow-lg", variantClasses[variant])}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          {trend && (
            <div
              className={cn(
                "flex items-center space-x-1 text-sm font-medium",
                trend.positive ? "text-green-600" : "text-red-600",
              )}
            >
              <span>{trend.positive ? "↗" : "↘"}</span>
              <span>{trend.value}%</span>
            </div>
          )}
        </div>

        <div className="space-y-1">
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
          {trend && <p className="text-xs text-gray-500">{trend.label}</p>}
        </div>
      </div>

      {/* Shimmer effect */}
      {animated && (
        <div className="absolute inset-0 shimmer opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      )}
    </div>
  )
}
