"use client"

import { Shield, Award, Lock, FileText } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function TrustIndicators() {
  return (
    <div className="space-y-4">
      {/* Security Badges */}
      <div className="flex flex-wrap gap-2 justify-center">
        <Badge className="bg-green-100 text-green-800 border-green-200">
          <Shield className="h-3 w-3 mr-1" />
          SSL Secured
        </Badge>
        <Badge className="bg-blue-100 text-blue-800 border-blue-200">
          <Lock className="h-3 w-3 mr-1" />
          Bank Grade Security
        </Badge>
        <Badge className="bg-purple-100 text-purple-800 border-purple-200">
          <Award className="h-3 w-3 mr-1" />
          Licensed Operator
        </Badge>
        <Badge className="bg-orange-100 text-orange-800 border-orange-200">
          <FileText className="h-3 w-3 mr-1" />
          State Compliant
        </Badge>
      </div>

      {/* Trust Stats */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-600">99.9%</div>
              <div className="text-xs text-gray-600">Uptime</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">$2.8M</div>
              <div className="text-xs text-gray-600">Paid Out</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">12K+</div>
              <div className="text-xs text-gray-600">Happy Members</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
