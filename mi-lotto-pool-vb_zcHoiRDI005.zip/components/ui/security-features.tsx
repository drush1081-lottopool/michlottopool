"use client"

import { Shield, Lock, Eye, FileCheck, AlertCircle, CheckCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function SecurityFeatures() {
  const securityFeatures = [
    {
      icon: Lock,
      title: "256-bit SSL Encryption",
      description: "All data transmitted with bank-level security",
      status: "active",
    },
    {
      icon: Shield,
      title: "Two-Factor Authentication",
      description: "Optional 2FA for enhanced account security",
      status: "available",
    },
    {
      icon: Eye,
      title: "Transparent Operations",
      description: "All draws and payouts publicly auditable",
      status: "active",
    },
    {
      icon: FileCheck,
      title: "Identity Verification",
      description: "Michigan residency and age verification required",
      status: "required",
    },
  ]

  return (
    <Card className="border-purple-200 bg-purple-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center space-x-2 text-purple-800">
          <Shield className="h-5 w-5" />
          <span>Security & Privacy</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {securityFeatures.map((feature, index) => (
          <div key={index} className="flex items-start space-x-3 p-2 bg-white/50 rounded">
            <div className="p-1 bg-purple-100 rounded">
              <feature.icon className="h-4 w-4 text-purple-600" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-purple-900 text-sm">{feature.title}</h4>
                {feature.status === "active" && <CheckCircle className="h-4 w-4 text-green-500" />}
                {feature.status === "required" && <AlertCircle className="h-4 w-4 text-orange-500" />}
              </div>
              <p className="text-xs text-purple-700 mt-1">{feature.description}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
