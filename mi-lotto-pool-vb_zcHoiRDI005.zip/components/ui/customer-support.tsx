"use client"

import { Phone, Mail, MessageCircle, Clock, Headphones, HelpCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Badge } from "@/components/ui/badge"

export default function CustomerSupport() {
  return (
    <Card className="border-indigo-200 bg-indigo-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-indigo-800">
            <Headphones className="h-5 w-5" />
            <span>24/7 Support</span>
          </div>
          <Badge className="bg-green-100 text-green-800">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse" />
            Online
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 gap-2">
          <CustomButton variant="outline" size="sm" className="justify-start">
            <MessageCircle className="h-4 w-4 mr-2" />
            Live Chat (Avg: 30 sec)
          </CustomButton>

          <CustomButton variant="ghost" size="sm" className="justify-start">
            <Phone className="h-4 w-4 mr-2" />
            Call: 1-800-MI-LOTTO
          </CustomButton>

          <CustomButton variant="ghost" size="sm" className="justify-start">
            <Mail className="h-4 w-4 mr-2" />
            Email: support@milottopool.com
          </CustomButton>
        </div>

        <div className="flex items-center space-x-2 text-xs text-indigo-700 bg-white/50 p-2 rounded">
          <Clock className="h-3 w-3" />
          <span>Average response time: Under 5 minutes</span>
        </div>

        <div className="flex items-center space-x-2 text-xs text-indigo-700">
          <HelpCircle className="h-3 w-3" />
          <span>FAQ available in 3 languages</span>
        </div>
      </CardContent>
    </Card>
  )
}
