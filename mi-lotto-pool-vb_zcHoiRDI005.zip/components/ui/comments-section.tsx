"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { MessageCircle, Send, ThumbsUp, Flag, Trash2, Facebook, Twitter, Instagram } from "lucide-react"

interface Comment {
  id: number
  userId: string
  userName: string
  userAvatar?: string
  socialMedia?: { platform: string; username: string }
  content: string
  timestamp: string
  likes: number
  isLiked: boolean
  replies?: Comment[]
}

interface CommentsSectionProps {
  poolId?: string
  voteId?: string
  title?: string
}

export function CommentsSection({ poolId, voteId, title = "Comments" }: CommentsSectionProps) {
  const [newComment, setNewComment] = useState("")
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 1,
      userId: "user1",
      userName: "Sarah Johnson",
      socialMedia: { platform: "facebook", username: "sjohnson" },
      content: "This is a great pool! Looking forward to the next draw. Good luck everyone!",
      timestamp: "2 hours ago",
      likes: 12,
      isLiked: false,
    },
    {
      id: 2,
      userId: "user2",
      userName: "Mike Chen",
      socialMedia: { platform: "twitter", username: "@mikechen" },
      content: "Just joined today. The community seems really active and trustworthy.",
      timestamp: "5 hours ago",
      likes: 8,
      isLiked: true,
    },
    {
      id: 3,
      userId: "user3",
      userName: "Emily Rodriguez",
      socialMedia: { platform: "instagram", username: "@emilyrod" },
      content: "Won $500 last month! This pool is legit. Thank you all!",
      timestamp: "1 day ago",
      likes: 24,
      isLiked: false,
    },
  ])

  const handlePostComment = () => {
    if (!newComment.trim()) return

    const comment: Comment = {
      id: Date.now(),
      userId: "currentUser",
      userName: "You",
      content: newComment,
      timestamp: "Just now",
      likes: 0,
      isLiked: false,
    }

    setComments([comment, ...comments])
    setNewComment("")
  }

  const handleLike = (commentId: number) => {
    setComments(
      comments.map((comment) =>
        comment.id === commentId
          ? {
              ...comment,
              likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1,
              isLiked: !comment.isLiked,
            }
          : comment,
      ),
    )
  }

  const handleDelete = (commentId: number) => {
    setComments(comments.filter((comment) => comment.id !== commentId))
  }

  const getSocialIcon = (platform: string) => {
    switch (platform) {
      case "facebook":
        return <Facebook className="h-3 w-3 text-blue-600" />
      case "twitter":
        return <Twitter className="h-3 w-3 text-sky-500" />
      case "instagram":
        return <Instagram className="h-3 w-3 text-pink-600" />
      default:
        return null
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center space-x-2">
            <MessageCircle className="h-5 w-5 text-blue-600" />
            <span>{title}</span>
          </h3>
          <Badge variant="secondary">{comments.length} comments</Badge>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Textarea
              placeholder="Share your thoughts..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              rows={3}
            />
            <div className="flex justify-end">
              <Button onClick={handlePostComment} disabled={!newComment.trim()}>
                <Send className="h-4 w-4 mr-2" />
                Post Comment
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            {comments.map((comment) => (
              <div key={comment.id} className="p-3 bg-gray-50 rounded-lg border">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-start space-x-2">
                    <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-red-600">{comment.userName.charAt(0)}</span>
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <p className="font-medium text-sm">{comment.userName}</p>
                        {comment.socialMedia && (
                          <div className="flex items-center space-x-1 text-xs text-gray-600">
                            {getSocialIcon(comment.socialMedia.platform)}
                            <span>{comment.socialMedia.username}</span>
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">{comment.timestamp}</p>
                    </div>
                  </div>
                  {comment.userId === "currentUser" && (
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(comment.id)}>
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </Button>
                  )}
                </div>

                <p className="text-sm text-gray-700 mb-3">{comment.content}</p>

                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleLike(comment.id)}
                    className={comment.isLiked ? "text-red-600" : ""}
                  >
                    <ThumbsUp className={`h-4 w-4 mr-1 ${comment.isLiked ? "fill-current" : ""}`} />
                    {comment.likes}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Flag className="h-4 w-4 mr-1" />
                    Report
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
