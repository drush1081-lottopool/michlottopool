"use client"

import { AlertTriangle, Clock, DollarSign, Phone, ExternalLink } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import Link from "next/link"

export default function ResponsibleGaming() {
  return (
    <Card className="border-amber-200 bg-amber-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center space-x-2 text-amber-800">
          <AlertTriangle className="h-5 w-5" />
          <span>Play Responsibly</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3 text-sm text-amber-700">
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4" />
            <span>Set time limits for your participation</span>
          </div>
          <div className="flex items-center space-x-2">
            <DollarSign className="h-4 w-4" />
            <span>Only invest what you can afford to lose</span>
          </div>
          <div className="flex items-center space-x-2">
            <Phone className="h-4 w-4" />
            <span>Gambling problem? Call 1-800-270-7117</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Link href="/responsible-gaming">
            <CustomButton variant="outline" size="sm" className="w-full text-xs">
              Learn More
            </CustomButton>
          </Link>
          <Link href="https://www.ncpgambling.org" target="_blank">
            <CustomButton variant="ghost" size="sm" className="w-full text-xs">
              <ExternalLink className="h-3 w-3 mr-1" />
              Get Help
            </CustomButton>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
