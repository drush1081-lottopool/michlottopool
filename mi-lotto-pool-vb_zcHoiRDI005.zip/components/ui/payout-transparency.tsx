"use client"

import { Eye, Download } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CustomButton } from "@/components/ui/custom-button"
import { Progress } from "@/components/ui/progress"

export default function PayoutTransparency() {
  const recentPayouts = [
    { date: "Jan 5, 2025", amount: 15420, winners: 3, pool: "Detroit Metro" },
    { date: "Jan 3, 2025", amount: 8750, winners: 2, pool: "Grand Rapids" },
    { date: "Dec 30, 2024", amount: 22100, winners: 5, pool: "Ann Arbor" },
  ]

  return (
    <Card className="border-green-200 bg-green-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-green-800">
            <Eye className="h-5 w-5" />
            <span>Payout Transparency</span>
          </div>
          <CustomButton variant="ghost" size="sm">
            <Download className="h-4 w-4" />
          </CustomButton>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Payout Distribution */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-green-700">Winners (85%)</span>
            <span className="font-medium">$2.38M</span>
          </div>
          <Progress value={85} className="h-2 bg-green-100" />

          <div className="flex justify-between text-sm">
            <span className="text-blue-700">Operations (10%)</span>
            <span className="font-medium">$280K</span>
          </div>
          <Progress value={10} className="h-2 bg-blue-100" />

          <div className="flex justify-between text-sm">
            <span className="text-gray-700">Reserve Fund (5%)</span>
            <span className="font-medium">$140K</span>
          </div>
          <Progress value={5} className="h-2 bg-gray-100" />
        </div>

        {/* Recent Payouts */}
        <div className="space-y-2">
          <h4 className="font-medium text-green-800 text-sm">Recent Payouts</h4>
          {recentPayouts.map((payout, index) => (
            <div key={index} className="flex items-center justify-between text-xs bg-white/50 p-2 rounded">
              <div>
                <div className="font-medium">${payout.amount.toLocaleString()}</div>
                <div className="text-gray-600">{payout.date}</div>
              </div>
              <div className="text-right">
                <div className="text-green-600">{payout.winners} winners</div>
                <div className="text-gray-600">{payout.pool}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
