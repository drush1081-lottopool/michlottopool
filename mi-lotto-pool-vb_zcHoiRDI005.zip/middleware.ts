import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import jwt from "jsonwebtoken"

export function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Public paths that don't require authentication
  const publicPaths = ["/", "/login", "/register", "/terms", "/privacy", "/forgot-password"]

  // Admin-only paths
  const adminPaths = ["/admin"]

  // Moderator-allowed paths (includes admin paths)
  const moderatorPaths = ["/admin/users", "/admin/documents", "/admin/compliance"]

  // Helper-allowed paths
  const helperPaths = ["/admin/users"]

  // Check if path is public
  if (publicPaths.some((p) => path === p)) {
    return NextResponse.next()
  }

  // Get auth token from cookie
  const token = request.cookies.get("auth-token")?.value

  // Redirect to login if no token
  if (!token) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "fallback-secret") as any

    // Check admin access
    if (adminPaths.some((p) => path.startsWith(p))) {
      const userRole = decoded.role || "user"

      // Full admin access
      if (userRole === "admin") {
        return NextResponse.next()
      }

      // Moderator access to specific paths
      if (userRole === "moderator" && moderatorPaths.some((p) => path.startsWith(p))) {
        return NextResponse.next()
      }

      // Helper access to limited paths
      if (userRole === "helper" && helperPaths.some((p) => path.startsWith(p))) {
        return NextResponse.next()
      }

      // Unauthorized access
      return NextResponse.redirect(new URL("/dashboard", request.url))
    }

    return NextResponse.next()
  } catch (error) {
    // Invalid token, redirect to login
    return NextResponse.redirect(new URL("/login", request.url))
  }
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|placeholder.svg).*)"],
}
