# Michigan Lotto Pool App

A comprehensive, legal-compliant lottery pool management system for Michigan residents.

## Features

- User registration and KYC/identity verification
- Pool creation and member management
- All 10,000 four-digit combination tracking
- Daily email distribution of lottery numbers
- Payment processing (Stripe)
- Bitcoin conversion for winnings
- Democratic voting system
- Comments and social features
- Admin dashboard with role-based access control
- Tax reporting (1099-MISC generation)
- Compliance monitoring and audit trails
- Responsible gaming features

## Quick Start

### Prerequisites

- Node.js 18+ installed
- PostgreSQL database (Supabase or Neon recommended)
- Stripe account
- Email service (Resend, SendGrid, or AWS SES)

### Installation

1. Clone this repository
2. Install dependencies:
\`\`\`bash
npm install
\`\`\`

3. Copy environment variables:
\`\`\`bash
cp .env.example .env.local
\`\`\`

4. Fill in all required environment variables in `.env.local`

5. Set up database:
   - Run `scripts/01-create-database-schema.sql`
   - Run `scripts/02-seed-initial-data.sql`

6. Run development server:
\`\`\`bash
npm run dev
\`\`\`

7. Open [http://localhost:3000/setup](http://localhost:3000/setup) to check system readiness

## Deployment

See [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) for complete deployment instructions.

**Quick Deploy to Vercel:**
1. Push code to GitHub
2. Import repository in Vercel
3. Add environment variables
4. Deploy!

## Legal Requirements

**IMPORTANT:** This app is for Michigan residents only and requires:

- Michigan Gaming Control Board license
- Business entity registration
- Liability insurance
- Legal review of all documents
- Compliance with state gaming laws

**Do not accept real money without proper licensing!**

## Default Admin Account

After running seed scripts, login with:
- Email: admin@milottopool.com
- Password: (Set in SQL script - change immediately!)

## Tech Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- PostgreSQL
- Stripe
- Vercel (hosting)

## Security Features

- Row Level Security (RLS) on database
- JWT authentication
- KYC/identity verification
- Bank-grade encryption (256-bit SSL)
- PCI DSS compliant payments
- Audit logging
- Rate limiting

## Support

For technical support, email: support@milottopool.com

## License

Proprietary - All rights reserved

## Disclaimer

This software is provided as-is. Operating a lottery pool may require licenses and permits in your jurisdiction. Consult with legal counsel before deployment. The developers are not responsible for any legal issues arising from use of this software.
