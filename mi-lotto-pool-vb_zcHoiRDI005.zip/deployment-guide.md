# Michigan Lotto Pool - Deployment Guide

## 🌐 Domain Setup

### 1. Domain Registration
- **Recommended Domain**: `milottopool.com`
- **Alternative Options**: 
  - `michiganlottopool.com`
  - `milotterypool.com`
  - `michiganlottery.pool`

### 2. DNS Configuration
\`\`\`
A Record: @ → Your server IP
CNAME: www → milottopool.com
MX Records: For email functionality
\`\`\`

## 🚀 Deployment Options

### Option 1: Vercel (Recommended)
\`\`\`bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod

# Custom domain
vercel domains add milottopool.com
\`\`\`

### Option 2: Netlify
\`\`\`bash
# Build command
npm run build

# Publish directory
.next
\`\`\`

### Option 3: AWS/DigitalOcean
\`\`\`bash
# Build for production
npm run build

# Start production server
npm start
\`\`\`

## 🔧 Environment Variables

### Production Environment (.env.production)
\`\`\`env
# Site Configuration
NEXT_PUBLIC_SITE_URL=https://milottopool.com
NEXT_PUBLIC_API_URL=https://api.milottopool.com

# Database
DATABASE_URL=mongodb://your-mongodb-connection
REDIS_URL=redis://your-redis-connection

# Authentication
JWT_SECRET=your-super-secure-jwt-secret
NEXTAUTH_SECRET=your-nextauth-secret
NEXTAUTH_URL=https://milottopool.com

# Email Service
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your-sendgrid-api-key
FROM_EMAIL=noreply@milottopool.com

# Payment Processing
STRIPE_SECRET_KEY=sk_live_your-stripe-secret
STRIPE_PUBLISHABLE_KEY=pk_live_your-stripe-publishable
STRIPE_WEBHOOK_SECRET=whsec_your-webhook-secret

# Cron Jobs
CRON_SECRET=your-cron-secret-key

# Analytics
GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
\`\`\`

## 📧 Email Service Setup

### SendGrid Configuration
\`\`\`javascript
// lib/email.js
import sgMail from '@sendgrid/mail'

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

export async function sendDailyNumbers(to, numbers, poolName) {
  const msg = {
    to,
    from: 'noreply@milottopool.com',
    subject: `Your Daily Numbers - ${new Date().toLocaleDateString()}`,
    html: generateNumbersHTML(numbers, poolName),
  }
  
  return sgMail.send(msg)
}
\`\`\`

## 💾 Database Setup

### MongoDB Atlas
\`\`\`javascript
// lib/mongodb.js
import { MongoClient } from 'mongodb'

const client = new MongoClient(process.env.DATABASE_URL)

export async function connectToDatabase() {
  if (!client.isConnected()) {
    await client.connect()
  }
  return client.db('michigan-lotto-pool')
}
\`\`\`

### Schema Design
\`\`\`javascript
// User Schema
{
  _id: ObjectId,
  email: String,
  firstName: String,
  lastName: String,
  phone: String,
  address: String,
  city: String,
  zipCode: String,
  verified: Boolean,
  emailPreferences: {
    dailyNumbers: Boolean,
    drawResults: Boolean,
    poolUpdates: Boolean,
    votingAlerts: Boolean
  },
  pools: [ObjectId],
  createdAt: Date
}

// Pool Schema
{
  _id: ObjectId,
  name: String,
  description: String,
  maxMembers: Number,
  currentMembers: Number,
  minInvestment: Number,
  status: String,
  members: [ObjectId],
  createdAt: Date
}

// Email Subscriber Schema
{
  _id: ObjectId,
  email: String,
  firstName: String,
  lastName: String,
  poolId: ObjectId,
  subscribed: Boolean,
  preferences: Object,
  createdAt: Date
}
\`\`\`

## ⚡ Cron Jobs Setup

### Daily Email Distribution
\`\`\`javascript
// Using node-cron or external service
import cron from 'node-cron'

// Send daily emails at 8:00 AM EST
cron.schedule('0 8 * * *', async () => {
  await sendDailyNumbersToAllSubscribers()
}, {
  timezone: "America/New_York"
})
\`\`\`

### External Cron Service (Recommended)
- **Vercel Cron**: Built-in cron jobs
- **GitHub Actions**: Scheduled workflows
- **Uptime Robot**: HTTP monitoring with webhooks

## 🔒 Security Configuration

### SSL Certificate
\`\`\`bash
# Let's Encrypt (if self-hosting)
certbot --nginx -d milottopool.com -d www.milottopool.com
\`\`\`

### Security Headers
\`\`\`javascript
// next.config.js
const securityHeaders = [
  {
    key: 'X-DNS-Prefetch-Control',
    value: 'on'
  },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload'
  },
  {
    key: 'X-Frame-Options',
    value: 'DENY'
  },
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff'
  }
]
\`\`\`

## 📊 Analytics & Monitoring

### Google Analytics
\`\`\`javascript
// lib/gtag.js
export const GA_TRACKING_ID = process.env.GOOGLE_ANALYTICS_ID

export const pageview = (url) => {
  window.gtag('config', GA_TRACKING_ID, {
    page_path: url,
  })
}
\`\`\`

### Error Monitoring
- **Sentry**: Error tracking
- **LogRocket**: Session replay
- **Uptime Robot**: Uptime monitoring

## 🚀 Performance Optimization

### CDN Setup
- **Cloudflare**: Global CDN and security
- **AWS CloudFront**: Amazon's CDN
- **Vercel Edge Network**: Built-in CDN

### Image Optimization
\`\`\`javascript
// next.config.js
module.exports = {
  images: {
    domains: ['milottopool.com'],
    formats: ['image/webp', 'image/avif'],
  },
}
\`\`\`

## 📱 PWA Configuration

### Manifest File
\`\`\`json
// public/manifest.json
{
  "name": "Michigan Lotto Pool",
  "short_name": "MI Lotto Pool",
  "description": "Michigan's Premier Lottery Pool",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#dc2626",
  "icons": [
    {
      "src": "/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
\`\`\`

## 🔄 Backup Strategy

### Database Backups
\`\`\`bash
# MongoDB backup
mongodump --uri="mongodb://your-connection-string" --out=/backups/

# Automated daily backups
0 2 * * * /usr/local/bin/backup-script.sh
\`\`\`

### File Backups
- **AWS S3**: File storage and backups
- **Google Cloud Storage**: Alternative storage
- **DigitalOcean Spaces**: Cost-effective storage

## 📋 Launch Checklist

### Pre-Launch
- [ ] Domain registered and configured
- [ ] SSL certificate installed
- [ ] Database setup and tested
- [ ] Email service configured
- [ ] Payment processing tested
- [ ] Cron jobs scheduled
- [ ] Analytics installed
- [ ] Error monitoring setup
- [ ] Performance optimized
- [ ] Security headers configured

### Post-Launch
- [ ] Monitor error rates
- [ ] Check email delivery
- [ ] Verify payment processing
- [ ] Monitor site performance
- [ ] Test mobile responsiveness
- [ ] Verify SEO optimization
- [ ] Check analytics data
- [ ] Monitor uptime

## 🎯 Marketing & SEO

### SEO Optimization
- Meta tags configured
- Sitemap generated
- Robots.txt configured
- Schema markup added
- Page speed optimized

### Social Media
- Facebook page setup
- Twitter account created
- LinkedIn company page
- Instagram for visual content

## 📞 Support & Maintenance

### Support Channels
- Email: support@milottopool.com
- Phone: 1-800-MI-LOTTO
- Live chat integration
- Help documentation

### Maintenance Schedule
- Daily: Monitor uptime and errors
- Weekly: Review analytics and performance
- Monthly: Security updates and backups
- Quarterly: Feature updates and improvements

## 💰 Cost Estimation

### Monthly Costs
- Domain: $10-15/year
- Hosting (Vercel Pro): $20/month
- Database (MongoDB Atlas): $25-50/month
- Email Service (SendGrid): $15-30/month
- CDN (Cloudflare): $20/month
- Monitoring: $10-20/month

**Total Estimated Monthly Cost: $90-155**

## 🚀 Go Live Steps

1. **Purchase Domain**: Register milottopool.com
2. **Setup Hosting**: Deploy to Vercel/Netlify
3. **Configure Database**: Setup MongoDB Atlas
4. **Setup Email**: Configure SendGrid
5. **Enable Payments**: Setup Stripe
6. **Schedule Crons**: Daily email distribution
7. **Add Analytics**: Google Analytics
8. **Test Everything**: Full functionality test
9. **Launch**: Go live with monitoring
10. **Monitor**: Watch for issues and optimize

The app is now ready for full production deployment with all necessary infrastructure and services configured!
